window.settings={

  useEmbeddedContent:true,
  outContentToConsole:false,

  contentUrl:"./presentation/content.xlsx",

  transition:{
    delay:0,
    duration:1,
    easing:"ease-in-out",
  },

  cacheSize:5,
  startPosition:0,

}
