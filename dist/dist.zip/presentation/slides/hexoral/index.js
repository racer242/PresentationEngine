(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib._001 = function() {
	this.initialize(img._001);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._1 = function() {
	this.initialize(img._1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._1pngcopy = function() {
	this.initialize(img._1pngcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._1pngcopy2 = function() {
	this.initialize(img._1pngcopy2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._1pngcopy3 = function() {
	this.initialize(img._1pngcopy3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._1pngcopy4 = function() {
	this.initialize(img._1pngcopy4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._1pngcopy5 = function() {
	this.initialize(img._1pngcopy5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._2 = function() {
	this.initialize(img._2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.EditBox = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* this.visible=false;*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Graphic
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag/AzIAAgSIBkhDIhkAAIAAgQICAAAIAAASIhkBCIBkAAIAAARg");
	this.shape.setTransform(1303.85,15.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag/AwIAAhcIAPAAIAABLIAoAAIAAhGIANAAIAABGIAsAAIAAhOIAQAAIAABfg");
	this.shape_1.setTransform(1303.85,27.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag/AwIAAhcIAPAAIAABLIAoAAIAAhGIANAAIAABGIAsAAIAAhOIAQAAIAABfg");
	this.shape_2.setTransform(1303.85,39.375);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag/A5IAAg5QAAgRADgJQAEgJAIgFQAJgFALAAQAOAAAJAIQAIAJADATQADgHADgDQAHgIAKgHIAkgWIAAAVIgbASIgSAMIgIAHIgEAIIgBAKIAAAUIA6AAIAAARgAgrgVQgGAGAAAPIAAAoIArAAIAAglQgBgLgCgGQgDgHgEgDQgGgEgGAAQgJAAgGAHg");
	this.shape_3.setTransform(1303.85,51.525);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgjAxQgPgHgIgOQgHgOgBgRQABgTAJgNQAKgNASgFIAEAQQgOAEgGAJQgHAIAAANQAAAOAHAKQAIAKAMAFQAMADAMAAQAPAAANgEQAMgFAGgKQAGgKAAgLQAAgOgIgKQgJgLgPgDIADgRQAWAGALAOQALAOgBATQABAVgJAMQgJANgQAHQgQAHgRAAQgUAAgPgIg");
	this.shape_4.setTransform(1303.85,65);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAVAjQAKgBAHgEQAGgEADgJQAEgJAAgKQAAgKgDgHQgDgIgFgDQgFgEgGAAQgFAAgFAEQgFADgCAIIgHAWQgEASgDAHQgFAJgHAFQgHAEgJAAQgKAAgIgFQgJgGgEgKQgFgLAAgNQAAgNAFgLQAFgLAIgGQAJgGAMgBIABARQgMABgGAIQgHAHAAAOQABAQAFAHQAGAHAIAAQAHAAAEgFQAEgFAFgUQAFgVADgHQAFgMAIgFQAHgFALAAQAKAAAJAFQAKAGAFALQAEALAAAOQAAARgEAMQgFALgKAHQgLAHgNAAg");
	this.shape_5.setTransform(1303.85,77.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag/AwIAAhcIAPAAIAABLIAoAAIAAhGIANAAIAABGIAsAAIAAhOIAQAAIAABfg");
	this.shape_6.setTransform(1303.85,94.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag/AyIAAgRIA0AAIAAhBIg0AAIAAgRICAAAIAAARIg9AAIAABBIA9AAIAAARg");
	this.shape_7.setTransform(1303.85,107.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag/AzIAAhlIAPAAIAAArIBxAAIAAAQIhxAAIAAAqg");
	this.shape_8.setTransform(1303.85,119.075);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag/A1IAAgRIA/AAIg/g/IAAgXIA0A1IBMg3IAAAWIhBAtIAUAVIAtAAIAAARg");
	this.shape_9.setTransform(1303.85,134.975);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgjAxQgPgHgIgOQgHgPgBgQQABgTAJgNQAKgOASgEIAEAQQgOAFgGAIQgHAIAAAOQAAAOAHAJQAIALAMAEQAMADAMAAQAPAAANgEQAMgFAGgKQAGgLAAgKQAAgOgIgLQgJgKgPgDIADgRQAWAGALAOQALANgBAVQABATgJANQgJAOgQAGQgQAHgRAAQgUAAgPgIg");
	this.shape_10.setTransform(1303.85,148);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Ag/AIIAAgPICAAAIAAAPg");
	this.shape_11.setTransform(1303.85,157.05);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag/AoIAAgRIBwAAIAAg+IAQAAIAABPg");
	this.shape_12.setTransform(1303.85,164.275);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgjAyQgPgJgIgOQgHgOgBgQQABgTAJgOQAKgNASgEIAEAQQgOAFgGAIQgHAIAAAOQAAAOAHAJQAIALAMAEQAMADAMAAQAPAAANgEQAMgFAGgKQAGgLAAgKQAAgOgIgLQgJgKgPgDIADgRQAWAGALAOQALANgBAVQABATgJANQgJAOgQAGQgQAHgRAAQgUAAgPgHg");
	this.shape_13.setTransform(1303.85,176);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0)").s().p("Ehj/A+gMAAAh8/MDH/AAAMAAAB8/g");
	this.shape_14.setTransform(640,400);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#999999").s().p("EgBjBLAMAAAiV/IDHAAMAAACV/g");
	this.shape_15.setTransform(1304,480);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.EditBox, new cjs.Rectangle(0,0,1316.1,960), null);


(lib.AreaButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,255,255,0.902)").s().p("AnzH0IAAvnIPnAAIAAPng");
	this.shape.setTransform(50,50);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,100,100);


(lib.light_a = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._2, null, new cjs.Matrix2D(1,0,0,1,-377.5,-528.8)).s().p("ArLJpIAAzRIWXAAIAATRg");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.light_a, new cjs.Rectangle(-71.5,-61.7,143.1,123.4), null);


(lib.Slide07 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{viewSlide02:2,end02:3});

	// Layer_6
	this.gotoSlide00hexoral06 = new lib.AreaButton();
	this.gotoSlide00hexoral06.name = "gotoSlide00hexoral06";
	this.gotoSlide00hexoral06.parent = this;
	this.gotoSlide00hexoral06.setTransform(1144.5,537.75,0.7451,0.6849);
	new cjs.ButtonHelper(this.gotoSlide00hexoral06, 0, 1, 2, false, new lib.AreaButton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.gotoSlide00hexoral06).wait(7));

	// Layer_2
	this.instance = new lib._1pngcopy();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(7));

	// ________EditBox_______
	this.instance_1 = new lib.EditBox();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(7));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1316.1,960);


(lib.Slide05 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"viewSlide02":2,"end02":3});

	// Layer_6
	this.gotoSlide00hexoral04 = new lib.AreaButton();
	this.gotoSlide00hexoral04.name = "gotoSlide00hexoral04";
	this.gotoSlide00hexoral04.parent = this;
	this.gotoSlide00hexoral04.setTransform(1144.5,621.75,0.7451,0.6849);
	new cjs.ButtonHelper(this.gotoSlide00hexoral04, 0, 1, 2, false, new lib.AreaButton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.gotoSlide00hexoral04).wait(13));

	// _
	this.instance = new lib._1pngcopy3();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(13));

	// ________EditBox_______
	this.instance_1 = new lib.EditBox();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(13));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1316.1,960);


(lib.Slide03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"viewSlide02":2,"end02":3});

	// Layer_6
	this.gotoSlide00hexoral02 = new lib.AreaButton();
	this.gotoSlide00hexoral02.name = "gotoSlide00hexoral02";
	this.gotoSlide00hexoral02.parent = this;
	this.gotoSlide00hexoral02.setTransform(1146.9,565.75,0.7451,0.6849);
	new cjs.ButtonHelper(this.gotoSlide00hexoral02, 0, 1, 2, false, new lib.AreaButton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.gotoSlide00hexoral02).wait(13));

	// _
	this.instance = new lib._1pngcopy5();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(13));

	// ________EditBox_______
	this.instance_1 = new lib.EditBox();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(13));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1316.1,960);


(lib.Slide01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"viewSlide02":2,"end02":3});

	// Layer_6
	this.gotoSlide00multizima07 = new lib.AreaButton();
	this.gotoSlide00multizima07.name = "gotoSlide00multizima07";
	this.gotoSlide00multizima07.parent = this;
	this.gotoSlide00multizima07.setTransform(1164.5,1061.25,0.7451,0.6849);
	new cjs.ButtonHelper(this.gotoSlide00multizima07, 0, 1, 2, false, new lib.AreaButton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.gotoSlide00multizima07).wait(8));

	// Layer_2
	this.instance = new lib._001();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(8));

	// ________EditBox_______
	this.instance_1 = new lib.EditBox();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(8));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1316.1,1129.8);


(lib._2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.light_a();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({scaleX:1.0084,scaleY:1.0084,alpha:0.9688},0).wait(1).to({scaleX:1.0335,scaleY:1.0335,alpha:0.875},0).wait(1).to({scaleX:1.0754,scaleY:1.0754,alpha:0.7188},0).wait(1).to({scaleX:1.1341,scaleY:1.1341,alpha:0.5},0).wait(1).to({scaleX:1.0858,scaleY:1.0858,alpha:0.68},0).wait(1).to({scaleX:1.0483,scaleY:1.0483,alpha:0.82},0).wait(1).to({scaleX:1.0215,scaleY:1.0215,alpha:0.92},0).wait(1).to({scaleX:1.0054,scaleY:1.0054,alpha:0.98},0).wait(1).to({scaleX:1,scaleY:1,alpha:1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-81.1,-69.9,162.3,139.9);


(lib.Slide06 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"viewSlide02":45,"end02":46});

	// Layer_6
	this.gotoSlide00hexoral07 = new lib.AreaButton();
	this.gotoSlide00hexoral07.name = "gotoSlide00hexoral07";
	this.gotoSlide00hexoral07.parent = this;
	this.gotoSlide00hexoral07.setTransform(1164.5,745.75,0.7451,0.6849);
	new cjs.ButtonHelper(this.gotoSlide00hexoral07, 0, 1, 2, false, new lib.AreaButton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.gotoSlide00hexoral07).wait(50));

	// _
	this.instance = new lib._2_1("single",0);
	this.instance.parent = this;
	this.instance.setTransform(601.5,248.85);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({mode:"synched"},0).wait(40).to({mode:"single"},0).wait(6));

	// _
	this.instance_1 = new lib._1pngcopy2();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(50));

	// ________EditBox_______
	this.instance_2 = new lib.EditBox();
	this.instance_2.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1316.1,960);


(lib.Slide04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"viewSlide02":44,"end02":45});

	// Layer_8
	this.gotoSlide07hexoral05 = new lib.AreaButton();
	this.gotoSlide07hexoral05.name = "gotoSlide07hexoral05";
	this.gotoSlide07hexoral05.parent = this;
	this.gotoSlide07hexoral05.setTransform(1164.5,753.75,0.7451,0.6849);
	new cjs.ButtonHelper(this.gotoSlide07hexoral05, 0, 1, 2, false, new lib.AreaButton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.gotoSlide07hexoral05).wait(50));

	// _
	this.instance = new lib._2_1("single",0);
	this.instance.parent = this;
	this.instance.setTransform(601.5,248.85);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({mode:"synched"},0).wait(40).to({mode:"single"},0).wait(6));

	// _
	this.instance_1 = new lib._1pngcopy4();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(50));

	// ________EditBox_______
	this.instance_2 = new lib.EditBox();
	this.instance_2.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1316.1,960);


(lib.Slide02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"viewSlide02":44,"end02":45});

	// Layer_8
	this.gotoSlide05hexoral03 = new lib.AreaButton();
	this.gotoSlide05hexoral03.name = "gotoSlide05hexoral03";
	this.gotoSlide05hexoral03.parent = this;
	this.gotoSlide05hexoral03.setTransform(1164.5,748.15,0.7451,0.6849);
	new cjs.ButtonHelper(this.gotoSlide05hexoral03, 0, 1, 2, false, new lib.AreaButton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.gotoSlide05hexoral03).wait(50));

	// _
	this.instance = new lib._2_1("single",0);
	this.instance.parent = this;
	this.instance.setTransform(377.5,528.85);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({mode:"synched"},0).wait(40).to({mode:"single"},0).wait(6));

	// _
	this.instance_1 = new lib._1();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(50));

	// ________EditBox_______
	this.instance_2 = new lib.EditBox();
	this.instance_2.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1316.1,960);


// stage content:
(lib.hexoral = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1316.1,1061.3);
// library properties:
lib.properties = {
	id: '284D0C179085334E961662CC8FA93117',
	width: 1280,
	height: 960,
	fps: 24,
	color: "#000000",
	opacity: 1.00,
	manifest: [
		{src:"images/_001.png", id:"_001"},
		{src:"images/_1.png", id:"_1"},
		{src:"images/_1pngcopy.png", id:"_1pngcopy"},
		{src:"images/_1pngcopy2.png", id:"_1pngcopy2"},
		{src:"images/_1pngcopy3.png", id:"_1pngcopy3"},
		{src:"images/_1pngcopy4.png", id:"_1pngcopy4"},
		{src:"images/_1pngcopy5.png", id:"_1pngcopy5"},
		{src:"images/_2.png", id:"_2"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['284D0C179085334E961662CC8FA93117'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;