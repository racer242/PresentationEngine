(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib._1 = function() {
	this.initialize(img._1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._1pngcopy = function() {
	this.initialize(img._1pngcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._1pngcopy10 = function() {
	this.initialize(img._1pngcopy10);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._1pngcopy11 = function() {
	this.initialize(img._1pngcopy11);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._1pngcopy12 = function() {
	this.initialize(img._1pngcopy12);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._1pngcopy13 = function() {
	this.initialize(img._1pngcopy13);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._1pngcopy14 = function() {
	this.initialize(img._1pngcopy14);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._1pngcopy2 = function() {
	this.initialize(img._1pngcopy2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._1pngcopy3 = function() {
	this.initialize(img._1pngcopy3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._1pngcopy4 = function() {
	this.initialize(img._1pngcopy4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._1pngcopy5 = function() {
	this.initialize(img._1pngcopy5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._1pngcopy6 = function() {
	this.initialize(img._1pngcopy6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._1pngcopy7 = function() {
	this.initialize(img._1pngcopy7);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._1pngcopy8 = function() {
	this.initialize(img._1pngcopy8);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._1pngcopy9 = function() {
	this.initialize(img._1pngcopy9);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._2 = function() {
	this.initialize(img._2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._2pngcopy = function() {
	this.initialize(img._2pngcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._2pngcopy10 = function() {
	this.initialize(img._2pngcopy10);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._2pngcopy11 = function() {
	this.initialize(img._2pngcopy11);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._2pngcopy12 = function() {
	this.initialize(img._2pngcopy12);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._2pngcopy2 = function() {
	this.initialize(img._2pngcopy2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._2pngcopy3 = function() {
	this.initialize(img._2pngcopy3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._2pngcopy4 = function() {
	this.initialize(img._2pngcopy4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._2pngcopy5 = function() {
	this.initialize(img._2pngcopy5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._2pngcopy6 = function() {
	this.initialize(img._2pngcopy6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._2pngcopy7 = function() {
	this.initialize(img._2pngcopy7);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._2pngcopy8 = function() {
	this.initialize(img._2pngcopy8);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._2pngcopy9 = function() {
	this.initialize(img._2pngcopy9);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._3 = function() {
	this.initialize(img._3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);


(lib._3pngcopy = function() {
	this.initialize(img._3pngcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1280,960);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._1pngcopy, null, new cjs.Matrix2D(1,0,0,1,-928.2,-402.1)).s().p("AvJYYIAArGIDIo2IAA8zIbLAAIAAMMIqAAAIAAQZIKAAAIAAUKg");
	this.shape.setTransform(77.025,156.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(-20,0,194.1,312.1), null);


(lib.EditBox = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* this.visible=false;*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Graphic
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag/AzIAAgSIBkhDIhkAAIAAgQICAAAIAAASIhkBCIBkAAIAAARg");
	this.shape.setTransform(1303.85,15.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag/AwIAAhcIAPAAIAABLIAoAAIAAhGIANAAIAABGIAsAAIAAhOIAQAAIAABfg");
	this.shape_1.setTransform(1303.85,27.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag/AwIAAhcIAPAAIAABLIAoAAIAAhGIANAAIAABGIAsAAIAAhOIAQAAIAABfg");
	this.shape_2.setTransform(1303.85,39.375);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag/A5IAAg5QAAgRADgJQAEgJAIgFQAJgFALAAQAOAAAJAIQAIAJADATQADgHADgDQAHgIAKgHIAkgWIAAAVIgbASIgSAMIgIAHIgEAIIgBAKIAAAUIA6AAIAAARgAgrgVQgGAGAAAPIAAAoIArAAIAAglQgBgLgCgGQgDgHgEgDQgGgEgGAAQgJAAgGAHg");
	this.shape_3.setTransform(1303.85,51.525);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgjAxQgPgHgIgOQgHgOgBgRQABgTAJgNQAKgNASgFIAEAQQgOAEgGAJQgHAIAAANQAAAOAHAKQAIAKAMAFQAMADAMAAQAPAAANgEQAMgFAGgKQAGgKAAgLQAAgOgIgKQgJgLgPgDIADgRQAWAGALAOQALAOgBATQABAVgJAMQgJANgQAHQgQAHgRAAQgUAAgPgIg");
	this.shape_4.setTransform(1303.85,65);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAVAjQAKgBAHgEQAGgEADgJQAEgJAAgKQAAgKgDgHQgDgIgFgDQgFgEgGAAQgFAAgFAEQgFADgCAIIgHAWQgEASgDAHQgFAJgHAFQgHAEgJAAQgKAAgIgFQgJgGgEgKQgFgLAAgNQAAgNAFgLQAFgLAIgGQAJgGAMgBIABARQgMABgGAIQgHAHAAAOQABAQAFAHQAGAHAIAAQAHAAAEgFQAEgFAFgUQAFgVADgHQAFgMAIgFQAHgFALAAQAKAAAJAFQAKAGAFALQAEALAAAOQAAARgEAMQgFALgKAHQgLAHgNAAg");
	this.shape_5.setTransform(1303.85,77.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag/AwIAAhcIAPAAIAABLIAoAAIAAhGIANAAIAABGIAsAAIAAhOIAQAAIAABfg");
	this.shape_6.setTransform(1303.85,94.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag/AyIAAgRIA0AAIAAhBIg0AAIAAgRICAAAIAAARIg9AAIAABBIA9AAIAAARg");
	this.shape_7.setTransform(1303.85,107.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag/AzIAAhlIAPAAIAAArIBxAAIAAAQIhxAAIAAAqg");
	this.shape_8.setTransform(1303.85,119.075);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag/A1IAAgRIA/AAIg/g/IAAgXIA0A1IBMg3IAAAWIhBAtIAUAVIAtAAIAAARg");
	this.shape_9.setTransform(1303.85,134.975);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgjAxQgPgHgIgOQgHgPgBgQQABgTAJgNQAKgOASgEIAEAQQgOAFgGAIQgHAIAAAOQAAAOAHAJQAIALAMAEQAMADAMAAQAPAAANgEQAMgFAGgKQAGgLAAgKQAAgOgIgLQgJgKgPgDIADgRQAWAGALAOQALANgBAVQABATgJANQgJAOgQAGQgQAHgRAAQgUAAgPgIg");
	this.shape_10.setTransform(1303.85,148);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Ag/AIIAAgPICAAAIAAAPg");
	this.shape_11.setTransform(1303.85,157.05);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag/AoIAAgRIBwAAIAAg+IAQAAIAABPg");
	this.shape_12.setTransform(1303.85,164.275);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgjAyQgPgJgIgOQgHgOgBgQQABgTAJgOQAKgNASgEIAEAQQgOAFgGAIQgHAIAAAOQAAAOAHAJQAIALAMAEQAMADAMAAQAPAAANgEQAMgFAGgKQAGgLAAgKQAAgOgIgLQgJgKgPgDIADgRQAWAGALAOQALANgBAVQABATgJANQgJAOgQAGQgQAHgRAAQgUAAgPgHg");
	this.shape_13.setTransform(1303.85,176);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(255,255,255,0)").s().p("Ehj/A+gMAAAh8/MDH/AAAMAAAB8/g");
	this.shape_14.setTransform(640,400);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#999999").s().p("EgBjBLAMAAAiV/IDHAAMAAACV/g");
	this.shape_15.setTransform(1304,480);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.EditBox, new cjs.Rectangle(0,0,1316.1,960), null);


(lib.CancelButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Red
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D20701").s().p("AhdAAIBKhRIAAA6IBxAAIAAAvIhxAAIAAA6g");
	this.shape.setTransform(35.025,58.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D20701").s().p("AgOA2QgGgGAAgKIAAhgIAVAAIAABZQAAAEACADQACADAEAAIAFgBIAEgCIADARQgEACgGABIgLABQgJAAgFgFg");
	this.shape_1.setTransform(59.625,34.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D20701").s().p("AgRAoQgIgDgGgGQgGgGgDgIQgDgIAAgIQAAgIADgIQADgIAGgHQAFgFAJgEQAIgDAKgBQAJABAJADQAHAEAGAFQAGAGADAJQADAIAAAHIAAAEIgBADIhAAAQABAFACAEIAFAGIAHAFIAHABQAHAAAFgDQAFgDADgFIASAEQgEALgLAFQgKAGgOABQgJAAgIgEgAgHgZQgEACgDACIgFAGQgCAEAAAFIArAAQgBgKgGgFQgGgGgJAAQgEAAgDACg");
	this.shape_2.setTransform(51.85,35.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D20701").s().p("AgOAoQgIgDgGgHQgGgGgDgHQgDgJAAgIQAAgHADgIQADgJAGgGQAFgFAIgEQAJgDAJgBQAOAAAJAHQAKAFAFAKIgVAGQgDgEgEgDQgFgCgFAAQgEAAgEACQgEACgDADQgDADgCAFQgBAFAAAEQAAAGACAEQABAFADAEIAHAEQAEADAEAAQAFAAAFgEQAFgDACgDIAVAGQgEAJgKAGQgKAGgOABQgJAAgIgEg");
	this.shape_3.setTransform(42.575,35.85);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D20701").s().p("AASArIAAguQAAgKgEgFQgEgFgGAAIgFACQgEABgDACIgFAGIgEAHIAAAwIgVAAIAAhTIATAAIAAAPQAFgIAJgEQAIgFALAAQAHAAAFADQAFADADAFQADAFABAFIABAMIAAA0g");
	this.shape_4.setTransform(33.225,35.775);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D20701").s().p("AgXApQgFgBgEgEQgEgEgCgEQgCgFAAgGQAAgGACgFQADgFAFgCQAFgEAGgCQAHgCAHAAIAKABIAKACIAAgEQAAgJgFgEQgFgFgIABQgHAAgGACQgGADgHAEIgHgOQARgLASAAQARAAAKAJQAKAKAAARIAAAZQAAAAAAABQAAABABAAQAAABAAAAQAAABABAAQAAAAAAABQABAAAAAAQABABAAAAQABAAAAAAIAAASIgJABQgGAAgDgDQgEgDAAgEIgBgEQgGAHgHADQgHAFgKAAQgGAAgFgDgAgPAGQgFADAAAHQAAAFAEAEQAEADAHAAQAFAAAEgCQAFgCACgDQAEgDAAgDIAAgKIgIgCIgIgBQgIAAgGAEg");
	this.shape_5.setTransform(23.675,35.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#D20701").s().p("AgRA1QgKgGgHgIQgIgIgEgKQgEgLAAgKQAAgLAEgKQAEgKAHgIQAHgIALgFQAKgFAMAAQAQAAALAHQAMAHAFALIgRAMQgCgFgDgEIgHgEIgIgDIgHgBQgIAAgGADQgGAEgEAFQgEAFgCAHQgCAHAAAGQAAAHACAHQACAHAFAGQAEAEAGAEQAHADAGAAIAIgBIAIgDQAEgCADgDQADgEACgEIASAKQgDAGgFAFQgFAFgGADQgGAEgIACQgHABgHAAQgLAAgKgEg");
	this.shape_6.setTransform(13.725,34.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgOA2QgGgGAAgKIAAhgIAVAAIAABZQAAAEACADQACADAEAAIAFgBIAEgCIADARQgEACgGABIgLABQgJAAgFgFg");
	this.shape_7.setTransform(59.625,34.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgRAoQgIgDgGgGQgGgGgDgIQgDgIAAgIQAAgIADgIQADgIAGgHQAFgFAJgEQAIgDAKgBQAJABAJADQAHAEAGAFQAGAGADAJQADAIAAAHIAAAEIgBADIhAAAQABAFACAEIAFAGIAHAFIAHABQAHAAAFgDQAFgDADgFIASAEQgEALgLAFQgKAGgOABQgJAAgIgEgAgHgZQgEACgDACIgFAGQgCAEAAAFIArAAQgBgKgGgFQgGgGgJAAQgEAAgDACg");
	this.shape_8.setTransform(51.85,35.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgOAoQgIgDgGgHQgGgGgDgHQgDgJAAgIQAAgHADgIQADgJAGgGQAFgFAIgEQAJgDAJgBQAOAAAJAHQAKAFAFAKIgVAGQgDgEgEgDQgFgCgFAAQgEAAgEACQgEACgDADQgDADgCAFQgBAFAAAEQAAAGACAEQABAFADAEIAHAEQAEADAEAAQAFAAAFgEQAFgDACgDIAVAGQgEAJgKAGQgKAGgOABQgJAAgIgEg");
	this.shape_9.setTransform(42.575,35.85);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AASArIAAguQAAgKgEgFQgEgFgGAAIgFACQgEABgDACIgFAGIgEAHIAAAwIgVAAIAAhTIATAAIAAAPQAFgIAJgEQAIgFALAAQAHAAAFADQAFADADAFQADAFABAFIABAMIAAA0g");
	this.shape_10.setTransform(33.225,35.775);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgXApQgFgBgEgEQgEgEgCgEQgCgFAAgGQAAgGACgFQADgFAFgCQAFgEAGgCQAHgCAHAAIAKABIAKACIAAgEQAAgJgFgEQgFgFgIABQgHAAgGACQgGADgHAEIgHgOQARgLASAAQARAAAKAJQAKAKAAARIAAAZQAAAAAAABQAAABABAAQAAABAAAAQAAABABAAQAAAAAAABQABAAAAAAQABABAAAAQABAAAAAAIAAASIgJABQgGAAgDgDQgEgDAAgEIgBgEQgGAHgHADQgHAFgKAAQgGAAgFgDgAgPAGQgFADAAAHQAAAFAEAEQAEADAHAAQAFAAAEgCQAFgCACgDQAEgDAAgDIAAgKIgIgCIgIgBQgIAAgGAEg");
	this.shape_11.setTransform(23.675,35.85);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgRA1QgKgGgHgIQgIgIgEgKQgEgLAAgKQAAgLAEgKQAEgKAHgIQAHgIALgFQAKgFAMAAQAQAAALAHQAMAHAFALIgRAMQgCgFgDgEIgHgEIgIgDIgHgBQgIAAgGADQgGAEgEAFQgEAFgCAHQgCAHAAAGQAAAHACAHQACAHAFAGQAEAEAGAEQAHADAGAAIAIgBIAIgDQAEgCADgDQADgEACgEIASAKQgDAGgFAFQgFAFgGADQgGAEgIACQgHABgHAAQgLAAgKgEg");
	this.shape_12.setTransform(13.725,34.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhdAAIBKhRIAAA5IBxAAIAAAxIhxAAIAAA4g");
	this.shape_13.setTransform(35.025,58.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7}]},2).to({state:[]},1).wait(1));

	// RedButtonLayer
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AldFeIAAq7IK7AAIAAK7g");
	this.shape_14.setTransform(35,35);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#404040").s().p("AldFeIAAq7IK7AAIAAK7g");
	this.shape_15.setTransform(35,35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14}]}).to({state:[{t:this.shape_15}]},2).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,70,70);


(lib._11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._2pngcopy4, null, new cjs.Matrix2D(1,0,0,1,-797.7,-746.8)).s().p("ArjGEIAAsIIXHAAIAAMIg");
	this.shape.setTransform(74.025,38.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._11, new cjs.Rectangle(0,0,148.1,77.7), null);


(lib._7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._2pngcopy4, null, new cjs.Matrix2D(1,0,0,1,-277.1,-749.1)).s().p("AwKHNIAAuZMAgVAAAIAAOZg");
	this.shape.setTransform(103.525,46.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._7, new cjs.Rectangle(0,0,207.1,92.2), null);


(lib._6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._2pngcopy4, null, new cjs.Matrix2D(1,0,0,1,-1051.5,-562.4)).s().p("A1SHsIgKgvIAAupMAq5AAAIAAPYg");
	this.shape.setTransform(137.275,49.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._6, new cjs.Rectangle(0,0,274.6,98.5), null);


(lib._5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._2pngcopy4, null, new cjs.Matrix2D(1,0,0,1,-1040.7,-451.6)).s().p("AzsI7IAAxxIABgEMAnYAAAIAAR1g");
	this.shape.setTransform(126.1,57.075);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._5, new cjs.Rectangle(0,0,252.2,114.2), null);


(lib._4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._2pngcopy4, null, new cjs.Matrix2D(1,0,0,1,-796.2,-501)).s().p("EgSvAgWMAAAhArMAlfAAAIAAOgIgPBNIgBAAIAAADQjWQ0DSQUIAAAvIAKAAIAKAvIAAOVg");
	this.shape.setTransform(120.025,206.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._4, new cjs.Rectangle(0,0,240.1,414), null);


(lib._3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._2pngcopy4, null, new cjs.Matrix2D(1,0,0,1,-504.6,-553.4)).s().p("A2QIKIAAwUMAshAAAIAAQUg");
	this.shape.setTransform(142.525,52.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._3_1, new cjs.Rectangle(0,0,285.1,104.5), null);


(lib._2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._2pngcopy4, null, new cjs.Matrix2D(1,0,0,1,-504.6,-434.4)).s().p("A2QIzIAAxlMAshAAAIAARlg");
	this.shape.setTransform(142.525,56.275);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._2_1, new cjs.Rectangle(0,0,285.1,112.6), null);


(lib._1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._2pngcopy4, null, new cjs.Matrix2D(1,0,0,1,-248.1,-507.5)).s().p("AroejImLAAMAAAg9FMAjnAAAMAAAA9Fg");
	this.shape.setTransform(114.025,195.475);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._1_1, new cjs.Rectangle(0,0,228.1,391), null);


(lib._12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._1pngcopy, null, new cjs.Matrix2D(1,0,0,1,-355.6,-820.2)).s().p("EgotADIIAAmPMBRaAAAIAAGPg");
	this.shape.setTransform(260.55,20);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._12, new cjs.Rectangle(0,0,521.1,40), null);


(lib._11_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(img._1pngcopy, null, new cjs.Matrix2D(1,0,0,1,-1036.2,-632.2)).s().p("A/uImIAAxLMA/cAAAIAARLg");
	this.shape_1.setTransform(203.05,55.025);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib._11_1, new cjs.Rectangle(0,0,406.1,110.1), null);


(lib._10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._1pngcopy, null, new cjs.Matrix2D(1,0,0,1,-665.2,-660.2)).s().p("A4/UoMgBQgpPIbfBGIAAEDIYOAAIAAkDIAyAAMAAAAoJg");
	this.shape.setTransform(168.025,132.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._10, new cjs.Rectangle(0,0,336.1,264.1), null);


(lib._9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._1pngcopy, null, new cjs.Matrix2D(1,0,0,1,-312.6,-639.7)).s().p("A81RbMAAAgg0MAkaAAAIAAiBIVQAAMAAAAi1g");
	this.shape.setTransform(184.55,111.525);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._9, new cjs.Rectangle(0,0,369.1,223.1), null);


(lib._7_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(img._1pngcopy, null, new cjs.Matrix2D(1,0,0,1,-1108.3,-380.1)).s().p("As9IwIAAhGIqAAAIAAwZMAt7AAAIAARfg");
	this.shape_1.setTransform(147.025,56.025);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib._7_1, new cjs.Rectangle(0,0,294.1,112.1), null);


(lib._5_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(img._1pngcopy, null, new cjs.Matrix2D(1,0,0,1,-762.2,-399.6)).s().p("At5X/MAAAgv9IbzAAMgDIAv9g");
	this.shape_1.setTransform(89.025,153.525);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib._5_1, new cjs.Rectangle(0,0,178.1,307.1), null);


(lib._3_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(img._1pngcopy, null, new cjs.Matrix2D(1,0,0,1,-450.1,-392.6)).s().p("A8cKtIAA1ZMA45AAAIAAVZg");
	this.shape_1.setTransform(182.05,68.525);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib._3_2, new cjs.Rectangle(0,0,364.1,137.1), null);


(lib._2_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(img._1pngcopy, null, new cjs.Matrix2D(1,0,0,1,-248.6,-397.6)).s().p("Ay0XhMAAAgvBIfZAAIAAMCIpiAAIAAVZIPyAAIAANmg");
	this.shape_1.setTransform(120.525,150.525);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib._2_2, new cjs.Rectangle(0,0,241.1,301.1), null);


(lib._1_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(img._1pngcopy, null, new cjs.Matrix2D(1,0,0,1,-654.1,-549.6)).s().p("EAn3A62MAAAglWMAwdAAAMAAAAlWgEhYTgwhIAAqUMBouAAAIAAKUg");
	this.shape_1.setTransform(565.15,376.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib._1_2, new cjs.Rectangle(0,0,1130.3,753.2), null);


(lib._4_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(img._2pngcopy, null, new cjs.Matrix2D(1,0,0,1,-176,-416)).s().p("Ar3KAIAAz/IXvAAIAAT/g");
	this.shape_1.setTransform(76,64);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib._4_1, new cjs.Rectangle(0,0,152,128), null);


(lib._3_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(img._2pngcopy, null, new cjs.Matrix2D(1,0,0,1,-1166,-351)).s().p("AxzKyIAA1jMAjnAAAIAAVjg");
	this.shape_2.setTransform(114,69);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib._3_3, new cjs.Rectangle(0,0,228,138), null);


(lib._2_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(img._2pngcopy, null, new cjs.Matrix2D(1,0,0,1,-386,-257)).s().p("EgsrAO2IAA9rMBZXAAAIAAdrg");
	this.shape_2.setTransform(286,95);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib._2_3, new cjs.Rectangle(0,0,572,190), null);


(lib._1_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(img._2pngcopy, null, new cjs.Matrix2D(1,0,0,1,-1126,-222)).s().p("A4DJYIAAyvMAwHAAAIAASvg");
	this.shape_2.setTransform(154,60);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib._1_3, new cjs.Rectangle(0,0,308,120), null);


(lib._10_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(img._2pngcopy2, null, new cjs.Matrix2D(1,0,0,1,-355,-850)).s().p("Egn1AH0IAAvnMBPrAAAIAAPng");
	this.shape_1.setTransform(255,10);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib._10_1, new cjs.Rectangle(0,-40,510,100), null);


(lib._9_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(img._2pngcopy2, null, new cjs.Matrix2D(1,0,0,1,-1014,-780)).s().p("A13FUIAAqnMArvAAAIAAKng");
	this.shape_1.setTransform(140,34);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib._9_1, new cjs.Rectangle(0,0,280,68), null);


(lib._8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._2pngcopy2, null, new cjs.Matrix2D(1,0,0,1,-742,-780)).s().p("A0nFUIAAqnMApPAAAIAAKng");
	this.shape.setTransform(132,34);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._8, new cjs.Rectangle(0,0,264,68), null);


(lib._7_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(img._2pngcopy2, null, new cjs.Matrix2D(1,0,0,1,-485,-775)).s().p("AzhEiIAApDMAnDAAAIAAJDg");
	this.shape_2.setTransform(124.975,29);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib._7_2, new cjs.Rectangle(0,0,250,58), null);


(lib._6_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(img._2pngcopy2, null, new cjs.Matrix2D(1,0,0,1,-230,-775.5)).s().p("A0TEnIAApNMAonAAAIAAJNg");
	this.shape_1.setTransform(130.025,29.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib._6_1, new cjs.Rectangle(0,0,260.1,59), null);


(lib._5_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(img._2pngcopy2, null, new cjs.Matrix2D(1,0,0,1,-1014,-576)).s().p("A13akMAAAg1HMArvAAAMAAAA1Hg");
	this.shape_2.setTransform(140,170);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib._5_2, new cjs.Rectangle(0,0,280,340), null);


(lib._4_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(img._2pngcopy2, null, new cjs.Matrix2D(1,0,0,1,-742,-576)).s().p("A0nakMAAAg1HMApPAAAMAAAA1Hg");
	this.shape_2.setTransform(132,170);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib._4_2, new cjs.Rectangle(0,0,264,340), null);


(lib._3_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.bf(img._2pngcopy2, null, new cjs.Matrix2D(1,0,0,1,-485,-576)).s().p("AzhakMAAAg1HMAnDAAAMAAAA1Hg");
	this.shape_3.setTransform(124.975,170);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib._3_4, new cjs.Rectangle(0,0,250,340), null);


(lib._2_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.bf(img._2pngcopy2, null, new cjs.Matrix2D(1,0,0,1,-230,-576)).s().p("A0TakMAAAg1HMAonAAAMAAAA1Hg");
	this.shape_3.setTransform(130.025,170);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib._2_4, new cjs.Rectangle(0,0,260.1,340), null);


(lib._1_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.bf(img._2pngcopy2, null, new cjs.Matrix2D(1,0,0,1,-667,-323)).s().p("EhYlAM+IAA57MCxLAAAIAAZ7g");
	this.shape_3.setTransform(567,83);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib._1_4, new cjs.Rectangle(0,0,1134,166), null);


(lib._12_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(img._2pngcopy4, null, new cjs.Matrix2D(1,0,0,1,-692.5,-842.2)).s().p("EhbyAGkIAAtHMC3lAAAIAANHg");
	this.shape_1.setTransform(587.5,42.025);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib._12_1, new cjs.Rectangle(0,0,1175,84.1), null);


(lib._5_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.bf(img._2pngcopy3, null, new cjs.Matrix2D(1,0,0,1,-227,-820)).s().p("AqdK8IAA13IU7AAIAAV3g");
	this.shape_3.setTransform(67,70);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib._5_3, new cjs.Rectangle(0,0,134,140), null);


(lib._4_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.bf(img._2pngcopy3, null, new cjs.Matrix2D(1,0,0,1,-175,-416)).s().p("ArtLkIAA3HIXbAAIAAXHg");
	this.shape_3.setTransform(75,74);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib._4_3, new cjs.Rectangle(0,0,150,148), null);


(lib._3_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.bf(img._2pngcopy3, null, new cjs.Matrix2D(1,0,0,1,-1167,-354)).s().p("AxpL4IAA3vMAjTAAAIAAXvg");
	this.shape_4.setTransform(113,76);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

}).prototype = getMCSymbolPrototype(lib._3_5, new cjs.Rectangle(0,0,226,152), null);


(lib._2_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.bf(img._2pngcopy3, null, new cjs.Matrix2D(1,0,0,1,-367,-250)).s().p("EggVAOYIAA8vMBArAAAIAAcvg");
	this.shape_4.setTransform(207,92);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

}).prototype = getMCSymbolPrototype(lib._2_5, new cjs.Rectangle(0,0,414,184), null);


(lib._1_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.bf(img._2pngcopy3, null, new cjs.Matrix2D(1,0,0,1,-1117,-218)).s().p("A5dJYIAAyvMAy7AAAIAASvg");
	this.shape_4.setTransform(163,60);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

}).prototype = getMCSymbolPrototype(lib._1_5, new cjs.Rectangle(0,0,326,120), null);


(lib._15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._1pngcopy6, null, new cjs.Matrix2D(1,0,0,1,-349.1,-814.7)).s().p("EgmSACbIAAk1MBMlAAAIAAE1g");
	this.shape.setTransform(245.05,15.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._15, new cjs.Rectangle(0,0,490.1,31), null);


(lib._14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._1pngcopy6, null, new cjs.Matrix2D(1,0,0,1,-935.5,-746.4)).s().p("Ap4HAIAAt/ITxAAIAAN/g");
	this.shape.setTransform(63.275,44.775);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._14, new cjs.Rectangle(0,0,126.6,89.6), null);


(lib._13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._1pngcopy6, null, new cjs.Matrix2D(1,0,0,1,-572.1,-745.2)).s().p("AuhHMIAAuXIdDAAIAAOXg");
	this.shape.setTransform(93,46.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._13, new cjs.Rectangle(0,0,186,92.1), null);


(lib._12_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(img._1pngcopy6, null, new cjs.Matrix2D(1,0,0,1,-208.5,-748.7)).s().p("AwAGfIAAs9MAgBAAAIAAM9g");
	this.shape_2.setTransform(102.525,41.525);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib._12_2, new cjs.Rectangle(0,0,205.1,83.1), null);


(lib._11_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(img._1pngcopy6, null, new cjs.Matrix2D(1,0,0,1,-1127.5,-559.1)).s().p("Ay3H0IAAvnMAlvAAAIAAPng");
	this.shape_2.setTransform(120.775,50);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib._11_2, new cjs.Rectangle(0,0,241.6,100), null);


(lib._10_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(img._1pngcopy6, null, new cjs.Matrix2D(1,0,0,1,-1129.3,-451.1)).s().p("AxyJEIgHh6IgxsRQA7hEBIhFQBLhHA5gsMAhNAAAIAASHg");
	this.shape_2.setTransform(119.45,58.025);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib._10_2, new cjs.Rectangle(0,0,238.9,116.1), null);


(lib._9_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(img._1pngcopy6, null, new cjs.Matrix2D(1,0,0,1,-940.2,-493.1)).s().p("Atve9IB9xhIAAweIg3AAIAAswIgxAAIiDu/Ie7gzIgKOFIkiEOIA/PxIhYAAIAABaIibRNIA8Keg");
	this.shape_2.setTransform(99.025,202.05);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib._9_2, new cjs.Rectangle(0,0,198.1,404.1), null);


(lib._8_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(img._1pngcopy6, null, new cjs.Matrix2D(1,0,0,1,-741.2,-526.4)).s().p("AzSIQIAApmIAem5MAmHAAAIAAQfg");
	this.shape_1.setTransform(123.525,52.775);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib._8_1, new cjs.Rectangle(0,0,247.1,105.6), null);


(lib._7_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.bf(img._1pngcopy6, null, new cjs.Matrix2D(1,0,0,1,-740.9,-432.8)).s().p("AySGYIgMkbIAZlpICIirMAicAAAIAAMvg");
	this.shape_3.setTransform(118.275,40.775);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib._7_3, new cjs.Rectangle(0,0,236.6,81.6), null);


(lib._6_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(img._1pngcopy6, null, new cjs.Matrix2D(1,0,0,1,-587.1,-511.1)).s().p("AtRccICCtRMgCMgmnIAKi+INRi+IMCAKIBaIJIlZCgIiHCqIgZFqIAMEbIggAAIhpX1IFALag");
	this.shape_2.setTransform(86,188.05);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib._6_2, new cjs.Rectangle(0,0,172,376.1), null);


(lib._5_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.bf(img._1pngcopy6, null, new cjs.Matrix2D(1,0,0,1,-382.1,-562.6)).s().p("AylHlIAAvJMAlLAAAIAAPJg");
	this.shape_4.setTransform(119.025,48.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

}).prototype = getMCSymbolPrototype(lib._5_4, new cjs.Rectangle(0,0,238.1,97), null);


(lib._4_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.bf(img._1pngcopy6, null, new cjs.Matrix2D(1,0,0,1,-329.5,-480.9)).s().p("AAUA+IhPAAIAAh7IBPAAIAoAAIAAB7g");
	this.shape_4.setTransform(133.975,87.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.bf(img._1pngcopy6, null, new cjs.Matrix2D(1,0,0,1,-426.5,-481.3)).s().p("AjIBRQhfgFhegPIAAgBIAAgCIAoAAIAAh6IgoAAIAAgWIMLAAIAACFQhrAThpALQhpAKhnAAIgGAAQhTAAhRgGg");
	this.shape_5.setTransform(174.95,88.1504);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AGvA0IAAiFIATAAIAACFQh0AVhzAJQBpgLBrgTgAnAA/IgBAAIAAh6IABAAIAAgWIBkAAIAAAWIhQAAIAAB6IBQAAIAAACIhkABg");
	this.shape_6.setTransform(170.85,87.6625);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.bf(img._1pngcopy6, null, new cjs.Matrix2D(1,0,0,1,-381.4,-453.6)).s().p("AyeJdQgyp/B9o6MAkAAAAIAAS5gACjFSQBdAOBfAFQBUAGBWAAQBoAABpgJQBzgKB0gVIAAiGIgTAAIsLAAIhlAAIAAAWIgBAAIAAB7IABAAIAAAEIBlgCg");
	this.shape_7.setTransform(119.7209,60.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib._4_4, new cjs.Rectangle(0,0,239.5,121.1), null);


(lib._3_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.bf(img._1pngcopy6, null, new cjs.Matrix2D(1,0,0,1,-208.5,-513.6)).s().p("AwAePMAAAg8eMAgBAAAIAALbImVAAQh8I6AxKAIAAPJIHgAAIAAPAg");
	this.shape_5.setTransform(102.525,193.55);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

}).prototype = getMCSymbolPrototype(lib._3_6, new cjs.Rectangle(0,0,205.1,387.1), null);


(lib._2_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.bf(img._1pngcopy6, null, new cjs.Matrix2D(1,0,0,1,-468.1,-274.5)).s().p("Eg4kAExIAAphMBxJAAAIAAJhg");
	this.shape_5.setTransform(362.1,30.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

}).prototype = getMCSymbolPrototype(lib._2_6, new cjs.Rectangle(0,0,724.2,61), null);


(lib._1_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.bf(img._1pngcopy6, null, new cjs.Matrix2D(1,0,0,1,-688.9,-516.4)).s().p("EA31A3NMAAAgg+MAjQAAAMAAAAg+gEA6qgV6MAAAghSIfQAAMAAAAhSgEhbEgqiIAAshMA6xAAAIAAMhg");
	this.shape_5.setTransform(582.9,353.325);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

}).prototype = getMCSymbolPrototype(lib._1_6, new cjs.Rectangle(0,0,1165.8,706.7), null);


(lib._5_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.bf(img._2pngcopy5, null, new cjs.Matrix2D(1,0,0,1,-638,-802)).s().p("AvTOEIAA8HIenAAIAAcHg");
	this.shape_5.setTransform(98,90);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

}).prototype = getMCSymbolPrototype(lib._5_5, new cjs.Rectangle(0,0,196,180), null);


(lib._4_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.bf(img._2pngcopy5, null, new cjs.Matrix2D(1,0,0,1,-960,-517)).s().p("Egx/AImIAAxLMBj/AAAIAARLg");
	this.shape_8.setTransform(320,55);

	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(1));

}).prototype = getMCSymbolPrototype(lib._4_5, new cjs.Rectangle(0,0,640,110), null);


(lib._3_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.bf(img._2pngcopy5, null, new cjs.Matrix2D(1,0,0,1,-1167,-215)).s().p("AxpLuIAA3bMAjTAAAIAAXbg");
	this.shape_6.setTransform(113,75);

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

}).prototype = getMCSymbolPrototype(lib._3_7, new cjs.Rectangle(0,0,226,150), null);


(lib._2_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.bf(img._2pngcopy5, null, new cjs.Matrix2D(1,0,0,1,-710,-291)).s().p("Aq7LGIAA2LIV3AAIAAWLg");
	this.shape_6.setTransform(70,71);

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

}).prototype = getMCSymbolPrototype(lib._2_7, new cjs.Rectangle(0,0,140,142), null);


(lib._1_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.bf(img._2pngcopy5, null, new cjs.Matrix2D(1,0,0,1,-1120,-802)).s().p("A4/OEIAA8HMAx/AAAIAAcHg");
	this.shape_6.setTransform(160,90);

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

}).prototype = getMCSymbolPrototype(lib._1_7, new cjs.Rectangle(0,0,320,180), null);


(lib._15_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(img._1pngcopy8, null, new cjs.Matrix2D(1,0,0,1,-348.6,-823.7)).s().p("EgnJADhIAAnBMBOTAAAIAAHBg");
	this.shape_1.setTransform(250.55,22.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib._15_1, new cjs.Rectangle(0,0,501.1,45), null);


(lib._14_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(img._1pngcopy8, null, new cjs.Matrix2D(1,0,0,1,-1165.1,-752.7)).s().p("AuhG9IAAt5IdDAAIAAN5g");
	this.shape_1.setTransform(93.025,44.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib._14_1, new cjs.Rectangle(0,0,186.1,89), null);


(lib._13_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(img._1pngcopy8, null, new cjs.Matrix2D(1,0,0,1,-979,-752.7)).s().p("AuhG9IAAt5IdDAAIAAN5g");
	this.shape_1.setTransform(93,44.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib._13_1, new cjs.Rectangle(0,0,186,89), null);


(lib._12_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.bf(img._1pngcopy8, null, new cjs.Matrix2D(1,0,0,1,-792,-752.7)).s().p("AuiG9IAAt5IdEAAIABN5g");
	this.shape_3.setTransform(93.05,44.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib._12_3, new cjs.Rectangle(0,0,186.1,89), null);


(lib._11_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.bf(img._1pngcopy8, null, new cjs.Matrix2D(1,0,0,1,-597,-752.7)).s().p("AuiG9IAAt5IdEAAIABN5g");
	this.shape_3.setTransform(93.05,44.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib._11_3, new cjs.Rectangle(0,0,186.1,89), null);


(lib._10_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.bf(img._1pngcopy8, null, new cjs.Matrix2D(1,0,0,1,-397,-752.7)).s().p("AuiG9IAAt5IdEAAIABN5g");
	this.shape_3.setTransform(93.05,44.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib._10_3, new cjs.Rectangle(0,0,186.1,89), null);


(lib._9_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.bf(img._1pngcopy8, null, new cjs.Matrix2D(1,0,0,1,-193,-752.7)).s().p("AuiG9IAAt5IdFAAIAAN5g");
	this.shape_3.setTransform(93.05,44.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib._9_3, new cjs.Rectangle(0,0,186.1,89), null);


(lib._8_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(img._1pngcopy8, null, new cjs.Matrix2D(1,0,0,1,-1163,-538.1)).s().p("AuhalMAAAg1JIdDAAMAAAA1Jg");
	this.shape_2.setTransform(93.025,170.05);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib._8_2, new cjs.Rectangle(0,0,186.1,340.1), null);


(lib._7_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.bf(img._1pngcopy8, null, new cjs.Matrix2D(1,0,0,1,-976,-538.1)).s().p("AuXalMAAAg1JIcvAAMAAAA1Jg");
	this.shape_4.setTransform(92,170.05);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

}).prototype = getMCSymbolPrototype(lib._7_4, new cjs.Rectangle(0,0,184,340.1), null);


(lib._6_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.bf(img._1pngcopy8, null, new cjs.Matrix2D(1,0,0,1,-790,-538.1)).s().p("AuXalMAAAg1JIcvAAMAAAA1Jg");
	this.shape_3.setTransform(92,170.05);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib._6_3, new cjs.Rectangle(0,0,184,340.1), null);


(lib._5_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.bf(img._1pngcopy8, null, new cjs.Matrix2D(1,0,0,1,-597,-538.1)).s().p("AuhalMAAAg1JIdDAAMAAAA1Jg");
	this.shape_6.setTransform(93.025,170.05);

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

}).prototype = getMCSymbolPrototype(lib._5_6, new cjs.Rectangle(0,0,186.1,340.1), null);


(lib._4_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.bf(img._1pngcopy8, null, new cjs.Matrix2D(1,0,0,1,-397,-538.1)).s().p("AuhalMAAAg1JIdDAAMAAAA1Jg");
	this.shape_9.setTransform(93.025,170.05);

	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(1));

}).prototype = getMCSymbolPrototype(lib._4_6, new cjs.Rectangle(0,0,186.1,340.1), null);


(lib._3_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.bf(img._1pngcopy8, null, new cjs.Matrix2D(1,0,0,1,-193,-538.1)).s().p("AuhalMAAAg1JIdDAAMAAAA1Jg");
	this.shape_7.setTransform(93.025,170.05);

	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(1));

}).prototype = getMCSymbolPrototype(lib._3_8, new cjs.Rectangle(0,0,186.1,340.1), null);


(lib._2_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.bf(img._1pngcopy8, null, new cjs.Matrix2D(1,0,0,1,-469.1,-297.1)).s().p("Eg0WAJOIAAybMBotAAAIAASbg");
	this.shape_7.setTransform(335.075,59.025);

	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(1));

}).prototype = getMCSymbolPrototype(lib._2_8, new cjs.Rectangle(0,0,670.2,118.1), null);


(lib._1_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.bf(img._1pngcopy8, null, new cjs.Matrix2D(1,0,0,1,-412.1,-199)).s().p("EgxYAGGIAAsLMBixAAAIAAMLg");
	this.shape_7.setTransform(316.1,39);

	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(1));

}).prototype = getMCSymbolPrototype(lib._1_8, new cjs.Rectangle(0,0,632.2,78), null);


(lib._18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._2pngcopy7, null, new cjs.Matrix2D(1,0,0,1,-405,-858)).s().p("EgvpAGkIAAtHMBfTAAAIAANHg");
	this.shape.setTransform(305,12);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._18, new cjs.Rectangle(0,-30,610,84), null);


(lib._17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._2pngcopy7, null, new cjs.Matrix2D(1,0,0,1,-1137.5,-645)).s().p("AtMJ2IAAzrIaZAAIAATrg");
	this.shape.setTransform(155.5,63);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._17, new cjs.Rectangle(71,0,169,126), null);


(lib._16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._2pngcopy7, null, new cjs.Matrix2D(1,0,0,1,-1137.1,-506)).s().p("AtQL4IAA3vIahAAIAAXvg");
	this.shape.setTransform(155.125,76);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._16, new cjs.Rectangle(70.3,0,169.7,152), null);


(lib._15_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(img._2pngcopy7, null, new cjs.Matrix2D(1,0,0,1,-935.1,-681.7)).s().p("Ax+OuIAA9bMAj9AAAIgWdbg");
	this.shape_2.setTransform(126.1,100.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib._15_2, new cjs.Rectangle(11,6,230.2,188.4), null);


(lib._14_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(img._2pngcopy7, null, new cjs.Matrix2D(1,0,0,1,-936,-506)).s().p("AyHL4IAA3vMAkPAAAIAAXvg");
	this.shape_2.setTransform(186,76);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib._14_2, new cjs.Rectangle(70,0,232,152), null);


(lib._13_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.bf(img._2pngcopy7, null, new cjs.Matrix2D(1,0,0,1,-986,-352)).s().p("Egk3AMMIAA4XMAz3AAAIAABQIV4AAIAAXHg");
	this.shape_2.setTransform(236,78);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = getMCSymbolPrototype(lib._13_2, new cjs.Rectangle(0,0,472,156), null);


(lib._12copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._2pngcopy7, null, new cjs.Matrix2D(1,0,0,1,-713.5,-764)).s().p("ArKIwIAAxfIWVAAIAARfg");
	this.shape.setTransform(297.475,56);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._12copy, new cjs.Rectangle(226,0,143,112), null);


(lib._12_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.bf(img._2pngcopy7, null, new cjs.Matrix2D(1,0,0,1,-463,-764)).s().p("Az1IwIAAxfMAnrAAAIAARfg");
	this.shape_4.setTransform(47,56);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

}).prototype = getMCSymbolPrototype(lib._12_4, new cjs.Rectangle(-80,0,254,112), null);


(lib._11_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.bf(img._2pngcopy7, null, new cjs.Matrix2D(1,0,0,1,-206,-764)).s().p("AwjIwIAAxfMAhHAAAIAARfg");
	this.shape_4.setTransform(106,56);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

}).prototype = getMCSymbolPrototype(lib._11_4, new cjs.Rectangle(0,0,212,112), null);


(lib._10_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.bf(img._2pngcopy7, null, new cjs.Matrix2D(1,0,0,1,-614,-395)).s().p("AyHFeIAAq7MAkPAAAIAAK7g");
	this.shape_4.setTransform(76,35);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

}).prototype = getMCSymbolPrototype(lib._10_4, new cjs.Rectangle(-40,0,232,70), null);


(lib._9_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.bf(img._2pngcopy7, null, new cjs.Matrix2D(1,0,0,1,-324,-397)).s().p("A5dFeIAAq7MAy7AAAIAAK7g");
	this.shape_4.setTransform(112,37);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

}).prototype = getMCSymbolPrototype(lib._9_4, new cjs.Rectangle(-51,2,326,70), null);


(lib._8copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._2pngcopy7, null, new cjs.Matrix2D(1,0,0,1,-717.1,-571)).s().p("AqIWCMAAmgsDITrAAMAAAAqzIAABQg");
	this.shape.setTransform(147.075,140.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib._8copy, new cjs.Rectangle(82.2,0,129.8,282), null);


(lib._8_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.bf(img._2pngcopy7, null, new cjs.Matrix2D(1,0,0,1,-590,-569)).s().p("AqJVuMAAAgrbIUTAAMAAAArbg");
	this.shape_3.setTransform(20,139);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = getMCSymbolPrototype(lib._8_3, new cjs.Rectangle(-45,0,130,278), null);


(lib._7_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.bf(img._2pngcopy7, null, new cjs.Matrix2D(1,0,0,1,-461.5,-569)).s().p("AqEVuMAAAgrbIUJAAMAAAArbg");
	this.shape_5.setTransform(25.5,139);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

}).prototype = getMCSymbolPrototype(lib._7_5, new cjs.Rectangle(-39,0,129,278), null);


(lib._6_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.bf(img._2pngcopy7, null, new cjs.Matrix2D(1,0,0,1,-334.5,-569)).s().p("ApwVuMAAAgrbIThAAMAAAArbg");
	this.shape_4.setTransform(42.5,139);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

}).prototype = getMCSymbolPrototype(lib._6_4, new cjs.Rectangle(-20,0,125,278), null);


(lib._5_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.bf(img._2pngcopy7, null, new cjs.Matrix2D(1,0,0,1,-186,-569)).s().p("AtbVuMAAAgrbIa3AAMAAAArbg");
	this.shape_7.setTransform(86,139);

	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(1));

}).prototype = getMCSymbolPrototype(lib._5_7, new cjs.Rectangle(0,0,172,278), null);


(lib._4_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.bf(img._2pngcopy7, null, new cjs.Matrix2D(1,0,0,1,-335,-317)).s().p("EgktAGuIAAtbMBJbAAAIAANbg");
	this.shape_10.setTransform(235,43);

	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(1));

}).prototype = getMCSymbolPrototype(lib._4_7, new cjs.Rectangle(0,0,470,86), null);


(lib._3_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.bf(img._2pngcopy7, null, new cjs.Matrix2D(1,0,0,1,-690,-218)).s().p("EA9QAKAIAAhQMiZbAAAIAAvnMCZbAAAIAAjIIe8AAIAAT/g");
	this.shape_8.setTransform(590,64);

	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(1));

}).prototype = getMCSymbolPrototype(lib._3_9, new cjs.Rectangle(0,0,1180,128), null);


(lib._2_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.bf(img._1pngcopy9, null, new cjs.Matrix2D(1,0,0,1,-1020,-540)).s().p("EgiXAvgMAAAhe/MBEvAAAMAAABe/g");
	this.shape_8.setTransform(288,304.025);

	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(1));

}).prototype = getMCSymbolPrototype(lib._2_9, new cjs.Rectangle(68,0,440,608.1), null);


(lib._1_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.bf(img._1pngcopy9, null, new cjs.Matrix2D(1,0,0,1,-450,-540)).s().p("Eg2rAvgMAAAhe/MBtXAAAMAAABe/g");
	this.shape_8.setTransform(350,304.025);

	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(1));

}).prototype = getMCSymbolPrototype(lib._1_9, new cjs.Rectangle(0,0,700,608.1), null);


(lib._5_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.bf(img._2pngcopy8, null, new cjs.Matrix2D(1,0,0,1,-198,-752)).s().p("AsLJYIAAyvIYXAAIAASvg");
	this.shape_8.setTransform(78,60);

	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(1));

}).prototype = getMCSymbolPrototype(lib._5_8, new cjs.Rectangle(0,0,156,120), null);


(lib._4_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.bf(img._2pngcopy8, null, new cjs.Matrix2D(1,0,0,1,-466,-517)).s().p("A9rImIAAxLMA7XAAAIAARLg");
	this.shape_11.setTransform(190,55);

	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(1));

}).prototype = getMCSymbolPrototype(lib._4_8, new cjs.Rectangle(0,0,380,110), null);


(lib._3_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.bf(img._2pngcopy8, null, new cjs.Matrix2D(1,0,0,1,-1168,-212)).s().p("AxfLQIAA2fMAi/AAAIAAWfg");
	this.shape_9.setTransform(112,72);

	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(1));

}).prototype = getMCSymbolPrototype(lib._3_10, new cjs.Rectangle(0,0,224,144), null);


(lib._2_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.bf(img._2pngcopy8, null, new cjs.Matrix2D(1,0,0,1,-736,-291)).s().p("AsfLGIAA2LIY/AAIAAWLg");
	this.shape_9.setTransform(80,71);

	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(1));

}).prototype = getMCSymbolPrototype(lib._2_10, new cjs.Rectangle(0,0,160,142), null);


(lib._1_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.bf(img._2pngcopy8, null, new cjs.Matrix2D(1,0,0,1,-268,-251)).s().p("A3HRWMAAAgirMAuPAAAMAAAAirg");
	this.shape_9.setTransform(148,111);

	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(1));

}).prototype = getMCSymbolPrototype(lib._1_10, new cjs.Rectangle(0,0,296,222), null);


(lib._10_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.bf(img._2pngcopy9, null, new cjs.Matrix2D(1,0,0,1,-679,-848)).s().p("EhadAIIIAAwPMC07AAAIAAQPg");
	this.shape_5.setTransform(579,52);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

}).prototype = getMCSymbolPrototype(lib._10_5, new cjs.Rectangle(0,0,1158,104), null);


(lib._9_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.bf(img._2pngcopy9, null, new cjs.Matrix2D(1,0,0,1,-1015,-676)).s().p("Egl9AHMIAAuXMBL7AAAIAAOXg");
	this.shape_5.setTransform(243,46);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

}).prototype = getMCSymbolPrototype(lib._9_5, new cjs.Rectangle(0,0,486,92), null);


(lib._8_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.bf(img._2pngcopy9, null, new cjs.Matrix2D(1,0,0,1,-1015,-586)).s().p("Egl9AG4IAAtvMBL7AAAIAANvg");
	this.shape_4.setTransform(243,44);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

}).prototype = getMCSymbolPrototype(lib._8_4, new cjs.Rectangle(0,0,486,88), null);


(lib._7_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.bf(img._2pngcopy9, null, new cjs.Matrix2D(1,0,0,1,-1015,-499)).s().p("Egl9AGuIAAtbMBL7AAAIAANbg");
	this.shape_6.setTransform(243,43);

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

}).prototype = getMCSymbolPrototype(lib._7_6, new cjs.Rectangle(0,0,486,86), null);


(lib._6_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.bf(img._2pngcopy9, null, new cjs.Matrix2D(1,0,0,1,-1015,-412)).s().p("Egl9AG4IAAtvMBL7AAAIAANvg");
	this.shape_5.setTransform(243,44);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

}).prototype = getMCSymbolPrototype(lib._6_5, new cjs.Rectangle(0,0,486,88), null);


(lib._5_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.bf(img._2pngcopy9, null, new cjs.Matrix2D(1,0,0,1,-444,-747)).s().p("AxzHqIAAvTMAjnAAAIAAPTg");
	this.shape_9.setTransform(113.975,49);

	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(1));

}).prototype = getMCSymbolPrototype(lib._5_9, new cjs.Rectangle(0,0,228,98), null);


(lib._4_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.bf(img._2pngcopy9, null, new cjs.Matrix2D(1,0,0,1,-665,-362)).s().p("AwtIcIAAw3MAhbAAAIAAQ3g");
	this.shape_12.setTransform(107,54);

	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(1));

}).prototype = getMCSymbolPrototype(lib._4_9, new cjs.Rectangle(0,0,214,108), null);


(lib._3_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.bf(img._2pngcopy9, null, new cjs.Matrix2D(1,0,0,1,-360,-362)).s().p("Am3IcIAAjbItcAAIAAtcMAonAAAIAAQ3g");
	this.shape_10.setTransform(129.975,54);

	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(1));

}).prototype = getMCSymbolPrototype(lib._3_11, new cjs.Rectangle(0,0,260,108), null);


(lib._2_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.bf(img._2pngcopy9, null, new cjs.Matrix2D(1,0,0,1,-679,-244)).s().p("AOiL4IAAh4Mho/AAAIAA13MC07AAAIAAXvg");
	this.shape_10.setTransform(579,76);

	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(1));

}).prototype = getMCSymbolPrototype(lib._2_11, new cjs.Rectangle(0,0,1158,152), null);


(lib._1_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.bf(img._1pngcopy11, null, new cjs.Matrix2D(1,0,0,1,-410,-510)).s().p("EgwbAg0MAAAhBnMBg3AAAMAAABBng");
	this.shape_10.setTransform(310,210);

	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(1));

}).prototype = getMCSymbolPrototype(lib._1_11, new cjs.Rectangle(0,0,620,420), null);


(lib._4_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.bf(img._2pngcopy10, null, new cjs.Matrix2D(1,0,0,1,-200,-750)).s().p("AsfJsIAAzXIY/AAIAATXg");
	this.shape_13.setTransform(80,62);

	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(1));

}).prototype = getMCSymbolPrototype(lib._4_10, new cjs.Rectangle(0,0,160,124), null);


(lib._3_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.bf(img._2pngcopy10, null, new cjs.Matrix2D(1,0,0,1,-470,-518)).s().p("Eg2rAOEIAA8HMBtXAAAIAAcHg");
	this.shape_11.setTransform(350,90);

	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(1));

}).prototype = getMCSymbolPrototype(lib._3_12, new cjs.Rectangle(0,0,700,180), null);


(lib._2_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.bf(img._2pngcopy10, null, new cjs.Matrix2D(1,0,0,1,-740,-274)).s().p("AsfOsIAA9XIY/AAIAAdXg");
	this.shape_11.setTransform(80,94);

	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(1));

}).prototype = getMCSymbolPrototype(lib._2_12, new cjs.Rectangle(0,0,160,188), null);


(lib._1_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.bf(img._2pngcopy10, null, new cjs.Matrix2D(1,0,0,1,-260,-274)).s().p("A13OsIAA9XMArvAAAIAAdXg");
	this.shape_11.setTransform(140,94);

	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(1));

}).prototype = getMCSymbolPrototype(lib._1_12, new cjs.Rectangle(0,0,280,188), null);


(lib._6_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.bf(img._1pngcopy13, null, new cjs.Matrix2D(1,0,0,1,-391,-842)).s().p("EgsNAK8IAA13MBYbAAAIAAV3g");
	this.shape_6.setTransform(283,10);

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

}).prototype = getMCSymbolPrototype(lib._6_6, new cjs.Rectangle(0,-60,566,140), null);


(lib._5_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.bf(img._1pngcopy13, null, new cjs.Matrix2D(1,0,0,1,-959,-632)).s().p("EgshAPoIAA/PMBZDAAAIAAfPg");
	this.shape_10.setTransform(285,100);

	this.timeline.addTween(cjs.Tween.get(this.shape_10).wait(1));

}).prototype = getMCSymbolPrototype(lib._5_10, new cjs.Rectangle(0,0,570,200), null);


(lib._4_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.bf(img._1pngcopy13, null, new cjs.Matrix2D(1,0,0,1,-391,-632)).s().p("EgsNAPoIAA/PMBYbAAAIAAfPg");
	this.shape_14.setTransform(283,100);

	this.timeline.addTween(cjs.Tween.get(this.shape_14).wait(1));

}).prototype = getMCSymbolPrototype(lib._4_11, new cjs.Rectangle(0,0,566,200), null);


(lib._3_13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.bf(img._1pngcopy13, null, new cjs.Matrix2D(1,0,0,1,-959,-434)).s().p("EgshAPUIAA+nMBZDAAAIAAeng");
	this.shape_12.setTransform(285,98);

	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(1));

}).prototype = getMCSymbolPrototype(lib._3_13, new cjs.Rectangle(0,0,570,196), null);


(lib._2_13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.bf(img._1pngcopy13, null, new cjs.Matrix2D(1,0,0,1,-391,-434)).s().p("EgsNAPUIAA+nMBYbAAAIAAeng");
	this.shape_12.setTransform(283,98);

	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(1));

}).prototype = getMCSymbolPrototype(lib._2_13, new cjs.Rectangle(0,0,566,196), null);


(lib._1_13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.bf(img._1pngcopy13, null, new cjs.Matrix2D(1,0,0,1,-686,-258)).s().p("EhaTAMMIAA4XMC0nAAAIAAYXg");
	this.shape_12.setTransform(578,78);

	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(1));

}).prototype = getMCSymbolPrototype(lib._1_13, new cjs.Rectangle(0,0,1156,156), null);


(lib._6_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.bf(img._2pngcopy12, null, new cjs.Matrix2D(1,0,0,1,-680,-848)).s().p("EhanAH0IAAvnMC1PAAAIAAPng");
	this.shape_7.setTransform(580,50);

	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(1));

}).prototype = getMCSymbolPrototype(lib._6_7, new cjs.Rectangle(0,0,1160,100), null);


(lib._5_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.bf(img._2pngcopy12, null, new cjs.Matrix2D(1,0,0,1,-1063,-544)).s().p("A+xdsMAAAg7XMA9jAAAMAAAA7Xg");
	this.shape_11.setTransform(197,190);

	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(1));

}).prototype = getMCSymbolPrototype(lib._5_11, new cjs.Rectangle(0,0,394,380), null);


(lib._4_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.bf(img._2pngcopy12, null, new cjs.Matrix2D(1,0,0,1,-677,-544)).s().p("A9hdsMAAAg7XMA7DAAAMAAAA7Xg");
	this.shape_15.setTransform(189,190);

	this.timeline.addTween(cjs.Tween.get(this.shape_15).wait(1));

}).prototype = getMCSymbolPrototype(lib._4_12, new cjs.Rectangle(0,0,378,380), null);


(lib._3_14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.bf(img._2pngcopy12, null, new cjs.Matrix2D(1,0,0,1,-294,-544)).s().p("A+TdsMAAAg7XMA8nAAAMAAAA7Xg");
	this.shape_13.setTransform(194,190);

	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(1));

}).prototype = getMCSymbolPrototype(lib._3_14, new cjs.Rectangle(0,0,388,380), null);


(lib._2_14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.bf(img._2pngcopy12, null, new cjs.Matrix2D(1,0,0,1,-677,-300)).s().p("A9hIcIAAw3MA7DAAAIAAQ3g");
	this.shape_13.setTransform(189,54);

	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(1));

}).prototype = getMCSymbolPrototype(lib._2_14, new cjs.Rectangle(0,0,378,108), null);


(lib._1_14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.bf(img._2pngcopy12, null, new cjs.Matrix2D(1,0,0,1,-680,-267)).s().p("AdENmIAAw3Mh3rAAAIAAqUMC1PAAAIAAbLg");
	this.shape_13.setTransform(580,87);

	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(1));

}).prototype = getMCSymbolPrototype(lib._1_14, new cjs.Rectangle(0,0,1160,174), null);


(lib._8_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.bf(img._2, null, new cjs.Matrix2D(1,0,0,1,-654,-856)).s().p("EhNLAH0IAAvnMCaXAAAIAAPng");
	this.shape_5.setTransform(494,50);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

}).prototype = getMCSymbolPrototype(lib._8_5, new cjs.Rectangle(0,0,988,100), null);


(lib._7_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.bf(img._2, null, new cjs.Matrix2D(1,0,0,1,-727,-703)).s().p("EgzFAQGMAAAggLMBmLAAAMAAAAgLg");
	this.shape_7.setTransform(327,103);

	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(1));

}).prototype = getMCSymbolPrototype(lib._7_7, new cjs.Rectangle(0,0,654,206), null);


(lib._6_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.bf(img._2, null, new cjs.Matrix2D(1,0,0,1,-1204,-683)).s().p("EgIvAi2IAAvoIjIAAMAAAg2DIXvAAMAAABFrg");
	this.shape_8.setTransform(76,223);

	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(1));

}).prototype = getMCSymbolPrototype(lib._6_8, new cjs.Rectangle(0,0,152,446), null);


(lib._5_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.bf(img._2, null, new cjs.Matrix2D(1,0,0,1,-80,-703)).s().p("AsfQGMAAAggLIY/AAMAAAAgLg");
	this.shape_12.setTransform(80,103);

	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(1));

}).prototype = getMCSymbolPrototype(lib._5_12, new cjs.Rectangle(0,0,160,206), null);


(lib._4_13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.bf(img._2, null, new cjs.Matrix2D(1,0,0,1,-280,-510)).s().p("AyvakMAAAg1HMAlfAAAMAAAA1Hg");
	this.shape_16.setTransform(120,170);

	this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(1));

}).prototype = getMCSymbolPrototype(lib._4_13, new cjs.Rectangle(0,0,240,340), null);


(lib._3_15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.bf(img._2, null, new cjs.Matrix2D(1,0,0,1,-1174,-260)).s().p("AnLMgIAA4/IOXAAIAAY/g");
	this.shape_14.setTransform(46,80);

	this.timeline.addTween(cjs.Tween.get(this.shape_14).wait(1));

}).prototype = getMCSymbolPrototype(lib._3_15, new cjs.Rectangle(0,0,92,160), null);


(lib._2_15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.bf(img._2, null, new cjs.Matrix2D(1,0,0,1,-1007,-260)).s().p("AnVMgIAA4/IOrAAIAAY/g");
	this.shape_14.setTransform(47,80);

	this.timeline.addTween(cjs.Tween.get(this.shape_14).wait(1));

}).prototype = getMCSymbolPrototype(lib._2_15, new cjs.Rectangle(0,0,94,160), null);


(lib._1_15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.bf(img._2, null, new cjs.Matrix2D(1,0,0,1,-1091,-260)).s().p("AlxMgIAA4/ILjAAIAAY/g");
	this.shape_14.setTransform(37,80);

	this.timeline.addTween(cjs.Tween.get(this.shape_14).wait(1));

}).prototype = getMCSymbolPrototype(lib._1_15, new cjs.Rectangle(0,0,74,160), null);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib._12_2();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.759,0.759,0,0,0,102.5,41.5);
	this.instance.alpha = 0;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D4D4D4").s().p("AgsAZIgFgdQAAgLASgPQARgPAOgEQAgANASAbQAAANgMAQQgOAUgYAKQgdgKgPgPg");
	this.shape.setTransform(33.5,-12.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-77.8,-31.5,155.7,63.1);


(lib.Slide101 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{viewSlide00:43,end00:45});

	// _2
	this.instance = new lib._12_1();
	this.instance.parent = this;
	this.instance.setTransform(692.5,882.2,1,1,0,0,0,587.5,42);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(25).to({_off:false},0).to({y:842.2,alpha:1},11,cjs.Ease.get(1)).wait(14));

	// _1
	this.instance_1 = new lib._11();
	this.instance_1.parent = this;
	this.instance_1.setTransform(797.65,746.9,0.919,0.919,0,0,0,74,38.9);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(22).to({_off:false},0).to({scaleX:1,scaleY:1,alpha:1},11,cjs.Ease.get(1)).wait(17));

	// _
	this.instance_2 = new lib._7();
	this.instance_2.parent = this;
	this.instance_2.setTransform(277.05,749.1,0.8915,0.8915,0,0,0,103.5,46.1);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(19).to({_off:false},0).to({scaleX:1,scaleY:1,alpha:1},11,cjs.Ease.get(1)).wait(20));

	// _
	this.instance_3 = new lib._6();
	this.instance_3.parent = this;
	this.instance_3.setTransform(1091.45,562.35,1,1,0,0,0,137.2,49.2);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(16).to({_off:false},0).to({x:1051.45,alpha:1},11,cjs.Ease.get(1)).wait(23));

	// _
	this.instance_4 = new lib._5();
	this.instance_4.parent = this;
	this.instance_4.setTransform(1080.7,451.6,1,1,0,0,0,126.1,57.1);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(13).to({_off:false},0).to({x:1040.7,alpha:1},11,cjs.Ease.get(1)).wait(26));

	// _
	this.instance_5 = new lib._4();
	this.instance_5.parent = this;
	this.instance_5.setTransform(796.2,541.05,1,1,0,0,0,120,207);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(11).to({_off:false},0).to({y:501.05,alpha:1},11,cjs.Ease.get(1)).wait(28));

	// _
	this.instance_6 = new lib._3_1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(544.6,553.35,1,1,0,0,0,142.5,52.2);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(8).to({_off:false},0).to({x:504.6,alpha:1},11,cjs.Ease.get(1)).wait(31));

	// _
	this.instance_7 = new lib._2_1();
	this.instance_7.parent = this;
	this.instance_7.setTransform(544.6,434.3,1,1,0,0,0,142.5,56.2);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(5).to({_off:false},0).to({x:504.6,alpha:1},11,cjs.Ease.get(1)).wait(34));

	// _
	this.instance_8 = new lib._1_1();
	this.instance_8.parent = this;
	this.instance_8.setTransform(248.05,547.55,1,1,0,0,0,114,195.5);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(2).to({_off:false},0).to({y:507.55,alpha:1},11,cjs.Ease.get(1)).wait(37));

	// Layer_13
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._2pngcopy4, null, new cjs.Matrix2D(1,0,0,1,-914.7,-609.3)).s().p("AgEAYIAAgvIAEAXIAFAYg");
	this.shape.setTransform(914.7375,609.2625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(50));

	// Layer_14
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(img._2pngcopy4, null, new cjs.Matrix2D(1,0,0,1,-914.6,-394.7)).s().p("AAAgBIAAAAIAAADg");
	this.shape_1.setTransform(914.6375,394.6625);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(50));

	// Layer_6
	this.instance_9 = new lib._1pngcopy5();
	this.instance_9.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(50));

	// ________EditBox_______
	this.instance_10 = new lib.EditBox();
	this.instance_10.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(50));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1316.1,960);


(lib.Slide14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"viewSlide00":38,"end00":40});

	// _2
	this.instance = new lib._12();
	this.instance.parent = this;
	this.instance.setTransform(355.65,860.2,1,1,0,0,0,260.6,20);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(26).to({_off:false},0).to({y:820.2,alpha:1},11,cjs.Ease.get(1)).wait(8));

	// _1
	this.instance_1 = new lib._11_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(1076.3,632.15,1,1,0,0,0,203.1,55);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(23).to({_off:false},0).to({x:1036.3,alpha:1},11,cjs.Ease.get(1)).wait(11));

	// _0
	this.instance_2 = new lib._10();
	this.instance_2.parent = this;
	this.instance_2.setTransform(705.15,660.15,1,1,0,0,0,168,132);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(20).to({_off:false},0).to({x:665.15,alpha:1},11,cjs.Ease.get(1)).wait(14));

	// _
	this.instance_3 = new lib._9();
	this.instance_3.parent = this;
	this.instance_3.setTransform(352.65,639.65,1,1,0,0,0,184.6,111.5);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(17).to({_off:false},0).to({x:312.65,alpha:1},11,cjs.Ease.get(1)).wait(17));

	// _
	this.instance_4 = new lib._7_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(1148.25,380.05,1,1,0,0,0,147,56);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(14).to({_off:false},0).to({x:1108.25,alpha:1},11,cjs.Ease.get(1)).wait(20));

	// Symbol_1
	this.instance_5 = new lib.Symbol1();
	this.instance_5.parent = this;
	this.instance_5.setTransform(938.2,407.05,1,1,0,0,0,87,121);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(11).to({_off:false},0).to({y:367.05,alpha:1},11,cjs.Ease.get(1)).wait(23));

	// _
	this.instance_6 = new lib._5_1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(762.15,409.55,1,1,0,0,0,89,123.5);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(8).to({_off:false},0).to({y:369.55,alpha:1},11,cjs.Ease.get(1)).wait(26));

	// _
	this.instance_7 = new lib._3_2();
	this.instance_7.parent = this;
	this.instance_7.setTransform(490.2,392.55,1,1,0,0,0,182.1,68.5);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(5).to({_off:false},0).to({x:450.2,alpha:1},11,cjs.Ease.get(1)).wait(29));

	// _
	this.instance_8 = new lib._2_2();
	this.instance_8.parent = this;
	this.instance_8.setTransform(228.55,407.55,1,1,0,0,0,100.5,120.5);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(2).to({_off:false},0).to({y:367.55,alpha:1},11,cjs.Ease.get(1)).wait(32));

	// _
	this.instance_9 = new lib._1_2();
	this.instance_9.parent = this;
	this.instance_9.setTransform(654.1,549.65,1,1,0,0,0,565.1,376.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(45));

	// Layer_6
	this.instance_10 = new lib._1pngcopy14();
	this.instance_10.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(45));

	// ________EditBox_______
	this.instance_11 = new lib.EditBox();
	this.instance_11.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(45));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1316.1,960);


(lib.Slide13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"viewSlide00":32,"end00":34});

	// _
	this.instance = new lib._4_1();
	this.instance.parent = this;
	this.instance.setTransform(176,416,0.375,0.375,0,0,0,76,64);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(6).to({_off:false},0).wait(1).to({scaleX:0.4748,scaleY:0.4748,alpha:0.1597},0).wait(1).to({scaleX:0.566,scaleY:0.566,x:175.95,y:415.95,alpha:0.3056},0).wait(1).to({scaleX:0.6484,scaleY:0.6484,x:176,y:416,alpha:0.4375},0).wait(1).to({scaleX:0.7222,scaleY:0.7222,y:415.95,alpha:0.5556},0).wait(1).to({scaleX:0.7873,scaleY:0.7873,y:416,alpha:0.6597},0).wait(1).to({scaleX:0.8438,scaleY:0.8438,alpha:0.75},0).wait(1).to({scaleX:0.8915,scaleY:0.8915,x:175.95,y:415.95,alpha:0.8264},0).wait(1).to({scaleX:0.9306,scaleY:0.9306,alpha:0.8889},0).wait(1).to({scaleX:0.9609,scaleY:0.9609,x:176,y:416,alpha:0.9375},0).wait(1).to({scaleX:0.9826,scaleY:0.9826,alpha:0.9722},0).wait(1).to({scaleX:0.9957,scaleY:0.9957,x:175.95,y:415.95,alpha:0.9931},0).wait(1).to({scaleX:1,scaleY:1,x:176,y:416,alpha:1},0).wait(21));

	// _
	this.instance_1 = new lib._3_3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(1166,351,0.3623,0.3623,0,0,0,114,69);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4).to({_off:false},0).wait(1).to({scaleX:0.4642,scaleY:0.4642,x:1165.95,alpha:0.1597},0).wait(1).to({scaleX:0.5572,scaleY:0.5572,alpha:0.3056},0).wait(1).to({scaleX:0.6413,scaleY:0.6413,alpha:0.4375},0).wait(1).to({scaleX:0.7166,scaleY:0.7166,x:1166,alpha:0.5556},0).wait(1).to({scaleX:0.783,scaleY:0.783,x:1165.95,alpha:0.6597},0).wait(1).to({scaleX:0.8406,scaleY:0.8406,x:1166,alpha:0.75},0).wait(1).to({scaleX:0.8893,scaleY:0.8893,y:350.95,alpha:0.8264},0).wait(1).to({scaleX:0.9291,scaleY:0.9291,x:1165.95,alpha:0.8889},0).wait(1).to({scaleX:0.9601,scaleY:0.9601,y:351,alpha:0.9375},0).wait(1).to({scaleX:0.9823,scaleY:0.9823,x:1166,alpha:0.9722},0).wait(1).to({scaleX:0.9956,scaleY:0.9956,alpha:0.9931},0).wait(1).to({scaleX:1,scaleY:1,alpha:1},0).wait(23));

	// _
	this.instance_2 = new lib._2_3();
	this.instance_2.parent = this;
	this.instance_2.setTransform(446,257,1,1,0,0,0,286,95);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2).to({_off:false},0).wait(1).to({x:436.4,alpha:0.1597},0).wait(1).to({x:427.65,alpha:0.3056},0).wait(1).to({x:419.75,alpha:0.4375},0).wait(1).to({x:412.65,alpha:0.5556},0).wait(1).to({x:406.4,alpha:0.6597},0).wait(1).to({x:401,alpha:0.75},0).wait(1).to({x:396.4,alpha:0.8264},0).wait(1).to({x:392.65,alpha:0.8889},0).wait(1).to({x:389.75,alpha:0.9375},0).wait(1).to({x:387.65,alpha:0.9722},0).wait(1).to({x:386.4,alpha:0.9931},0).wait(1).to({x:386,alpha:1},0).wait(25));

	// _
	this.instance_3 = new lib._1_3();
	this.instance_3.parent = this;
	this.instance_3.setTransform(1126,222,1,1,0,0,0,154,60);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(39));

	// Layer_6
	this.instance_4 = new lib._1pngcopy2();
	this.instance_4.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(39));

	// ________EditBox_______
	this.instance_5 = new lib.EditBox();
	this.instance_5.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(39));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1316.1,960);


(lib.Slide12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"viewSlide00":32,"end00":34});

	// _0
	this.instance = new lib._10_1();
	this.instance.parent = this;
	this.instance.setTransform(355,910,1,1,0,0,0,255,30);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20).to({_off:false},0).to({y:870,alpha:1},12,cjs.Ease.get(1)).wait(7));

	// _
	this.instance_1 = new lib._9_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(1014,780,0.5882,0.5882,0,0,0,140,34);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(18).to({_off:false},0).to({scaleX:1,scaleY:1,alpha:1},12,cjs.Ease.get(1)).wait(9));

	// _
	this.instance_2 = new lib._8();
	this.instance_2.parent = this;
	this.instance_2.setTransform(742,780,0.5882,0.5882,0,0,0,132,34);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(16).to({_off:false},0).to({scaleX:1,scaleY:1,alpha:1},12,cjs.Ease.get(1)).wait(11));

	// _
	this.instance_3 = new lib._7_2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(485.05,780,0.5294,0.5294,0,0,0,125,34);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(14).to({_off:false},0).to({scaleX:1,scaleY:1,alpha:1},12,cjs.Ease.get(1)).wait(13));

	// _
	this.instance_4 = new lib._6_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(230,780,0.4706,0.4706,0,0,0,130.1,34);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(12).to({_off:false},0).to({regX:130,scaleX:1,scaleY:1,alpha:1},12,cjs.Ease.get(1)).wait(15));

	// _
	this.instance_5 = new lib._5_2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(1014,636,1,1,0,0,0,140,170);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(10).to({_off:false},0).to({y:576,alpha:1},12,cjs.Ease.get(1)).wait(17));

	// _
	this.instance_6 = new lib._4_2();
	this.instance_6.parent = this;
	this.instance_6.setTransform(742,636,1,1,0,0,0,132,170);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(8).to({_off:false},0).to({y:576,alpha:1},12,cjs.Ease.get(1)).wait(19));

	// _
	this.instance_7 = new lib._3_4();
	this.instance_7.parent = this;
	this.instance_7.setTransform(485.05,636,1,1,0,0,0,125,170);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(6).to({_off:false},0).to({y:576,alpha:1},12,cjs.Ease.get(1)).wait(21));

	// _
	this.instance_8 = new lib._2_4();
	this.instance_8.parent = this;
	this.instance_8.setTransform(230,636,1,1,0,0,0,130,170);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(4).to({_off:false},0).to({y:576,alpha:1},12,cjs.Ease.get(1)).wait(23));

	// _
	this.instance_9 = new lib._1_4();
	this.instance_9.parent = this;
	this.instance_9.setTransform(666.95,323,0.7831,0.7831,0,0,0,567,83);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(2).to({_off:false},0).to({scaleX:1,scaleY:1,x:667,alpha:1},12,cjs.Ease.get(1)).wait(25));

	// Слой_3
	this.instance_10 = new lib._1pngcopy3();
	this.instance_10.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(39));

	// Layer_6
	this.instance_11 = new lib._1pngcopy14();
	this.instance_11.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(39));

	// ________EditBox_______
	this.instance_12 = new lib.EditBox();
	this.instance_12.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(39));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1316.1,960);


(lib.Slide11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"viewSlide00":32,"end00":34});

	// _
	this.instance = new lib._5_3();
	this.instance.parent = this;
	this.instance.setTransform(227,820,0.2246,0.2246,0,0,0,67,69.9);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(8).to({_off:false},0).wait(1).to({regY:70,scaleX:0.3485,scaleY:0.3485,alpha:0.1597},0).wait(1).to({scaleX:0.4615,scaleY:0.4615,x:226.95,alpha:0.3056},0).wait(1).to({scaleX:0.5639,scaleY:0.5639,x:227,alpha:0.4375},0).wait(1).to({scaleX:0.6554,scaleY:0.6554,x:226.95,y:820.05,alpha:0.5556},0).wait(1).to({scaleX:0.7362,scaleY:0.7362,alpha:0.6597},0).wait(1).to({scaleX:0.8062,scaleY:0.8062,y:820.1,alpha:0.75},0).wait(1).to({scaleX:0.8654,scaleY:0.8654,x:227,alpha:0.8264},0).wait(1).to({scaleX:0.9138,scaleY:0.9138,y:820.05,alpha:0.8889},0).wait(1).to({scaleX:0.9515,scaleY:0.9515,x:226.95,alpha:0.9375},0).wait(1).to({scaleX:0.9785,scaleY:0.9785,y:820.1,alpha:0.9722},0).wait(1).to({scaleX:0.9946,scaleY:0.9946,x:227,y:820.05,alpha:0.9931},0).wait(1).to({scaleX:1,scaleY:1,y:820,alpha:1},0).wait(19));

	// _
	this.instance_1 = new lib._4_3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(175,416,0.28,0.28,0,0,0,75,74);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(6).to({_off:false},0).wait(1).to({scaleX:0.395,scaleY:0.395,x:174.95,alpha:0.1597},0).wait(1).to({scaleX:0.5,scaleY:0.5,x:175,alpha:0.3056},0).wait(1).to({scaleX:0.595,scaleY:0.595,x:174.95,y:416.05,alpha:0.4375},0).wait(1).to({scaleX:0.68,scaleY:0.68,x:175,y:416,alpha:0.5556},0).wait(1).to({scaleX:0.755,scaleY:0.755,x:174.95,alpha:0.6597},0).wait(1).to({scaleX:0.82,scaleY:0.82,x:175,y:416.05,alpha:0.75},0).wait(1).to({scaleX:0.875,scaleY:0.875,x:174.95,y:416,alpha:0.8264},0).wait(1).to({scaleX:0.92,scaleY:0.92,x:175,y:416.05,alpha:0.8889},0).wait(1).to({scaleX:0.955,scaleY:0.955,x:174.95,y:416,alpha:0.9375},0).wait(1).to({scaleX:0.98,scaleY:0.98,x:175,alpha:0.9722},0).wait(1).to({scaleX:0.995,scaleY:0.995,x:174.95,y:416.05,alpha:0.9931},0).wait(1).to({scaleX:1,scaleY:1,x:175,y:416,alpha:1},0).wait(21));

	// _
	this.instance_2 = new lib._3_5();
	this.instance_2.parent = this;
	this.instance_2.setTransform(1167,354,0.3165,0.3165,0,0,0,113,76);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(4).to({_off:false},0).wait(1).to({scaleX:0.4256,scaleY:0.4256,alpha:0.1597},0).wait(1).to({scaleX:0.5253,scaleY:0.5253,y:353.95,alpha:0.3056},0).wait(1).to({scaleX:0.6155,scaleY:0.6155,y:354,alpha:0.4375},0).wait(1).to({scaleX:0.6962,scaleY:0.6962,y:353.95,alpha:0.5556},0).wait(1).to({scaleX:0.7674,scaleY:0.7674,alpha:0.6597},0).wait(1).to({scaleX:0.8291,scaleY:0.8291,x:1167.05,alpha:0.75},0).wait(1).to({scaleX:0.8813,scaleY:0.8813,y:354,alpha:0.8264},0).wait(1).to({scaleX:0.9241,scaleY:0.9241,x:1167,alpha:0.8889},0).wait(1).to({scaleX:0.9573,scaleY:0.9573,y:353.95,alpha:0.9375},0).wait(1).to({scaleX:0.981,scaleY:0.981,alpha:0.9722},0).wait(1).to({scaleX:0.9953,scaleY:0.9953,y:354,alpha:0.9931},0).wait(1).to({scaleX:1,scaleY:1,alpha:1},0).wait(23));

	// _
	this.instance_3 = new lib._2_5();
	this.instance_3.parent = this;
	this.instance_3.setTransform(427,250,1,1,0,0,0,207,92);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(2).to({_off:false},0).wait(1).to({x:417.4,alpha:0.1597},0).wait(1).to({x:408.65,alpha:0.3056},0).wait(1).to({x:400.75,alpha:0.4375},0).wait(1).to({x:393.65,alpha:0.5556},0).wait(1).to({x:387.4,alpha:0.6597},0).wait(1).to({x:382,alpha:0.75},0).wait(1).to({x:377.4,alpha:0.8264},0).wait(1).to({x:373.65,alpha:0.8889},0).wait(1).to({x:370.75,alpha:0.9375},0).wait(1).to({x:368.65,alpha:0.9722},0).wait(1).to({x:367.4,alpha:0.9931},0).wait(1).to({x:367,alpha:1},0).wait(25));

	// _
	this.instance_4 = new lib._1_5();
	this.instance_4.parent = this;
	this.instance_4.setTransform(1117,218,1,1,0,0,0,163,60);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(39));

	// Layer_6
	this.instance_5 = new lib._1pngcopy4();
	this.instance_5.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(39));

	// ________EditBox_______
	this.instance_6 = new lib.EditBox();
	this.instance_6.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(39));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1316.1,960);


(lib.Slide10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"viewSlide00":43,"end00":45});

	// _5
	this.instance = new lib._15();
	this.instance.parent = this;
	this.instance.setTransform(349.15,854.7,1,1,0,0,0,245.1,15.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(32).to({_off:false},0).to({y:814.7,alpha:1},11).wait(7));

	// _4
	this.instance_1 = new lib._14();
	this.instance_1.parent = this;
	this.instance_1.setTransform(935.4,746.45,0.8548,0.8548,0,0,0,63.2,44.8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(27).to({_off:false},0).to({scaleX:1,scaleY:1,alpha:1},11).wait(12));

	// _3
	this.instance_2 = new lib._13();
	this.instance_2.parent = this;
	this.instance_2.setTransform(572.15,745.15,0.8044,0.8044,0,0,0,93,46);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(25).to({_off:false},0).to({scaleX:1,scaleY:1,alpha:1},11).wait(14));

	// _2
	this.instance_3 = new lib.Tween1("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(208.5,748.65);
	this.instance_3._off = true;

	this.instance_4 = new lib._12_2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(208.5,748.65,1,1,0,0,0,102.5,41.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},23).to({state:[{t:this.instance_4}]},11).wait(16));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(23).to({_off:false},0).to({_off:true,regX:102.5,regY:41.5,mode:"independent"},11).wait(16));

	// _1
	this.instance_5 = new lib._11_2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(1167.55,559.15,1,1,0,0,0,120.8,50);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(21).to({_off:false},0).to({x:1127.55,alpha:1},11).wait(18));

	// _0
	this.instance_6 = new lib._10_2();
	this.instance_6.parent = this;
	this.instance_6.setTransform(1169.4,451.1,1,1,0,0,0,119.5,58);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(19).to({_off:false},0).to({x:1129.4,alpha:1},11).wait(20));

	// _
	this.instance_7 = new lib._9_2();
	this.instance_7.parent = this;
	this.instance_7.setTransform(940.2,533.15,1,1,0,0,0,99,202.1);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(17).to({_off:false},0).to({y:493.15,alpha:1},11).wait(22));

	// _
	this.instance_8 = new lib._8_1();
	this.instance_8.parent = this;
	this.instance_8.setTransform(781.15,526.4,1,1,0,0,0,123.5,52.8);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(15).to({_off:false},0).to({x:741.15,alpha:1},11).wait(24));

	// _
	this.instance_9 = new lib._7_3();
	this.instance_9.parent = this;
	this.instance_9.setTransform(780.85,432.85,1,1,0,0,0,118.2,40.8);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(13).to({_off:false},0).to({x:740.85,alpha:1},11).wait(26));

	// _
	this.instance_10 = new lib._6_2();
	this.instance_10.parent = this;
	this.instance_10.setTransform(587.15,551.15,1,1,0,0,0,86,188.1);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(11).to({_off:false},0).to({y:511.15,alpha:1},11).wait(28));

	// _
	this.instance_11 = new lib._5_4();
	this.instance_11.parent = this;
	this.instance_11.setTransform(422.05,562.65,1,1,0,0,0,119,48.5);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(9).to({_off:false},0).to({x:382.05,alpha:1},11).wait(30));

	// _
	this.instance_12 = new lib._4_4();
	this.instance_12.parent = this;
	this.instance_12.setTransform(421.35,453.6,1,1,0,0,0,119.7,60.5);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(7).to({_off:false},0).to({x:381.35,alpha:1},11).wait(32));

	// _
	this.instance_13 = new lib._3_6();
	this.instance_13.parent = this;
	this.instance_13.setTransform(208.5,553.65,1,1,0,0,0,102.5,193.6);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(5).to({_off:false},0).to({y:513.65,alpha:1},11).wait(34));

	// _
	this.instance_14 = new lib._2_6();
	this.instance_14.parent = this;
	this.instance_14.setTransform(428.1,274.55,1,1,0,0,0,362.1,30.5);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(3).to({_off:false},0).to({x:468.1,alpha:1},11).wait(36));

	// _
	this.instance_15 = new lib._1_6();
	this.instance_15.parent = this;
	this.instance_15.setTransform(688.9,516.35,1,1,0,0,0,582.9,353.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(50));

	// Layer_6
	this.instance_16 = new lib._1pngcopy14();
	this.instance_16.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(50));

	// ________EditBox_______
	this.instance_17 = new lib.EditBox();
	this.instance_17.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(50));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1316.1,960);


(lib.Slide09 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"viewSlide00":30,"end00":32});

	// _
	this.instance = new lib._5_5();
	this.instance.parent = this;
	this.instance.setTransform(638,802,0.4699,0.4699,0,0,0,98,90);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(8).to({_off:false},0).wait(1).to({scaleX:0.5546,scaleY:0.5546,y:801.95,alpha:0.1597},0).wait(1).to({scaleX:0.6319,scaleY:0.6319,x:637.95,alpha:0.3056},0).wait(1).to({scaleX:0.7018,scaleY:0.7018,x:638,alpha:0.4375},0).wait(1).to({scaleX:0.7644,scaleY:0.7644,x:637.95,y:802,alpha:0.5556},0).wait(1).to({scaleX:0.8196,scaleY:0.8196,y:801.95,alpha:0.6597},0).wait(1).to({scaleX:0.8675,scaleY:0.8675,alpha:0.75},0).wait(1).to({scaleX:0.908,scaleY:0.908,x:638,alpha:0.8264},0).wait(1).to({scaleX:0.9411,scaleY:0.9411,y:802,alpha:0.8889},0).wait(1).to({scaleX:0.9669,scaleY:0.9669,x:637.95,y:801.95,alpha:0.9375},0).wait(1).to({scaleX:0.9853,scaleY:0.9853,alpha:0.9722},0).wait(1).to({scaleX:0.9963,scaleY:0.9963,x:638,alpha:0.9931},0).wait(1).to({scaleX:1,scaleY:1,y:802,alpha:1},0).wait(19));

	// _
	this.instance_1 = new lib._4_5();
	this.instance_1.parent = this;
	this.instance_1.setTransform(960,577,1,1,0,0,0,320,55);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(6).to({_off:false},0).wait(1).to({y:567.4,alpha:0.1597},0).wait(1).to({y:558.65,alpha:0.3056},0).wait(1).to({y:550.75,alpha:0.4375},0).wait(1).to({y:543.65,alpha:0.5556},0).wait(1).to({y:537.4,alpha:0.6597},0).wait(1).to({y:532,alpha:0.75},0).wait(1).to({y:527.4,alpha:0.8264},0).wait(1).to({y:523.65,alpha:0.8889},0).wait(1).to({y:520.75,alpha:0.9375},0).wait(1).to({y:518.65,alpha:0.9722},0).wait(1).to({y:517.4,alpha:0.9931},0).wait(1).to({y:517,alpha:1},0).wait(21));

	// _
	this.instance_2 = new lib._3_7();
	this.instance_2.parent = this;
	this.instance_2.setTransform(1167,215,0.4667,0.4667,0,0,0,113,75);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(4).to({_off:false},0).wait(1).to({scaleX:0.5518,scaleY:0.5518,x:1166.95,alpha:0.1597},0).wait(1).to({scaleX:0.6296,scaleY:0.6296,y:214.95,alpha:0.3056},0).wait(1).to({scaleX:0.7,scaleY:0.7,y:215,alpha:0.4375},0).wait(1).to({scaleX:0.763,scaleY:0.763,y:214.95,alpha:0.5556},0).wait(1).to({scaleX:0.8185,scaleY:0.8185,y:215,alpha:0.6597},0).wait(1).to({scaleX:0.8667,scaleY:0.8667,alpha:0.75},0).wait(1).to({scaleX:0.9074,scaleY:0.9074,y:214.95,alpha:0.8264},0).wait(1).to({scaleX:0.9407,scaleY:0.9407,alpha:0.8889},0).wait(1).to({scaleX:0.9667,scaleY:0.9667,y:215,alpha:0.9375},0).wait(1).to({scaleX:0.9852,scaleY:0.9852,alpha:0.9722},0).wait(1).to({scaleX:0.9963,scaleY:0.9963,y:214.95,alpha:0.9931},0).wait(1).to({scaleX:1,scaleY:1,x:1167,y:215,alpha:1},0).wait(23));

	// _
	this.instance_3 = new lib._2_7();
	this.instance_3.parent = this;
	this.instance_3.setTransform(710,291,0.4286,0.4286,0,0,0,70,71);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(2).to({_off:false},0).wait(1).to({scaleX:0.5198,scaleY:0.5198,y:290.95,alpha:0.1597},0).wait(1).to({scaleX:0.6032,scaleY:0.6032,x:709.95,y:290.9,alpha:0.3056},0).wait(1).to({scaleX:0.6786,scaleY:0.6786,x:710,y:290.95,alpha:0.4375},0).wait(1).to({scaleX:0.746,scaleY:0.746,x:709.95,y:290.9,alpha:0.5556},0).wait(1).to({scaleX:0.8056,scaleY:0.8056,x:710,y:290.95,alpha:0.6597},0).wait(1).to({scaleX:0.8571,scaleY:0.8571,alpha:0.75},0).wait(1).to({scaleX:0.9008,scaleY:0.9008,x:709.95,y:290.9,alpha:0.8264},0).wait(1).to({scaleX:0.9365,scaleY:0.9365,y:290.95,alpha:0.8889},0).wait(1).to({scaleX:0.9643,scaleY:0.9643,x:710,y:290.9,alpha:0.9375},0).wait(1).to({scaleX:0.9841,scaleY:0.9841,alpha:0.9722},0).wait(1).to({scaleX:0.996,scaleY:0.996,x:709.95,alpha:0.9931},0).wait(1).to({scaleX:1,scaleY:1,x:710,y:291,alpha:1},0).wait(25));

	// _
	this.instance_4 = new lib._1_7();
	this.instance_4.parent = this;
	this.instance_4.setTransform(1120,802,1,1,0,0,0,160,90);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(39));

	// Layer_6
	this.instance_5 = new lib._1pngcopy7();
	this.instance_5.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(39));

	// ________EditBox_______
	this.instance_6 = new lib.EditBox();
	this.instance_6.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(39));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1316.1,960);


(lib.Slide08 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"viewSlide00":41,"end00":43});

	// Слой_3
	this.instance = new lib._2pngcopy6();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(51));

	// _5
	this.instance_1 = new lib._15_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(348.65,863.7,1,1,0,0,0,250.6,22.5);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(30).to({_off:false},0).to({y:823.7,alpha:1},11,cjs.Ease.get(1)).wait(10));

	// _4
	this.instance_2 = new lib._14_1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(1165.05,792.7,1,1,0,0,0,93,44.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(28).to({_off:false},0).to({y:752.7,alpha:1},11,cjs.Ease.get(1)).wait(12));

	// _3
	this.instance_3 = new lib._13_1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(979,792.7,1,1,0,0,0,93,44.5);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(26).to({_off:false},0).to({y:752.7,alpha:1},11,cjs.Ease.get(1)).wait(14));

	// _2
	this.instance_4 = new lib._12_3();
	this.instance_4.parent = this;
	this.instance_4.setTransform(792,792.7,1,1,0,0,0,93,44.5);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(24).to({_off:false},0).to({y:752.7,alpha:1},11,cjs.Ease.get(1)).wait(16));

	// _1
	this.instance_5 = new lib._11_3();
	this.instance_5.parent = this;
	this.instance_5.setTransform(597,792.7,1,1,0,0,0,93,44.5);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(22).to({_off:false},0).to({y:752.7,alpha:1},11,cjs.Ease.get(1)).wait(18));

	// _0
	this.instance_6 = new lib._10_3();
	this.instance_6.parent = this;
	this.instance_6.setTransform(397,792.7,1,1,0,0,0,93,44.5);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(20).to({_off:false},0).to({y:752.7,alpha:1},11,cjs.Ease.get(1)).wait(20));

	// _
	this.instance_7 = new lib._9_3();
	this.instance_7.parent = this;
	this.instance_7.setTransform(193,792.7,1,1,0,0,0,93,44.5);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(18).to({_off:false},0).to({y:752.7,alpha:1},11,cjs.Ease.get(1)).wait(22));

	// _
	this.instance_8 = new lib._8_2();
	this.instance_8.parent = this;
	this.instance_8.setTransform(1163,578.2,1,1,0,0,0,93,170.1);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(16).to({_off:false},0).to({y:538.2,alpha:1},11,cjs.Ease.get(1)).wait(24));

	// _
	this.instance_9 = new lib._7_4();
	this.instance_9.parent = this;
	this.instance_9.setTransform(976.05,578.2,1,1,0,0,0,92,170.1);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(14).to({_off:false},0).to({y:538.2,alpha:1},11,cjs.Ease.get(1)).wait(26));

	// _
	this.instance_10 = new lib._6_3();
	this.instance_10.parent = this;
	this.instance_10.setTransform(790,578.2,1,1,0,0,0,92,170.1);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(12).to({_off:false},0).to({y:538.2,alpha:1},11,cjs.Ease.get(1)).wait(28));

	// _
	this.instance_11 = new lib._5_6();
	this.instance_11.parent = this;
	this.instance_11.setTransform(597,578.2,1,1,0,0,0,93,170.1);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(10).to({_off:false},0).to({y:538.2,alpha:1},11,cjs.Ease.get(1)).wait(30));

	// _
	this.instance_12 = new lib._4_6();
	this.instance_12.parent = this;
	this.instance_12.setTransform(397,578.2,1,1,0,0,0,93,170.1);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(8).to({_off:false},0).to({y:538.2,alpha:1},11,cjs.Ease.get(1)).wait(32));

	// _
	this.instance_13 = new lib._3_8();
	this.instance_13.parent = this;
	this.instance_13.setTransform(193,578.2,1,1,0,0,0,93,170.1);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(6).to({_off:false},0).to({y:538.2,alpha:1},11,cjs.Ease.get(1)).wait(34));

	// _
	this.instance_14 = new lib._2_8();
	this.instance_14.parent = this;
	this.instance_14.setTransform(409.15,297.05,1,1,0,0,0,335.1,59);
	this.instance_14.alpha = 0.5;
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(4).to({_off:false},0).to({x:469.15,alpha:1},11,cjs.Ease.get(1)).wait(36));

	// _
	this.instance_15 = new lib._1_8();
	this.instance_15.parent = this;
	this.instance_15.setTransform(412.1,199.05,1,1,0,0,0,316.1,39);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(51));

	// Layer_19
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img._1pngcopy8, null, new cjs.Matrix2D(1,0,0,1,-1072,-752.7)).s().p("AAAG9IAAt5IAAAAIAAN5g");
	this.shape.setTransform(1072.05,752.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(51));

	// Layer_20
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(img._1pngcopy8, null, new cjs.Matrix2D(1,0,0,1,-883,-538.1)).s().p("AgJalMAAAg1IIATAAMAAAA1Ig");
	this.shape_1.setTransform(883.025,538.15);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(51));

	// Layer_6
	this.instance_16 = new lib._1pngcopy14();
	this.instance_16.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(51));

	// ________EditBox_______
	this.instance_17 = new lib.EditBox();
	this.instance_17.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(51));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1316.1,960);


(lib.Slide07 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"viewSlide00":30,"end00":32});

	// _8
	this.instance = new lib._18();
	this.instance.parent = this;
	this.instance.setTransform(405,873,1,1,0,0,0,305,27);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(18).to({_off:false},0).wait(1).to({regY:12,y:858,alpha:0.1597},0).wait(1).to({alpha:0.3056},0).wait(1).to({alpha:0.4375},0).wait(1).to({alpha:0.5556},0).wait(1).to({alpha:0.6597},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.8264},0).wait(1).to({alpha:0.8889},0).wait(1).to({alpha:0.9375},0).wait(1).to({alpha:0.9722},0).wait(1).to({alpha:0.9931},0).wait(1).to({regY:27,y:873,alpha:1},0).wait(9));

	// _7
	this.instance_1 = new lib._17();
	this.instance_1.parent = this;
	this.instance_1.setTransform(1062,645,1,1,0,0,0,120,63);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(16).to({_off:false},0).wait(1).to({regX:155.5,x:1103.85,alpha:0.1597},0).wait(1).to({x:1109.7,alpha:0.3056},0).wait(1).to({x:1115,alpha:0.4375},0).wait(1).to({x:1119.7,alpha:0.5556},0).wait(1).to({x:1123.85,alpha:0.6597},0).wait(1).to({x:1127.5,alpha:0.75},0).wait(1).to({x:1130.55,alpha:0.8264},0).wait(1).to({x:1133.05,alpha:0.8889},0).wait(1).to({x:1135,alpha:0.9375},0).wait(1).to({x:1136.35,alpha:0.9722},0).wait(1).to({x:1137.2,alpha:0.9931},0).wait(1).to({regX:120,x:1102,alpha:1},0).wait(11));

	// _6
	this.instance_2 = new lib._16();
	this.instance_2.parent = this;
	this.instance_2.setTransform(1062,506,1,1,0,0,0,120,76);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(14).to({_off:false},0).wait(1).to({regX:155.1,x:1103.45,alpha:0.1597},0).wait(1).to({x:1109.3,alpha:0.3056},0).wait(1).to({x:1114.6,alpha:0.4375},0).wait(1).to({x:1119.3,alpha:0.5556},0).wait(1).to({x:1123.45,alpha:0.6597},0).wait(1).to({x:1127.1,alpha:0.75},0).wait(1).to({x:1130.15,alpha:0.8264},0).wait(1).to({x:1132.65,alpha:0.8889},0).wait(1).to({x:1134.6,alpha:0.9375},0).wait(1).to({x:1135.95,alpha:0.9722},0).wait(1).to({x:1136.8,alpha:0.9931},0).wait(1).to({regX:120,x:1102,alpha:1},0).wait(13));

	// _5
	this.instance_3 = new lib._15_2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(976,655,1,1,0,0,0,116,73);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(12).to({_off:false},0).wait(1).to({regX:126.1,regY:100.2,x:978.1,y:682.2,alpha:0.1597},0).wait(1).to({x:970.8,alpha:0.3056},0).wait(1).to({x:964.2,alpha:0.4375},0).wait(1).to({x:958.3,alpha:0.5556},0).wait(1).to({x:953.1,alpha:0.6597},0).wait(1).to({x:948.6,alpha:0.75},0).wait(1).to({x:944.75,alpha:0.8264},0).wait(1).to({x:941.65,alpha:0.8889},0).wait(1).to({x:939.2,alpha:0.9375},0).wait(1).to({x:937.45,alpha:0.9722},0).wait(1).to({x:936.4,alpha:0.9931},0).wait(1).to({regX:116,regY:73,x:926,y:655,alpha:1},0).wait(15));

	// _4
	this.instance_4 = new lib._14_2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(926,506,1,1,0,0,0,116,76);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(10).to({_off:false},0).wait(1).to({regX:186,x:986.4,alpha:0.1597},0).wait(1).to({x:977.65,alpha:0.3056},0).wait(1).to({x:969.75,alpha:0.4375},0).wait(1).to({x:962.65,alpha:0.5556},0).wait(1).to({x:956.4,alpha:0.6597},0).wait(1).to({x:951,alpha:0.75},0).wait(1).to({x:946.4,alpha:0.8264},0).wait(1).to({x:942.65,alpha:0.8889},0).wait(1).to({x:939.75,alpha:0.9375},0).wait(1).to({x:937.65,alpha:0.9722},0).wait(1).to({x:936.4,alpha:0.9931},0).wait(1).to({regX:116,x:866,alpha:1},0).wait(17));

	// _3
	this.instance_5 = new lib._13_2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(1046,352,1,1,0,0,0,236,78);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(8).to({_off:false},0).wait(1).to({x:1036.4,alpha:0.1597},0).wait(1).to({x:1027.65,alpha:0.3056},0).wait(1).to({x:1019.75,alpha:0.4375},0).wait(1).to({x:1012.65,alpha:0.5556},0).wait(1).to({x:1006.4,alpha:0.6597},0).wait(1).to({x:1001,alpha:0.75},0).wait(1).to({x:996.4,alpha:0.8264},0).wait(1).to({x:992.65,alpha:0.8889},0).wait(1).to({x:989.75,alpha:0.9375},0).wait(1).to({x:987.65,alpha:0.9722},0).wait(1).to({x:986.4,alpha:0.9931},0).wait(1).to({x:986,alpha:1},0).wait(19));

	// _2_copy
	this.instance_6 = new lib._12copy();
	this.instance_6.parent = this;
	this.instance_6.setTransform(583,764,0.6429,0.6429,0,0,0,87,56);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(18).to({_off:false},0).wait(1).to({regX:297.5,scaleX:0.6999,scaleY:0.6999,x:717.5,alpha:0.1597},0).wait(1).to({scaleX:0.752,scaleY:0.752,x:716.8,y:763.95,alpha:0.3056},0).wait(1).to({scaleX:0.7991,scaleY:0.7991,x:716.15,y:764,alpha:0.4375},0).wait(1).to({scaleX:0.8413,scaleY:0.8413,x:715.6,y:763.95,alpha:0.5556},0).wait(1).to({scaleX:0.8785,scaleY:0.8785,x:715.1,y:764,alpha:0.6597},0).wait(1).to({scaleX:0.9107,scaleY:0.9107,x:714.65,alpha:0.75},0).wait(1).to({scaleX:0.938,scaleY:0.938,x:714.25,alpha:0.8264},0).wait(1).to({scaleX:0.9603,scaleY:0.9603,x:713.95,alpha:0.8889},0).wait(1).to({scaleX:0.9777,scaleY:0.9777,x:713.7,alpha:0.9375},0).wait(1).to({scaleX:0.9901,scaleY:0.9901,x:713.55,alpha:0.9722},0).wait(1).to({scaleX:0.9975,scaleY:0.9975,x:713.45,y:763.95,alpha:0.9931},0).wait(1).to({regX:87,scaleX:1,scaleY:1,x:503,y:764,alpha:1},0).wait(9));

	// _2
	this.instance_7 = new lib._12_4();
	this.instance_7.parent = this;
	this.instance_7.setTransform(503,764,0.6429,0.6429,0,0,0,87,56);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(14).to({_off:false},0).wait(1).to({regX:47,scaleX:0.6999,scaleY:0.6999,x:474.95,alpha:0.1597},0).wait(1).to({scaleX:0.752,scaleY:0.752,x:472.85,y:763.95,alpha:0.3056},0).wait(1).to({scaleX:0.7991,scaleY:0.7991,x:470.95,y:764,alpha:0.4375},0).wait(1).to({scaleX:0.8413,scaleY:0.8413,x:469.3,y:763.95,alpha:0.5556},0).wait(1).to({scaleX:0.8785,scaleY:0.8785,x:467.8,y:764,alpha:0.6597},0).wait(1).to({scaleX:0.9107,scaleY:0.9107,x:466.5,alpha:0.75},0).wait(1).to({scaleX:0.938,scaleY:0.938,x:465.4,alpha:0.8264},0).wait(1).to({scaleX:0.9603,scaleY:0.9603,x:464.55,alpha:0.8889},0).wait(1).to({scaleX:0.9777,scaleY:0.9777,x:463.8,alpha:0.9375},0).wait(1).to({scaleX:0.9901,scaleY:0.9901,x:463.35,alpha:0.9722},0).wait(1).to({scaleX:0.9975,scaleY:0.9975,x:463.05,y:763.95,alpha:0.9931},0).wait(1).to({regX:87,scaleX:1,scaleY:1,x:503,y:764,alpha:1},0).wait(13));

	// _1
	this.instance_8 = new lib._11_4();
	this.instance_8.parent = this;
	this.instance_8.setTransform(206,764,0.6786,0.6786,0,0,0,106,56);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(10).to({_off:false},0).wait(1).to({scaleX:0.7299,scaleY:0.7299,x:205.95,y:763.95,alpha:0.1597},0).wait(1).to({scaleX:0.7768,scaleY:0.7768,y:764,alpha:0.3056},0).wait(1).to({scaleX:0.8192,scaleY:0.8192,y:763.95,alpha:0.4375},0).wait(1).to({scaleX:0.8571,scaleY:0.8571,y:764,alpha:0.5556},0).wait(1).to({scaleX:0.8906,scaleY:0.8906,alpha:0.6597},0).wait(1).to({scaleX:0.9196,scaleY:0.9196,alpha:0.75},0).wait(1).to({scaleX:0.9442,scaleY:0.9442,y:763.95,alpha:0.8264},0).wait(1).to({scaleX:0.9643,scaleY:0.9643,x:205.9,y:764,alpha:0.8889},0).wait(1).to({scaleX:0.9799,scaleY:0.9799,y:763.95,alpha:0.9375},0).wait(1).to({scaleX:0.9911,scaleY:0.9911,y:764,alpha:0.9722},0).wait(1).to({scaleX:0.9978,scaleY:0.9978,y:763.95,alpha:0.9931},0).wait(1).to({scaleX:1,scaleY:1,x:206,y:764,alpha:1},0).wait(17));

	// _0
	this.instance_9 = new lib._10_4();
	this.instance_9.parent = this;
	this.instance_9.setTransform(634,395,0.5429,0.5429,0,0,0,96,35);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(16).to({_off:false},0).wait(1).to({regX:76,scaleX:0.6159,scaleY:0.6159,x:621.65,y:394.95,alpha:0.1597},0).wait(1).to({scaleX:0.6825,scaleY:0.6825,x:620.35,y:395,alpha:0.3056},0).wait(1).to({scaleX:0.7429,scaleY:0.7429,x:619.15,alpha:0.4375},0).wait(1).to({scaleX:0.7968,scaleY:0.7968,x:618.05,alpha:0.5556},0).wait(1).to({scaleX:0.8444,scaleY:0.8444,x:617.15,y:394.95,alpha:0.6597},0).wait(1).to({scaleX:0.8857,scaleY:0.8857,x:616.3,y:395,alpha:0.75},0).wait(1).to({scaleX:0.9206,scaleY:0.9206,x:615.6,y:394.95,alpha:0.8264},0).wait(1).to({scaleX:0.9492,scaleY:0.9492,x:615.05,alpha:0.8889},0).wait(1).to({scaleX:0.9714,scaleY:0.9714,x:614.6,y:395,alpha:0.9375},0).wait(1).to({scaleX:0.9873,scaleY:0.9873,x:614.3,y:394.95,alpha:0.9722},0).wait(1).to({scaleX:0.9968,scaleY:0.9968,x:614.1,y:395,alpha:0.9931},0).wait(1).to({regX:96,scaleX:1,scaleY:1,x:634,alpha:1},0).wait(11));

	// _
	this.instance_10 = new lib._9_4();
	this.instance_10.parent = this;
	this.instance_10.setTransform(375,395,0.6572,0.6572,0,0,0,163,35);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(12).to({_off:false},0).wait(1).to({regX:112,regY:37,scaleX:0.7119,scaleY:0.7119,x:338.7,y:396.4,alpha:0.1597},0).wait(1).to({scaleX:0.7619,scaleY:0.7619,x:336.15,y:396.5,alpha:0.3056},0).wait(1).to({scaleX:0.8071,scaleY:0.8071,x:333.8,y:396.6,alpha:0.4375},0).wait(1).to({scaleX:0.8476,scaleY:0.8476,x:331.75,y:396.65,alpha:0.5556},0).wait(1).to({scaleX:0.8833,scaleY:0.8833,x:329.95,y:396.75,alpha:0.6597},0).wait(1).to({scaleX:0.9143,scaleY:0.9143,x:328.35,y:396.85,alpha:0.75},0).wait(1).to({scaleX:0.9405,scaleY:0.9405,x:327.05,alpha:0.8264},0).wait(1).to({scaleX:0.9619,scaleY:0.9619,x:325.95,y:396.9,alpha:0.8889},0).wait(1).to({scaleX:0.9786,scaleY:0.9786,x:325.05,y:396.95,alpha:0.9375},0).wait(1).to({scaleX:0.9905,scaleY:0.9905,x:324.5,alpha:0.9722},0).wait(1).to({scaleX:0.9976,scaleY:0.9976,x:324.1,alpha:0.9931},0).wait(1).to({regX:163,regY:35,scaleX:1,scaleY:1,x:375,y:395,alpha:1},0).wait(15));

	// __copy
	this.instance_11 = new lib._8copy();
	this.instance_11.parent = this;
	this.instance_11.setTransform(640,629,1,1,0,0,0,70,139);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(16).to({_off:false},0).wait(1).to({regX:147.1,regY:141,x:717.1,y:621.4,alpha:0.1597},0).wait(1).to({y:612.65,alpha:0.3056},0).wait(1).to({y:604.75,alpha:0.4375},0).wait(1).to({y:597.65,alpha:0.5556},0).wait(1).to({y:591.4,alpha:0.6597},0).wait(1).to({y:586,alpha:0.75},0).wait(1).to({y:581.4,alpha:0.8264},0).wait(1).to({y:577.65,alpha:0.8889},0).wait(1).to({y:574.75,alpha:0.9375},0).wait(1).to({y:572.65,alpha:0.9722},0).wait(1).to({y:571.4,alpha:0.9931},0).wait(1).to({regX:70,regY:139,x:640,y:569,alpha:1},0).wait(11));

	// _
	this.instance_12 = new lib._8_3();
	this.instance_12.parent = this;
	this.instance_12.setTransform(640,629,1,1,0,0,0,70,139);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(14).to({_off:false},0).wait(1).to({regX:20,x:590,y:619.4,alpha:0.1597},0).wait(1).to({y:610.65,alpha:0.3056},0).wait(1).to({y:602.75,alpha:0.4375},0).wait(1).to({y:595.65,alpha:0.5556},0).wait(1).to({y:589.4,alpha:0.6597},0).wait(1).to({y:584,alpha:0.75},0).wait(1).to({y:579.4,alpha:0.8264},0).wait(1).to({y:575.65,alpha:0.8889},0).wait(1).to({y:572.75,alpha:0.9375},0).wait(1).to({y:570.65,alpha:0.9722},0).wait(1).to({y:569.4,alpha:0.9931},0).wait(1).to({regX:70,x:640,y:569,alpha:1},0).wait(13));

	// _
	this.instance_13 = new lib._7_5();
	this.instance_13.parent = this;
	this.instance_13.setTransform(503,629,1,1,0,0,0,67,139);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(12).to({_off:false},0).wait(1).to({regX:25.5,x:461.5,y:619.4,alpha:0.1597},0).wait(1).to({y:610.65,alpha:0.3056},0).wait(1).to({y:602.75,alpha:0.4375},0).wait(1).to({y:595.65,alpha:0.5556},0).wait(1).to({y:589.4,alpha:0.6597},0).wait(1).to({y:584,alpha:0.75},0).wait(1).to({y:579.4,alpha:0.8264},0).wait(1).to({y:575.65,alpha:0.8889},0).wait(1).to({y:572.75,alpha:0.9375},0).wait(1).to({y:570.65,alpha:0.9722},0).wait(1).to({y:569.4,alpha:0.9931},0).wait(1).to({regX:67,x:503,y:569,alpha:1},0).wait(15));

	// _
	this.instance_14 = new lib._6_4();
	this.instance_14.parent = this;
	this.instance_14.setTransform(364,629,1,1,0,0,0,72,139);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(10).to({_off:false},0).wait(1).to({regX:42.5,x:334.5,y:619.4,alpha:0.1597},0).wait(1).to({y:610.65,alpha:0.3056},0).wait(1).to({y:602.75,alpha:0.4375},0).wait(1).to({y:595.65,alpha:0.5556},0).wait(1).to({y:589.4,alpha:0.6597},0).wait(1).to({y:584,alpha:0.75},0).wait(1).to({y:579.4,alpha:0.8264},0).wait(1).to({y:575.65,alpha:0.8889},0).wait(1).to({y:572.75,alpha:0.9375},0).wait(1).to({y:570.65,alpha:0.9722},0).wait(1).to({y:569.4,alpha:0.9931},0).wait(1).to({regX:72,x:364,y:569,alpha:1},0).wait(17));

	// _
	this.instance_15 = new lib._5_7();
	this.instance_15.parent = this;
	this.instance_15.setTransform(196,629,1,1,0,0,0,96,139);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(8).to({_off:false},0).wait(1).to({regX:86,x:186,y:619.4,alpha:0.1597},0).wait(1).to({y:610.65,alpha:0.3056},0).wait(1).to({y:602.75,alpha:0.4375},0).wait(1).to({y:595.65,alpha:0.5556},0).wait(1).to({y:589.4,alpha:0.6597},0).wait(1).to({y:584,alpha:0.75},0).wait(1).to({y:579.4,alpha:0.8264},0).wait(1).to({y:575.65,alpha:0.8889},0).wait(1).to({y:572.75,alpha:0.9375},0).wait(1).to({y:570.65,alpha:0.9722},0).wait(1).to({y:569.4,alpha:0.9931},0).wait(1).to({regX:96,x:196,y:569,alpha:1},0).wait(19));

	// _
	this.instance_16 = new lib._4_7();
	this.instance_16.parent = this;
	this.instance_16.setTransform(395,317,1,1,0,0,0,235,43);
	this.instance_16.alpha = 0;
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(6).to({_off:false},0).wait(1).to({x:385.4,alpha:0.1597},0).wait(1).to({x:376.65,alpha:0.3056},0).wait(1).to({x:368.75,alpha:0.4375},0).wait(1).to({x:361.65,alpha:0.5556},0).wait(1).to({x:355.4,alpha:0.6597},0).wait(1).to({x:350,alpha:0.75},0).wait(1).to({x:345.4,alpha:0.8264},0).wait(1).to({x:341.65,alpha:0.8889},0).wait(1).to({x:338.75,alpha:0.9375},0).wait(1).to({x:336.65,alpha:0.9722},0).wait(1).to({x:335.4,alpha:0.9931},0).wait(1).to({x:335,alpha:1},0).wait(21));

	// _
	this.instance_17 = new lib._2_9();
	this.instance_17.parent = this;
	this.instance_17.setTransform(986,540,0.7961,0.7961,0,0,0,254,304);
	this.instance_17.alpha = 0;
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(4).to({_off:false},0).wait(1).to({regX:288,scaleX:0.8287,scaleY:0.8287,x:1014.15,y:539.95,alpha:0.1597},0).wait(1).to({scaleX:0.8584,scaleY:0.8584,x:1015.15,y:540,alpha:0.3056},0).wait(1).to({scaleX:0.8853,scaleY:0.8853,x:1016.05,alpha:0.4375},0).wait(1).to({scaleX:0.9094,scaleY:0.9094,x:1016.9,alpha:0.5556},0).wait(1).to({scaleX:0.9306,scaleY:0.9306,x:1017.6,y:539.95,alpha:0.6597},0).wait(1).to({scaleX:0.949,scaleY:0.949,x:1018.25,y:540,alpha:0.75},0).wait(1).to({scaleX:0.9646,scaleY:0.9646,x:1018.75,alpha:0.8264},0).wait(1).to({scaleX:0.9773,scaleY:0.9773,x:1019.2,y:539.95,alpha:0.8889},0).wait(1).to({scaleX:0.9873,scaleY:0.9873,x:1019.55,alpha:0.9375},0).wait(1).to({scaleX:0.9943,scaleY:0.9943,x:1019.75,alpha:0.9722},0).wait(1).to({scaleX:0.9986,scaleY:0.9986,x:1019.95,alpha:0.9931},0).wait(1).to({regX:254,scaleX:1,scaleY:1,x:986,y:540,alpha:1},0).wait(23));

	// _
	this.instance_18 = new lib._1_9();
	this.instance_18.parent = this;
	this.instance_18.setTransform(416,540,0.8924,0.8924,0,0,0,316,304);
	this.instance_18.alpha = 0;
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(2).to({_off:false},0).wait(1).to({regX:350,scaleX:0.9096,scaleY:0.9096,x:446.9,y:539.95,alpha:0.1597},0).wait(1).to({scaleX:0.9253,scaleY:0.9253,x:447.45,y:540,alpha:0.3056},0).wait(1).to({scaleX:0.9395,scaleY:0.9395,x:447.9,y:539.95,alpha:0.4375},0).wait(1).to({scaleX:0.9522,scaleY:0.9522,x:448.35,alpha:0.5556},0).wait(1).to({scaleX:0.9634,scaleY:0.9634,x:448.75,alpha:0.6597},0).wait(1).to({scaleX:0.9731,scaleY:0.9731,x:449.1,alpha:0.75},0).wait(1).to({scaleX:0.9813,scaleY:0.9813,x:449.35,alpha:0.8264},0).wait(1).to({scaleX:0.988,scaleY:0.988,x:449.55,alpha:0.8889},0).wait(1).to({scaleX:0.9933,scaleY:0.9933,x:449.75,alpha:0.9375},0).wait(1).to({scaleX:0.997,scaleY:0.997,x:449.85,y:540,alpha:0.9722},0).wait(1).to({scaleX:0.9993,scaleY:0.9993,x:449.95,y:539.95,alpha:0.9931},0).wait(1).to({regX:316,scaleX:1,scaleY:1,x:416,y:540,alpha:1},0).wait(25));

	// Layer_3
	this.instance_19 = new lib._3pngcopy();
	this.instance_19.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(39));

	// _
	this.instance_20 = new lib._3_9();
	this.instance_20.parent = this;
	this.instance_20.setTransform(690,218,1,1,0,0,0,590,64);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(39));

	// Layer_6
	this.instance_21 = new lib._1pngcopy14();
	this.instance_21.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(39));

	// ________EditBox_______
	this.instance_22 = new lib.EditBox();
	this.instance_22.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(39));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1316.1,960);


(lib.Slide06 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"viewSlide00":30,"end00":32});

	// _
	this.instance = new lib._5_8();
	this.instance.parent = this;
	this.instance.setTransform(198,752,0.4667,0.4667,0,0,0,78,60);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(8).to({_off:false},0).wait(1).to({scaleX:0.5518,scaleY:0.5518,y:751.95,alpha:0.1597},0).wait(1).to({scaleX:0.6296,scaleY:0.6296,x:197.95,y:752,alpha:0.3056},0).wait(1).to({scaleX:0.7,scaleY:0.7,x:198,alpha:0.4375},0).wait(1).to({scaleX:0.763,scaleY:0.763,x:197.95,alpha:0.5556},0).wait(1).to({scaleX:0.8185,scaleY:0.8185,x:198,y:751.95,alpha:0.6597},0).wait(1).to({scaleX:0.8667,scaleY:0.8667,y:752,alpha:0.75},0).wait(1).to({scaleX:0.9074,scaleY:0.9074,alpha:0.8264},0).wait(1).to({scaleX:0.9407,scaleY:0.9407,alpha:0.8889},0).wait(1).to({scaleX:0.9667,scaleY:0.9667,alpha:0.9375},0).wait(1).to({scaleX:0.9852,scaleY:0.9852,y:751.95,alpha:0.9722},0).wait(1).to({scaleX:0.9963,scaleY:0.9963,x:197.95,y:752,alpha:0.9931},0).wait(1).to({scaleX:1,scaleY:1,x:198,alpha:1},0).wait(19));

	// _
	this.instance_1 = new lib._4_8();
	this.instance_1.parent = this;
	this.instance_1.setTransform(466,577,1,1,0,0,0,190,55);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(6).to({_off:false},0).wait(1).to({y:567.4,alpha:0.1597},0).wait(1).to({y:558.65,alpha:0.3056},0).wait(1).to({y:550.75,alpha:0.4375},0).wait(1).to({y:543.65,alpha:0.5556},0).wait(1).to({y:537.4,alpha:0.6597},0).wait(1).to({y:532,alpha:0.75},0).wait(1).to({y:527.4,alpha:0.8264},0).wait(1).to({y:523.65,alpha:0.8889},0).wait(1).to({y:520.75,alpha:0.9375},0).wait(1).to({y:518.65,alpha:0.9722},0).wait(1).to({y:517.4,alpha:0.9931},0).wait(1).to({y:517,alpha:1},0).wait(21));

	// _
	this.instance_2 = new lib._3_10();
	this.instance_2.parent = this;
	this.instance_2.setTransform(1168,212,0.4444,0.4444,0,0,0,112,72);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(4).to({_off:false},0).wait(1).to({scaleX:0.5332,scaleY:0.5332,x:1167.95,alpha:0.1597},0).wait(1).to({scaleX:0.6142,scaleY:0.6142,y:211.95,alpha:0.3056},0).wait(1).to({scaleX:0.6875,scaleY:0.6875,y:212,alpha:0.4375},0).wait(1).to({scaleX:0.7531,scaleY:0.7531,y:211.95,alpha:0.5556},0).wait(1).to({scaleX:0.811,scaleY:0.811,y:212,alpha:0.6597},0).wait(1).to({scaleX:0.8611,scaleY:0.8611,alpha:0.75},0).wait(1).to({scaleX:0.9035,scaleY:0.9035,y:211.95,alpha:0.8264},0).wait(1).to({scaleX:0.9383,scaleY:0.9383,alpha:0.8889},0).wait(1).to({scaleX:0.9653,scaleY:0.9653,x:1167.9,y:212,alpha:0.9375},0).wait(1).to({scaleX:0.9846,scaleY:0.9846,alpha:0.9722},0).wait(1).to({scaleX:0.9961,scaleY:0.9961,y:211.95,alpha:0.9931},0).wait(1).to({scaleX:1,scaleY:1,x:1168,y:212,alpha:1},0).wait(23));

	// _
	this.instance_3 = new lib._2_10();
	this.instance_3.parent = this;
	this.instance_3.setTransform(736,291,0.3803,0.3803,0,0,0,80,71);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(2).to({_off:false},0).wait(1).to({scaleX:0.4793,scaleY:0.4793,alpha:0.1597},0).wait(1).to({scaleX:0.5696,scaleY:0.5696,alpha:0.3056},0).wait(1).to({scaleX:0.6514,scaleY:0.6514,alpha:0.4375},0).wait(1).to({scaleX:0.7246,scaleY:0.7246,alpha:0.5556},0).wait(1).to({scaleX:0.7891,scaleY:0.7891,x:736.05,alpha:0.6597},0).wait(1).to({scaleX:0.8451,scaleY:0.8451,x:736,alpha:0.75},0).wait(1).to({scaleX:0.8924,scaleY:0.8924,x:736.05,y:290.95,alpha:0.8264},0).wait(1).to({scaleX:0.9311,scaleY:0.9311,alpha:0.8889},0).wait(1).to({scaleX:0.9613,scaleY:0.9613,x:736,y:291,alpha:0.9375},0).wait(1).to({scaleX:0.9828,scaleY:0.9828,alpha:0.9722},0).wait(1).to({scaleX:0.9957,scaleY:0.9957,alpha:0.9931},0).wait(1).to({scaleX:1,scaleY:1,alpha:1},0).wait(25));

	// _
	this.instance_4 = new lib._1_10();
	this.instance_4.parent = this;
	this.instance_4.setTransform(268,251,1,1,0,0,0,148,111);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(39));

	// Layer_6
	this.instance_5 = new lib._1pngcopy10();
	this.instance_5.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(39));

	// ________EditBox_______
	this.instance_6 = new lib.EditBox();
	this.instance_6.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(39));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1316.1,960);


(lib.Slide05 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"viewSlide00":30,"end00":32});

	// _0
	this.instance = new lib._10_5();
	this.instance.parent = this;
	this.instance.setTransform(679,848,1,1,0,0,0,579,52);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(18).to({_off:false},0).wait(1).to({alpha:0.1597},0).wait(1).to({alpha:0.3056},0).wait(1).to({alpha:0.4375},0).wait(1).to({alpha:0.5556},0).wait(1).to({alpha:0.6597},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.8264},0).wait(1).to({alpha:0.8889},0).wait(1).to({alpha:0.9375},0).wait(1).to({alpha:0.9722},0).wait(1).to({alpha:0.9931},0).wait(1).to({alpha:1},0).wait(9));

	// _
	this.instance_1 = new lib._9_5();
	this.instance_1.parent = this;
	this.instance_1.setTransform(1115,676,1,1,0,0,0,243,46);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(16).to({_off:false},0).wait(1).to({x:1099,alpha:0.1597},0).wait(1).to({x:1084.4,alpha:0.3056},0).wait(1).to({x:1071.25,alpha:0.4375},0).wait(1).to({x:1059.4,alpha:0.5556},0).wait(1).to({x:1049,alpha:0.6597},0).wait(1).to({x:1040,alpha:0.75},0).wait(1).to({x:1032.35,alpha:0.8264},0).wait(1).to({x:1026.1,alpha:0.8889},0).wait(1).to({x:1021.25,alpha:0.9375},0).wait(1).to({x:1017.75,alpha:0.9722},0).wait(1).to({x:1015.65,alpha:0.9931},0).wait(1).to({x:1015,alpha:1},0).wait(11));

	// _
	this.instance_2 = new lib._8_4();
	this.instance_2.parent = this;
	this.instance_2.setTransform(1115,586,1,1,0,0,0,243,44);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(14).to({_off:false},0).wait(1).to({x:1099,alpha:0.1597},0).wait(1).to({x:1084.4,alpha:0.3056},0).wait(1).to({x:1071.25,alpha:0.4375},0).wait(1).to({x:1059.4,alpha:0.5556},0).wait(1).to({x:1049,alpha:0.6597},0).wait(1).to({x:1040,alpha:0.75},0).wait(1).to({x:1032.35,alpha:0.8264},0).wait(1).to({x:1026.1,alpha:0.8889},0).wait(1).to({x:1021.25,alpha:0.9375},0).wait(1).to({x:1017.75,alpha:0.9722},0).wait(1).to({x:1015.65,alpha:0.9931},0).wait(1).to({x:1015,alpha:1},0).wait(13));

	// _
	this.instance_3 = new lib._7_6();
	this.instance_3.parent = this;
	this.instance_3.setTransform(1115,499,1,1,0,0,0,243,43);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(12).to({_off:false},0).wait(1).to({x:1099,alpha:0.1597},0).wait(1).to({x:1084.4,alpha:0.3056},0).wait(1).to({x:1071.25,alpha:0.4375},0).wait(1).to({x:1059.4,alpha:0.5556},0).wait(1).to({x:1049,alpha:0.6597},0).wait(1).to({x:1040,alpha:0.75},0).wait(1).to({x:1032.35,alpha:0.8264},0).wait(1).to({x:1026.1,alpha:0.8889},0).wait(1).to({x:1021.25,alpha:0.9375},0).wait(1).to({x:1017.75,alpha:0.9722},0).wait(1).to({x:1015.65,alpha:0.9931},0).wait(1).to({x:1015,alpha:1},0).wait(15));

	// _
	this.instance_4 = new lib._6_5();
	this.instance_4.parent = this;
	this.instance_4.setTransform(1115,412,1,1,0,0,0,243,44);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(10).to({_off:false},0).wait(1).to({x:1099,alpha:0.1597},0).wait(1).to({x:1084.4,alpha:0.3056},0).wait(1).to({x:1071.25,alpha:0.4375},0).wait(1).to({x:1059.4,alpha:0.5556},0).wait(1).to({x:1049,alpha:0.6597},0).wait(1).to({x:1040,alpha:0.75},0).wait(1).to({x:1032.35,alpha:0.8264},0).wait(1).to({x:1026.1,alpha:0.8889},0).wait(1).to({x:1021.25,alpha:0.9375},0).wait(1).to({x:1017.75,alpha:0.9722},0).wait(1).to({x:1015.65,alpha:0.9931},0).wait(1).to({x:1015,alpha:1},0).wait(17));

	// _
	this.instance_5 = new lib._5_9();
	this.instance_5.parent = this;
	this.instance_5.setTransform(444.05,807,1,1,0,0,0,114,49);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(8).to({_off:false},0).wait(1).to({y:797.4,alpha:0.1597},0).wait(1).to({y:788.65,alpha:0.3056},0).wait(1).to({y:780.75,alpha:0.4375},0).wait(1).to({y:773.65,alpha:0.5556},0).wait(1).to({y:767.4,alpha:0.6597},0).wait(1).to({y:762,alpha:0.75},0).wait(1).to({y:757.4,alpha:0.8264},0).wait(1).to({y:753.65,alpha:0.8889},0).wait(1).to({y:750.75,alpha:0.9375},0).wait(1).to({y:748.65,alpha:0.9722},0).wait(1).to({y:747.4,alpha:0.9931},0).wait(1).to({y:747,alpha:1},0).wait(19));

	// _
	this.instance_6 = new lib._4_9();
	this.instance_6.parent = this;
	this.instance_6.setTransform(725,362,1,1,0,0,0,107,54);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(6).to({_off:false},0).wait(1).to({x:715.4,alpha:0.1597},0).wait(1).to({x:706.65,alpha:0.3056},0).wait(1).to({x:698.75,alpha:0.4375},0).wait(1).to({x:691.65,alpha:0.5556},0).wait(1).to({x:685.4,alpha:0.6597},0).wait(1).to({x:680,alpha:0.75},0).wait(1).to({x:675.4,alpha:0.8264},0).wait(1).to({x:671.65,alpha:0.8889},0).wait(1).to({x:668.75,alpha:0.9375},0).wait(1).to({x:666.65,alpha:0.9722},0).wait(1).to({x:665.4,alpha:0.9931},0).wait(1).to({x:665,alpha:1},0).wait(21));

	// _
	this.instance_7 = new lib._3_11();
	this.instance_7.parent = this;
	this.instance_7.setTransform(299.95,362,1,1,0,0,0,129.9,54);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(4).to({_off:false},0).wait(1).to({regX:130,x:309.6,alpha:0.1597},0).wait(1).to({x:318.35,alpha:0.3056},0).wait(1).to({x:326.3,alpha:0.4375},0).wait(1).to({x:333.35,alpha:0.5556},0).wait(1).to({x:339.6,alpha:0.6597},0).wait(1).to({x:345.05,alpha:0.75},0).wait(1).to({x:349.6,alpha:0.8264},0).wait(1).to({x:353.35,alpha:0.8889},0).wait(1).to({x:356.3,alpha:0.9375},0).wait(1).to({x:358.35,alpha:0.9722},0).wait(1).to({x:359.6,alpha:0.9931},0).wait(1).to({regX:129.9,x:359.95,alpha:1},0).wait(23));

	// Слой_2
	this.instance_8 = new lib._1_11();
	this.instance_8.parent = this;
	this.instance_8.setTransform(410,510,0.6903,0.6903,0,0,0,310,210);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(2).to({_off:false},0).wait(1).to({scaleX:0.7398,scaleY:0.7398,alpha:0.1597},0).wait(1).to({scaleX:0.7849,scaleY:0.7849,alpha:0.3056},0).wait(1).to({scaleX:0.8258,scaleY:0.8258,alpha:0.4375},0).wait(1).to({scaleX:0.8624,scaleY:0.8624,alpha:0.5556},0).wait(1).to({scaleX:0.8946,scaleY:0.8946,alpha:0.6597},0).wait(1).to({scaleX:0.9226,scaleY:0.9226,y:510.05,alpha:0.75},0).wait(1).to({scaleX:0.9462,scaleY:0.9462,y:510,alpha:0.8264},0).wait(1).to({scaleX:0.9656,scaleY:0.9656,alpha:0.8889},0).wait(1).to({scaleX:0.9806,scaleY:0.9806,y:510.05,alpha:0.9375},0).wait(1).to({scaleX:0.9914,scaleY:0.9914,alpha:0.9722},0).wait(1).to({scaleX:0.9978,scaleY:0.9978,alpha:0.9931},0).wait(1).to({scaleX:1,scaleY:1,y:510,alpha:1},0).wait(25));

	// Слой_3
	this.instance_9 = new lib._3();
	this.instance_9.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(39));

	// _
	this.instance_10 = new lib._2_11();
	this.instance_10.parent = this;
	this.instance_10.setTransform(679,244,1,1,0,0,0,579,76);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(39));

	// Layer_6
	this.instance_11 = new lib._1pngcopy14();
	this.instance_11.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(39));

	// ________EditBox_______
	this.instance_12 = new lib.EditBox();
	this.instance_12.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(39));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1358,960);


(lib.Slide04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"viewSlide00":28,"end00":30});

	// _
	this.instance = new lib._4_10();
	this.instance.parent = this;
	this.instance.setTransform(200,750,0.3548,0.3548,0,0,0,80,62);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(6).to({_off:false},0).wait(1).to({scaleX:0.4579,scaleY:0.4579,alpha:0.1597},0).wait(1).to({scaleX:0.552,scaleY:0.552,x:199.95,y:749.95,alpha:0.3056},0).wait(1).to({scaleX:0.6371,scaleY:0.6371,y:750,alpha:0.4375},0).wait(1).to({scaleX:0.7133,scaleY:0.7133,y:749.95,alpha:0.5556},0).wait(1).to({scaleX:0.7805,scaleY:0.7805,y:750,alpha:0.6597},0).wait(1).to({scaleX:0.8387,scaleY:0.8387,alpha:0.75},0).wait(1).to({scaleX:0.888,scaleY:0.888,y:749.95,alpha:0.8264},0).wait(1).to({scaleX:0.9283,scaleY:0.9283,x:199.9,alpha:0.8889},0).wait(1).to({scaleX:0.9597,scaleY:0.9597,y:750,alpha:0.9375},0).wait(1).to({scaleX:0.9821,scaleY:0.9821,alpha:0.9722},0).wait(1).to({scaleX:0.9955,scaleY:0.9955,x:199.95,y:749.95,alpha:0.9931},0).wait(1).to({scaleX:1,scaleY:1,x:200,y:750,alpha:1},0).wait(19));

	// _
	this.instance_1 = new lib._3_12();
	this.instance_1.parent = this;
	this.instance_1.setTransform(470,578,1,1,0,0,0,350,90);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4).to({_off:false},0).wait(1).to({y:568.4,alpha:0.1597},0).wait(1).to({y:559.65,alpha:0.3056},0).wait(1).to({y:551.75,alpha:0.4375},0).wait(1).to({y:544.65,alpha:0.5556},0).wait(1).to({y:538.4,alpha:0.6597},0).wait(1).to({y:533,alpha:0.75},0).wait(1).to({y:528.4,alpha:0.8264},0).wait(1).to({y:524.65,alpha:0.8889},0).wait(1).to({y:521.75,alpha:0.9375},0).wait(1).to({y:519.65,alpha:0.9722},0).wait(1).to({y:518.4,alpha:0.9931},0).wait(1).to({y:518,alpha:1},0).wait(21));

	// _
	this.instance_2 = new lib._2_12();
	this.instance_2.parent = this;
	this.instance_2.setTransform(740,294,0.425,0.425,0,0,0,80,94);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(2).to({_off:false},0).wait(1).to({scaleX:0.5168,scaleY:0.5168,y:290.8,alpha:0.1597},0).wait(1).to({scaleX:0.6007,scaleY:0.6007,x:739.95,y:287.85,alpha:0.3056},0).wait(1).to({scaleX:0.6766,scaleY:0.6766,y:285.25,alpha:0.4375},0).wait(1).to({scaleX:0.7444,scaleY:0.7444,y:282.9,alpha:0.5556},0).wait(1).to({scaleX:0.8043,scaleY:0.8043,x:740,y:280.75,alpha:0.6597},0).wait(1).to({scaleX:0.8563,scaleY:0.8563,y:279,alpha:0.75},0).wait(1).to({scaleX:0.9002,scaleY:0.9002,x:739.95,y:277.45,alpha:0.8264},0).wait(1).to({scaleX:0.9361,scaleY:0.9361,x:740,y:276.2,alpha:0.8889},0).wait(1).to({scaleX:0.9641,scaleY:0.9641,x:739.95,y:275.2,alpha:0.9375},0).wait(1).to({scaleX:0.984,scaleY:0.984,y:274.55,alpha:0.9722},0).wait(1).to({scaleX:0.996,scaleY:0.996,x:740,y:274.1,alpha:0.9931},0).wait(1).to({scaleX:1,scaleY:1,y:274,alpha:1},0).wait(23));

	// _
	this.instance_3 = new lib._1_12();
	this.instance_3.parent = this;
	this.instance_3.setTransform(260,274,1,1,0,0,0,140,94);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(37));

	// Layer_6
	this.instance_4 = new lib._1pngcopy12();
	this.instance_4.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(37));

	// ________EditBox_______
	this.instance_5 = new lib.EditBox();
	this.instance_5.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(37));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1316.1,960);


(lib.Slide03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"viewSlide00":28,"end00":30});

	// _
	this.instance = new lib._6_6();
	this.instance.parent = this;
	this.instance.setTransform(391,872,1,1,0,0,0,283,40);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({_off:false},0).wait(1).to({regY:10,y:842,alpha:0.1597},0).wait(1).to({alpha:0.3056},0).wait(1).to({alpha:0.4375},0).wait(1).to({alpha:0.5556},0).wait(1).to({alpha:0.6597},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.8264},0).wait(1).to({alpha:0.8889},0).wait(1).to({alpha:0.9375},0).wait(1).to({alpha:0.9722},0).wait(1).to({alpha:0.9931},0).wait(1).to({regY:40,y:872,alpha:1},0).wait(15));

	// _
	this.instance_1 = new lib._5_10();
	this.instance_1.parent = this;
	this.instance_1.setTransform(959,632,0.62,0.62,0,0,0,285,100);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(8).to({_off:false},0).wait(1).to({scaleX:0.6807,scaleY:0.6807,y:631.95,alpha:0.1597},0).wait(1).to({scaleX:0.7361,scaleY:0.7361,alpha:0.3056},0).wait(1).to({scaleX:0.7862,scaleY:0.7862,alpha:0.4375},0).wait(1).to({scaleX:0.8311,scaleY:0.8311,x:958.95,alpha:0.5556},0).wait(1).to({scaleX:0.8707,scaleY:0.8707,x:959,alpha:0.6597},0).wait(1).to({scaleX:0.905,scaleY:0.905,x:958.95,y:632,alpha:0.75},0).wait(1).to({scaleX:0.934,scaleY:0.934,x:959,y:631.95,alpha:0.8264},0).wait(1).to({scaleX:0.9578,scaleY:0.9578,x:958.95,y:632,alpha:0.8889},0).wait(1).to({scaleX:0.9762,scaleY:0.9762,x:959,y:631.95,alpha:0.9375},0).wait(1).to({scaleX:0.9894,scaleY:0.9894,y:632,alpha:0.9722},0).wait(1).to({scaleX:0.9974,scaleY:0.9974,alpha:0.9931},0).wait(1).to({scaleX:1,scaleY:1,alpha:1},0).wait(17));

	// _
	this.instance_2 = new lib._4_11();
	this.instance_2.parent = this;
	this.instance_2.setTransform(391,632,0.58,0.58,0,0,0,283,100);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(6).to({_off:false},0).wait(1).to({scaleX:0.6471,scaleY:0.6471,x:390.95,y:631.95,alpha:0.1597},0).wait(1).to({scaleX:0.7083,scaleY:0.7083,y:632,alpha:0.3056},0).wait(1).to({scaleX:0.7638,scaleY:0.7638,x:391,y:631.95,alpha:0.4375},0).wait(1).to({scaleX:0.8133,scaleY:0.8133,x:390.95,y:632,alpha:0.5556},0).wait(1).to({scaleX:0.8571,scaleY:0.8571,y:631.95,alpha:0.6597},0).wait(1).to({scaleX:0.895,scaleY:0.895,x:391,y:632,alpha:0.75},0).wait(1).to({scaleX:0.9271,scaleY:0.9271,x:390.95,y:631.95,alpha:0.8264},0).wait(1).to({scaleX:0.9533,scaleY:0.9533,x:391,y:632,alpha:0.8889},0).wait(1).to({scaleX:0.9738,scaleY:0.9738,x:390.95,y:631.95,alpha:0.9375},0).wait(1).to({scaleX:0.9883,scaleY:0.9883,x:391,y:632,alpha:0.9722},0).wait(1).to({scaleX:0.9971,scaleY:0.9971,x:390.95,y:631.95,alpha:0.9931},0).wait(1).to({scaleX:1,scaleY:1,x:391,y:632,alpha:1},0).wait(19));

	// _
	this.instance_3 = new lib._3_13();
	this.instance_3.parent = this;
	this.instance_3.setTransform(958.95,434,0.6531,0.6531,0,0,0,284.9,98);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(4).to({_off:false},0).wait(1).to({regX:285,scaleX:0.7085,scaleY:0.7085,x:959,alpha:0.1597},0).wait(1).to({scaleX:0.7591,scaleY:0.7591,alpha:0.3056},0).wait(1).to({scaleX:0.8048,scaleY:0.8048,x:959.05,y:433.95,alpha:0.4375},0).wait(1).to({scaleX:0.8458,scaleY:0.8458,x:959,y:434,alpha:0.5556},0).wait(1).to({scaleX:0.8819,scaleY:0.8819,alpha:0.6597},0).wait(1).to({scaleX:0.9133,scaleY:0.9133,x:959.05,alpha:0.75},0).wait(1).to({scaleX:0.9398,scaleY:0.9398,alpha:0.8264},0).wait(1).to({scaleX:0.9615,scaleY:0.9615,x:959,y:433.95,alpha:0.8889},0).wait(1).to({scaleX:0.9783,scaleY:0.9783,alpha:0.9375},0).wait(1).to({scaleX:0.9904,scaleY:0.9904,alpha:0.9722},0).wait(1).to({scaleX:0.9976,scaleY:0.9976,alpha:0.9931},0).wait(1).to({scaleX:1,scaleY:1,y:434,alpha:1},0).wait(21));

	// _
	this.instance_4 = new lib._2_13();
	this.instance_4.parent = this;
	this.instance_4.setTransform(391,434,0.5714,0.5714,0,0,0,283,98);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(2).to({_off:false},0).wait(1).to({scaleX:0.6399,scaleY:0.6399,y:433.95,alpha:0.1597},0).wait(1).to({scaleX:0.7024,scaleY:0.7024,x:390.95,y:434,alpha:0.3056},0).wait(1).to({scaleX:0.7589,scaleY:0.7589,x:391,y:433.95,alpha:0.4375},0).wait(1).to({scaleX:0.8095,scaleY:0.8095,y:434,alpha:0.5556},0).wait(1).to({scaleX:0.8542,scaleY:0.8542,y:433.95,alpha:0.6597},0).wait(1).to({scaleX:0.8929,scaleY:0.8929,y:434,alpha:0.75},0).wait(1).to({scaleX:0.9256,scaleY:0.9256,y:433.95,alpha:0.8264},0).wait(1).to({scaleX:0.9524,scaleY:0.9524,x:390.95,y:434,alpha:0.8889},0).wait(1).to({scaleX:0.9732,scaleY:0.9732,y:433.95,alpha:0.9375},0).wait(1).to({scaleX:0.9881,scaleY:0.9881,x:391,y:434,alpha:0.9722},0).wait(1).to({scaleX:0.997,scaleY:0.997,x:390.95,y:433.95,alpha:0.9931},0).wait(1).to({scaleX:1,scaleY:1,x:391,y:434,alpha:1},0).wait(23));

	// _
	this.instance_5 = new lib._1_13();
	this.instance_5.parent = this;
	this.instance_5.setTransform(686,258,1,1,0,0,0,578,78);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(37));

	// Layer_3
	this.instance_6 = new lib._2pngcopy11();
	this.instance_6.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(37));

	// Layer_6
	this.instance_7 = new lib._1pngcopy14();
	this.instance_7.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(37));

	// ________EditBox_______
	this.instance_8 = new lib.EditBox();
	this.instance_8.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(37));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1316.1,960);


(lib.Slide02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"viewSlide00":28,"end00":30});

	// timeline functions:
	this.frame_27 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(27).call(this.frame_27).wait(10));

	// Layer_3
	this.prev00 = new lib.CancelButton();
	this.prev00.name = "prev00";
	this.prev00.parent = this;
	this.prev00.setTransform(791.4,266.4);
	new cjs.ButtonHelper(this.prev00, 0, 1, 2, false, new lib.CancelButton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.prev00).wait(37));

	// _
	this.instance = new lib._6_7();
	this.instance.parent = this;
	this.instance.setTransform(680,828,1,1,0,0,0,580,50);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).wait(1).to({alpha:0.1597},0).wait(1).to({alpha:0.3056},0).wait(1).to({alpha:0.4375},0).wait(1).to({alpha:0.5556},0).wait(1).to({alpha:0.6597},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.8264},0).wait(1).to({alpha:0.8889},0).wait(1).to({alpha:0.9375},0).wait(1).to({alpha:0.9722},0).wait(1).to({alpha:0.9931},0).wait(1).to({alpha:1},0).wait(11));

	// _
	this.instance_1 = new lib._5_11();
	this.instance_1.parent = this;
	this.instance_1.setTransform(1063.05,544,0.5684,0.5684,0,0,0,197.1,190);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(11).to({_off:false},0).wait(1).to({regX:197,scaleX:0.6374,scaleY:0.6374,x:1062.95,alpha:0.1597},0).wait(1).to({scaleX:0.7003,scaleY:0.7003,y:543.95,alpha:0.3056},0).wait(1).to({scaleX:0.7572,scaleY:0.7572,x:1062.9,alpha:0.4375},0).wait(1).to({scaleX:0.8082,scaleY:0.8082,x:1062.95,alpha:0.5556},0).wait(1).to({scaleX:0.8531,scaleY:0.8531,x:1062.9,y:544,alpha:0.6597},0).wait(1).to({scaleX:0.8921,scaleY:0.8921,x:1062.95,alpha:0.75},0).wait(1).to({scaleX:0.9251,scaleY:0.9251,y:543.95,alpha:0.8264},0).wait(1).to({scaleX:0.952,scaleY:0.952,y:544,alpha:0.8889},0).wait(1).to({scaleX:0.973,scaleY:0.973,y:543.95,alpha:0.9375},0).wait(1).to({scaleX:0.988,scaleY:0.988,alpha:0.9722},0).wait(1).to({scaleX:0.997,scaleY:0.997,x:1062.9,y:544,alpha:0.9931},0).wait(1).to({scaleX:1,scaleY:1,x:1063,alpha:1},0).wait(14));

	// _
	this.instance_2 = new lib._4_12();
	this.instance_2.parent = this;
	this.instance_2.setTransform(677,544,0.5579,0.5579,0,0,0,189,190);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(8).to({_off:false},0).wait(1).to({scaleX:0.6285,scaleY:0.6285,y:543.95,alpha:0.1597},0).wait(1).to({scaleX:0.693,scaleY:0.693,x:676.95,alpha:0.3056},0).wait(1).to({scaleX:0.7513,scaleY:0.7513,y:544,alpha:0.4375},0).wait(1).to({scaleX:0.8035,scaleY:0.8035,y:543.95,alpha:0.5556},0).wait(1).to({scaleX:0.8496,scaleY:0.8496,alpha:0.6597},0).wait(1).to({scaleX:0.8895,scaleY:0.8895,y:544,alpha:0.75},0).wait(1).to({scaleX:0.9232,scaleY:0.9232,x:677,y:543.95,alpha:0.8264},0).wait(1).to({scaleX:0.9509,scaleY:0.9509,x:676.95,alpha:0.8889},0).wait(1).to({scaleX:0.9724,scaleY:0.9724,x:677,y:544,alpha:0.9375},0).wait(1).to({scaleX:0.9877,scaleY:0.9877,y:543.95,alpha:0.9722},0).wait(1).to({scaleX:0.9969,scaleY:0.9969,x:676.95,alpha:0.9931},0).wait(1).to({scaleX:1,scaleY:1,x:677,y:544,alpha:1},0).wait(17));

	// _
	this.instance_3 = new lib._3_14();
	this.instance_3.parent = this;
	this.instance_3.setTransform(294,544,0.5361,0.5361,0,0,0,194,190);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(5).to({_off:false},0).wait(1).to({scaleX:0.6102,scaleY:0.6102,alpha:0.1597},0).wait(1).to({scaleX:0.6778,scaleY:0.6778,alpha:0.3056},0).wait(1).to({scaleX:0.739,scaleY:0.739,x:293.95,y:543.95,alpha:0.4375},0).wait(1).to({scaleX:0.7938,scaleY:0.7938,x:294,alpha:0.5556},0).wait(1).to({scaleX:0.8421,scaleY:0.8421,x:293.95,alpha:0.6597},0).wait(1).to({scaleX:0.884,scaleY:0.884,x:294,alpha:0.75},0).wait(1).to({scaleX:0.9195,scaleY:0.9195,x:293.95,y:544,alpha:0.8264},0).wait(1).to({scaleX:0.9485,scaleY:0.9485,x:294,y:543.95,alpha:0.8889},0).wait(1).to({scaleX:0.971,scaleY:0.971,x:293.95,y:544,alpha:0.9375},0).wait(1).to({scaleX:0.9871,scaleY:0.9871,x:294,y:543.95,alpha:0.9722},0).wait(1).to({scaleX:0.9968,scaleY:0.9968,x:293.95,y:544,alpha:0.9931},0).wait(1).to({scaleX:1,scaleY:1,x:294,alpha:1},0).wait(20));

	// _
	this.instance_4 = new lib._2_14();
	this.instance_4.parent = this;
	this.instance_4.setTransform(777,300,1,1,0,0,0,189,54);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(2).to({_off:false},0).wait(1).to({x:761,alpha:0.1597},0).wait(1).to({x:746.4,alpha:0.3056},0).wait(1).to({x:733.25,alpha:0.4375},0).wait(1).to({x:721.4,alpha:0.5556},0).wait(1).to({x:711,alpha:0.6597},0).wait(1).to({x:702,alpha:0.75},0).wait(1).to({x:694.35,alpha:0.8264},0).wait(1).to({x:688.1,alpha:0.8889},0).wait(1).to({x:683.25,alpha:0.9375},0).wait(1).to({x:679.75,alpha:0.9722},0).wait(1).to({x:677.65,alpha:0.9931},0).wait(1).to({x:677,alpha:1},0).wait(23));

	// _
	this.instance_5 = new lib._1_14();
	this.instance_5.parent = this;
	this.instance_5.setTransform(680,267,1,1,0,0,0,580,87);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(37));

	// Layer_6
	this.instance_6 = new lib._1pngcopy14();
	this.instance_6.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(37));

	// ________EditBox_______
	this.instance_7 = new lib.EditBox();
	this.instance_7.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(37));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1316.1,960);


(lib.Slide01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"viewSlide00":28,"end00":30});

	// _
	this.instance = new lib._8_5();
	this.instance.parent = this;
	this.instance.setTransform(654,846,1,1,0,0,0,494,50);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).wait(1).to({alpha:0.1597},0).wait(1).to({alpha:0.3056},0).wait(1).to({alpha:0.4375},0).wait(1).to({alpha:0.5556},0).wait(1).to({alpha:0.6597},0).wait(1).to({alpha:0.75},0).wait(1).to({alpha:0.8264},0).wait(1).to({alpha:0.8889},0).wait(1).to({alpha:0.9375},0).wait(1).to({alpha:0.9722},0).wait(1).to({alpha:0.9931},0).wait(1).to({alpha:1},0).wait(13));

	// _
	this.instance_1 = new lib._7_7();
	this.instance_1.parent = this;
	this.instance_1.setTransform(827,703,1,1,0,0,0,327,103);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(7).to({_off:false},0).wait(1).to({x:811,alpha:0.1597},0).wait(1).to({x:796.4,alpha:0.3056},0).wait(1).to({x:783.25,alpha:0.4375},0).wait(1).to({x:771.4,alpha:0.5556},0).wait(1).to({x:761,alpha:0.6597},0).wait(1).to({x:752,alpha:0.75},0).wait(1).to({x:744.35,alpha:0.8264},0).wait(1).to({x:738.1,alpha:0.8889},0).wait(1).to({x:733.25,alpha:0.9375},0).wait(1).to({x:729.75,alpha:0.9722},0).wait(1).to({x:727.65,alpha:0.9931},0).wait(1).to({x:727,alpha:1},0).wait(18));

	// _
	this.instance_2 = new lib._6_8();
	this.instance_2.parent = this;
	this.instance_2.setTransform(1204,723,1,1,0,0,0,76,223);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(8).to({_off:false},0).wait(1).to({y:738.95,alpha:0.1597},0).wait(1).to({y:753.55,alpha:0.3056},0).wait(1).to({y:766.75,alpha:0.4375},0).wait(1).to({y:778.55,alpha:0.5556},0).wait(1).to({y:788.95,alpha:0.6597},0).wait(1).to({y:798,alpha:0.75},0).wait(1).to({y:805.6,alpha:0.8264},0).wait(1).to({y:811.85,alpha:0.8889},0).wait(1).to({y:816.75,alpha:0.9375},0).wait(1).to({y:820.2,alpha:0.9722},0).wait(1).to({y:822.3,alpha:0.9931},0).wait(1).to({y:823,alpha:1},0).wait(17));

	// _
	this.instance_3 = new lib._5_12();
	this.instance_3.parent = this;
	this.instance_3.setTransform(80,743,1,1,0,0,0,80,103);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(6).to({_off:false},0).wait(1).to({y:758.95,alpha:0.1597},0).wait(1).to({y:773.55,alpha:0.3056},0).wait(1).to({y:786.75,alpha:0.4375},0).wait(1).to({y:798.55,alpha:0.5556},0).wait(1).to({y:808.95,alpha:0.6597},0).wait(1).to({y:818,alpha:0.75},0).wait(1).to({y:825.6,alpha:0.8264},0).wait(1).to({y:831.85,alpha:0.8889},0).wait(1).to({y:836.75,alpha:0.9375},0).wait(1).to({y:840.2,alpha:0.9722},0).wait(1).to({y:842.3,alpha:0.9931},0).wait(1).to({y:843,alpha:1},0).wait(19));

	// _
	this.instance_4 = new lib._4_13();
	this.instance_4.parent = this;
	this.instance_4.setTransform(280,550,1,1,0,0,0,120,170);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(4).to({_off:false},0).wait(1).to({y:565.95,alpha:0.1597},0).wait(1).to({y:580.55,alpha:0.3056},0).wait(1).to({y:593.75,alpha:0.4375},0).wait(1).to({y:605.55,alpha:0.5556},0).wait(1).to({y:615.95,alpha:0.6597},0).wait(1).to({y:625,alpha:0.75},0).wait(1).to({y:632.6,alpha:0.8264},0).wait(1).to({y:638.85,alpha:0.8889},0).wait(1).to({y:643.75,alpha:0.9375},0).wait(1).to({y:647.2,alpha:0.9722},0).wait(1).to({y:649.3,alpha:0.9931},0).wait(1).to({y:650,alpha:1},0).wait(21));

	// _
	this.instance_5 = new lib._1_15();
	this.instance_5.parent = this;
	this.instance_5.setTransform(1091,340,1,1,0,0,0,37,80);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(2).to({_off:false},0).wait(1).to({y:349.55,alpha:0.1597},0).wait(1).to({y:358.3,alpha:0.3056},0).wait(1).to({y:366.25,alpha:0.4375},0).wait(1).to({y:373.3,alpha:0.5556},0).wait(1).to({y:379.55,alpha:0.6597},0).wait(1).to({y:385,alpha:0.75},0).wait(1).to({y:389.55,alpha:0.8264},0).wait(1).to({y:393.3,alpha:0.8889},0).wait(1).to({y:396.25,alpha:0.9375},0).wait(1).to({y:398.3,alpha:0.9722},0).wait(1).to({y:399.55,alpha:0.9931},0).wait(1).to({y:400,alpha:1},0).wait(23));

	// _
	this.instance_6 = new lib._3_15();
	this.instance_6.parent = this;
	this.instance_6.setTransform(1114,400,1,1,0,0,0,46,80);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(7).to({_off:false},0).wait(1).to({x:1123.55,alpha:0.1597},0).wait(1).to({x:1132.3,alpha:0.3056},0).wait(1).to({x:1140.25,alpha:0.4375},0).wait(1).to({x:1147.3,alpha:0.5556},0).wait(1).to({x:1153.55,alpha:0.6597},0).wait(1).to({x:1159,alpha:0.75},0).wait(1).to({x:1163.55,alpha:0.8264},0).wait(1).to({x:1167.3,alpha:0.8889},0).wait(1).to({x:1170.25,alpha:0.9375},0).wait(1).to({x:1172.3,alpha:0.9722},0).wait(1).to({x:1173.55,alpha:0.9931},0).wait(1).to({x:1174,alpha:1},0).wait(18));

	// _
	this.instance_7 = new lib._2_15();
	this.instance_7.parent = this;
	this.instance_7.setTransform(1067,400,1,1,0,0,0,47,80);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(7).to({_off:false},0).wait(1).to({x:1057.4,alpha:0.1597},0).wait(1).to({x:1048.65,alpha:0.3056},0).wait(1).to({x:1040.75,alpha:0.4375},0).wait(1).to({x:1033.65,alpha:0.5556},0).wait(1).to({x:1027.4,alpha:0.6597},0).wait(1).to({x:1022,alpha:0.75},0).wait(1).to({x:1017.4,alpha:0.8264},0).wait(1).to({x:1013.65,alpha:0.8889},0).wait(1).to({x:1010.75,alpha:0.9375},0).wait(1).to({x:1008.65,alpha:0.9722},0).wait(1).to({x:1007.4,alpha:0.9931},0).wait(1).to({x:1007,alpha:1},0).wait(18));

	// Layer_6
	this.instance_8 = new lib._1();
	this.instance_8.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(37));

	// ________EditBox_______
	this.instance_9 = new lib.EditBox();
	this.instance_9.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(37));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1316.1,1046);


// stage content:
(lib.johnsons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(640,480,676.0999999999999,480);
// library properties:
lib.properties = {
	id: '284D0C179085334E961662CC8FA93117',
	width: 1280,
	height: 960,
	fps: 24,
	color: "#000000",
	opacity: 1.00,
	manifest: [
		{src:"images/_1.png", id:"_1"},
		{src:"images/_1pngcopy.png", id:"_1pngcopy"},
		{src:"images/_1pngcopy10.png", id:"_1pngcopy10"},
		{src:"images/_1pngcopy11.png", id:"_1pngcopy11"},
		{src:"images/_1pngcopy12.png", id:"_1pngcopy12"},
		{src:"images/_1pngcopy13.png", id:"_1pngcopy13"},
		{src:"images/_1pngcopy14.png", id:"_1pngcopy14"},
		{src:"images/_1pngcopy2.png", id:"_1pngcopy2"},
		{src:"images/_1pngcopy3.png", id:"_1pngcopy3"},
		{src:"images/_1pngcopy4.png", id:"_1pngcopy4"},
		{src:"images/_1pngcopy5.png", id:"_1pngcopy5"},
		{src:"images/_1pngcopy6.png", id:"_1pngcopy6"},
		{src:"images/_1pngcopy7.png", id:"_1pngcopy7"},
		{src:"images/_1pngcopy8.png", id:"_1pngcopy8"},
		{src:"images/_1pngcopy9.png", id:"_1pngcopy9"},
		{src:"images/_2.png", id:"_2"},
		{src:"images/_2pngcopy.png", id:"_2pngcopy"},
		{src:"images/_2pngcopy10.png", id:"_2pngcopy10"},
		{src:"images/_2pngcopy11.png", id:"_2pngcopy11"},
		{src:"images/_2pngcopy12.png", id:"_2pngcopy12"},
		{src:"images/_2pngcopy2.png", id:"_2pngcopy2"},
		{src:"images/_2pngcopy3.png", id:"_2pngcopy3"},
		{src:"images/_2pngcopy4.png", id:"_2pngcopy4"},
		{src:"images/_2pngcopy5.png", id:"_2pngcopy5"},
		{src:"images/_2pngcopy6.png", id:"_2pngcopy6"},
		{src:"images/_2pngcopy7.png", id:"_2pngcopy7"},
		{src:"images/_2pngcopy8.png", id:"_2pngcopy8"},
		{src:"images/_2pngcopy9.png", id:"_2pngcopy9"},
		{src:"images/_3.png", id:"_3"},
		{src:"images/_3pngcopy.png", id:"_3pngcopy"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['284D0C179085334E961662CC8FA93117'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;