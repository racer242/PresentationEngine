(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.aveeno_title = function() {
	this.initialize(img.aveeno_title);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,745,47);


(lib.bengeylogo = function() {
	this.initialize(img.bengeylogo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,217,58);


(lib.Bitmap13 = function() {
	this.initialize(img.Bitmap13);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,138,27);


(lib.Bitmap18 = function() {
	this.initialize(img.Bitmap18);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2667,1666);


(lib.Bitmap25 = function() {
	this.initialize(img.Bitmap25);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,152,46);


(lib.Bitmap26 = function() {
	this.initialize(img.Bitmap26);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,446,360);


(lib.Bitmap28 = function() {
	this.initialize(img.Bitmap28);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,213,53);


(lib.Bitmap30 = function() {
	this.initialize(img.Bitmap30);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,224,60);


(lib.dicloranSmallLogo = function() {
	this.initialize(img.dicloranSmallLogo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,210,57);


(lib.HexoBroncho = function() {
	this.initialize(img.HexoBroncho);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,98,56);


(lib.hexorallogo = function() {
	this.initialize(img.hexorallogo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,185,44);


(lib.imodiumLogo = function() {
	this.initialize(img.imodiumLogo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,178,38);


(lib.imofloralogo = function() {
	this.initialize(img.imofloralogo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,206,36);


(lib.listerine = function() {
	this.initialize(img.listerine);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,133,24);


(lib.logo = function() {
	this.initialize(img.logo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,242,60);


(lib.logo_alergy = function() {
	this.initialize(img.logo_alergy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,87,54);


(lib.logoMom = function() {
	this.initialize(img.logoMom);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,161,154);


(lib.motilegas_icon = function() {
	this.initialize(img.motilegas_icon);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,202,62);


(lib.motrine = function() {
	this.initialize(img.motrine);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,146,44);


(lib.neutrogena = function() {
	this.initialize(img.neutrogena);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,249,56);


(lib.nikorettelogo = function() {
	this.initialize(img.nikorettelogo);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,162,28);


(lib.ob_title = function() {
	this.initialize(img.ob_title);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,70,44);


(lib.penaten = function() {
	this.initialize(img.penaten);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,61,61);


(lib.topSplitter = function() {
	this.initialize(img.topSplitter);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1,67);


(lib.tyzine = function() {
	this.initialize(img.tyzine);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,93,40);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.visin_logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0054A6").s().p("AguBQQgVgNgMgVQgNgVAAgZQAAgZANgVQAMgVAVgMQAVgNAZAAQAaAAAVANQAVAMAMAVQANAVAAAZQAAAZgNAVQgMAVgVANQgVAMgaABQgZgBgVgMgAgmhBQgRAKgKARQgLARAAAVQAAAVALARQAKASARAKQASAKAUABQAVgBASgKQARgKAKgSQAKgRAAgVQAAgVgKgRQgKgRgRgKQgSgKgVgBQgUABgSAKgAAVAyIgBgFIgBgJQAAgPgFgEQgEgGgOABIgLAAIAAAmIgXAAIAAhlIAlAAQAKAAAKACQAKACAHAHQAHAGAAANQAAAKgEAFQgFAGgJACQAJAEAEAHQADAIABAPIAAAIIACAGgAgPgFIANAAQALAAAFgDQAGgEAAgHQAAgHgGgDQgFgDgLAAIgNAAg");
	this.shape.setTransform(182.925,7.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0054A6").s().p("AgREXIAkkQIgnAAIglEQIh6AAIBLouIB5AAIgcDWIAoAAIAcjWIB7AAIhLIug");
	this.shape_1.setTransform(154.7,43.35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0054A6").s().p("AAAEXIAokdIgFAAIhqEdIhtAAIBKouIBqAAIgmEXIAFAAIBokXIBuAAIhKIug");
	this.shape_2.setTransform(120.575,43.35);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0054A6").s().p("AiYEGQgWgUAJhHIAQh3IB8AAIgSCEQgBAMADAGQAEAFALAAQAKAAAFgGQAFgFABgMIASiPQADgXgYAAIgsAAIALhPIAqAAQAQAAAHgHQAFgGACgPIAMheQACgMgDgFQgDgHgMAAQgLAAgFAHQgEAFgCAMIgKBWIh8AAIAKhJQAJhHAagTQAdgVBeAAQBbAAAXAVQAWAUgKBGIgIA9QgFAngOAUQgQAVgjAIQAjAJAJAUQAIASgFAoIgOBpQgKBGgZATQgdAWhbAAQheAAgXgUg");
	this.shape_3.setTransform(86.9023,43.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0054A6").s().p("AAAEXIAokdIgFAAIhqEdIhtAAIBKouIBqAAIgmEXIAFAAIBokXIBuAAIhKIug");
	this.shape_4.setTransform(54.125,43.35);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0054A6").s().p("AjCFkIBfrIICkAAQBWAAAaAbQAaAagKBKIgNBeQgFAsgRAZQgRAagiAMQAhAOAKAaQAIAXgHAvIgRCCQgMBZgeAaQghAehlgBgAgQAZIggDuIANABQAQgBAIgHQAIgHACgRIAXixQACgQgGgIQgHgGgPgBgAgChOIAKABQASAAAHgIQAIgGACgSIARh7QACgRgFgHQgGgGgPgBIgPAAg");
	this.shape_5.setTransform(19.5408,35.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.visin_logo, new cjs.Rectangle(0,-2.2,192.2,73.8), null);


(lib.ReganeLogo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.logo();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ReganeLogo, new cjs.Rectangle(0,0,242,60), null);


(lib.drmom_logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.logoMom();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.6745,0.6745);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.drmom_logo, new cjs.Rectangle(0,0,108.6,103.9), null);


// stage content:
(lib.titles = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{empty:0,visine:9,metrogyl:19,imodium:29,dicloran:39,doktor_mom:49,motilium:59,nizoral:69,rinza:79,tyzine:89,gastro:99,microlax:109,imoflora:119,allergy:129,hexoral:139,nikorette:149,bengay:159,regaine:169,desitin:179,hexoralBroncho:189,motrine:199,aveeno:209,ob:219,johnsons:229,listerine:239,carefree:249,neutrogena:259,penaten:269,tyzinevisine:279,metrogyl_listerine:289,motiligas:299,stop00:4,stop01:14,stop02:24,stop03:34,stop04:44,stop05:54,stop06:64,stop07:74,stop08:84,stop09:94,stop10:104,stop11:114,stop12:124,stop13:134,stop14:144,stop15:154,stop16:164,stop17:174,stop18:184,stop19:194,stop20:204,stop21:214,stop22:224,stop23:234,stop24:244,stop25:254,stop26:264,"stop26":274,"stop26":284,"stop26":294,stop27:304});

	// Layer_3
	this.instance = new lib.topSplitter();
	this.instance.parent = this;
	this.instance.setTransform(559,2);

	this.instance_1 = new lib.visin_logo();
	this.instance_1.parent = this;
	this.instance_1.setTransform(160.65,34.6,0.4898,0.4898,0,0,0,86.4,35.8);

	this.instance_2 = new lib.topSplitter();
	this.instance_2.parent = this;
	this.instance_2.setTransform(262,2);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0079C0").s().p("AgkAkQgPgPAAgVQAAgVAPgPQAQgPAUAAQAWAAAPAPQAPAPAAAVQAAAVgPAPQgPAQgWAAQgUAAgQgQgAgdgdQgNAMAAARQAAASANANQAMAMARAAQASAAANgMQANgNAAgSQAAgRgNgMQgNgOgSAAQgRAAgMAOg");
	this.shape.setTransform(343.4165,25.9565,0.7229,0.7224);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0079C0").s().p("AANAeIgMgXIgDgDIgMAAIAAAaIgHAAIAAg7IAVAAQAHAAADACQADABACAEQACAEABAFQAAAIgEADQgEAEgGAAIAEAEIAFAIIAIAQgAgOgCIAOAAIAGgBIAEgEIABgGQAAgDgCgEQgEgCgEAAIgPAAg");
	this.shape_1.setTransform(343.6876,25.8843,0.7229,0.7224);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0079C0").s().p("AhMBOQghgfAAgwQAAgpAcgfQAfgiAzgBQA2ABAbApIABAAIAAgkIAbAAIAADOIgbAAIAAgnIgBAAQgcArg0AAQgvAAgfgegAg5g6QgYAYABAjQgBAjAZAYQAYAXAiAAQAhAAAYgXQAYgYAAgjQAAgigYgYQgYgZgiAAQgiAAgYAYg");
	this.shape_2.setTransform(329.6992,36.0342,0.7229,0.7224);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0079C0").s().p("AgNBoIAAi1Ig1AAIAAgZICGAAIAAAZIg2AAIAAC1g");
	this.shape_3.setTransform(315.4216,36.0342,0.7229,0.7224);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0079C0").s().p("AA6BoIAAheIhzAAIAABeIgcAAIAAjOIAcAAIAABYIBzAAIAAhYIAcAAIAADOg");
	this.shape_4.setTransform(302.2645,36.0342,0.7229,0.7224);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0079C0").s().p("AhLBOQgfgfAAgvQAAgpAbggQAfgiAxgBQA2ABAcAnQAYAgAAAuIi4AAQACAfAWAVQAXAVAfAAQAYAAATgNQATgNAKgVIAdAAQgNAigaATQgbATgjAAQgtAAgfgegAgyg/QgWATgFAeICaAAQgGgggWgSQgVgSgbAAQgdAAgWATg");
	this.shape_5.setTransform(285.4387,36.0342,0.7229,0.7224);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0079C0").s().p("AB1CnIAAg1IjpAAIAAA1IgcAAIAAhPIAZAAIBpj+IAdAAIBpD+IAZAAIAABPgAhYBYICxAAIhZjag");
	this.shape_6.setTransform(265.8477,35.2937,0.7229,0.7224);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#0079C0").s().p("ABIBoIhIirIhICrIgeAAIBYjOIAdAAIBYDOg");
	this.shape_7.setTransform(241.1059,36.0342,0.7229,0.7224);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#0079C0").s().p("AA+BoIAAinIh7CnIgcAAIAAjOIAcAAIAACmIB7imIAcAAIAADOg");
	this.shape_8.setTransform(225.2198,36.0342,0.7229,0.7224);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#0079C0").s().p("Ag1BoIAAjOIBrAAIAAAZIhPAAIAAC1g");
	this.shape_9.setTransform(212.7676,36.0342,0.7229,0.7224);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#0079C0").s().p("AhMBOQgfgfAAgvQAAgtAfgfQAfggAtAAQAuAAAfAgQAfAfAAAtQAAAvgfAfQgfAeguAAQgtAAgfgegAg5g6QgWAXAAAjQAAAkAWAXQAXAYAiAAQAjAAAXgYQAWgXAAgkQAAgjgWgXQgXgYgjAAQgiAAgXAYg");
	this.shape_10.setTransform(198.1828,36.0342,0.7229,0.7224);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#0079C0").s().p("AhsCPIAAkXIAaAAIAAAjIABAAQAdgpA0AAQAyABAfAiQAcAgAAArQAAAtgfAfQggAfgvgBQg0AAgbgrIAAAAIAABwgAg7hbQgXAYAAAjQAAAiAXAYQAXAXAjAAQAiAAAYgXQAYgYAAgjQAAgigYgZQgXgYgiAAQgkAAgXAZg");
	this.shape_11.setTransform(180.146,38.4904,0.7229,0.7224);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#0079C0").s().p("AgNBoIAAi1Ig2AAIAAgZICGAAIAAAZIg1AAIAAC1g");
	this.shape_12.setTransform(165.3082,36.0342,0.7229,0.7224);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0079C0").s().p("AhLBOQgfgfAAgvQAAgpAbggQAfgiAxgBQA2ABAdAnQAYAggBAuIi4AAQADAfAVAVQAWAVAgAAQAYAAATgNQATgNAKgVIAdAAQgMAigbATQgbATgjAAQgtAAgfgegAgyg/QgWATgFAeICaAAQgGgggWgSQgVgSgbAAQgdAAgWATg");
	this.shape_13.setTransform(151.1936,36.0342,0.7229,0.7224);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#0079C0").s().p("AB2CMIAAj4IhqD4IgXAAIhqj4IAAD4IgcAAIAAkXIArAAIBmDuIBnjuIArAAIAAEXg");
	this.shape_14.setTransform(129.7226,33.3793,0.7229,0.7224);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#004B8A").s().p("AAZBVIAAhUIgrBUIgnAAIAAh6IAhAAIAABTIArhTIAnAAIAAB6gAAAgyQgRABgLgJQgKgIAAgTIANAAQACAJAHAEQAHADAJAAQAKAAAHgDQAHgEABgJIAOAAQAAATgLAIQgKAIgQAAIgCAAg");
	this.shape_15.setTransform(838.075,36.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#004B8A").s().p("AgfA5QgOgHgIgPQgIgPAAgTQAAgTAIgPQAIgPAOgHQAOgKARABQATgBAOAKQAOAIAHAQQAHAPABAWIAAACIhYAAQAAARAIAIQAHAJANAAQAJAAAGgFQAGgEAEgJIAhAAQgGATgQALQgPALgVAAQgTAAgOgIgAAbgMQgBgHgDgHQgDgGgFgEQgGgDgJAAQgKAAgHAGQgIAIgBANIA1AAIAAAAg");
	this.shape_16.setTransform(824.125,38.75);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#004B8A").s().p("AgfA5QgOgHgIgPQgIgPAAgTQAAgTAIgPQAIgPAOgHQAOgKARABQATgBAOAKQAOAIAHAQQAHAPABAWIAAACIhYAAQAAARAIAIQAHAJANAAQAJAAAGgFQAGgEAEgJIAhAAQgGATgQALQgPALgVAAQgTAAgOgIgAAbgMQgBgHgDgHQgDgGgFgEQgGgDgJAAQgKAAgHAGQgIAIgBANIA1AAIAAAAg");
	this.shape_17.setTransform(810.325,38.75);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#004B8A").s().p("Ag+BWIAAinIAgAAIAAAPQAHgJAKgFQAJgFALAAQARABAMAIQANAIAHAPQAGAPABAUQgBASgGAOQgGAPgNAIQgLAIgRAAQgLAAgJgFQgLgEgGgKIAAA8gAgVgvQgJAKABASQgBASAJAJQAHAKAOAAQANAAAIgKQAIgJgBgRQAAgTgHgKQgIgKgNAAQgOAAgHAKg");
	this.shape_18.setTransform(796.3,40.775);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#004B8A").s().p("AgwA3QgMgJABgSQAAgMAEgHQAGgIAHgCQAIgFAKgCIATgCQAPgCAHgDQAHgDgBgHQAAgJgFgDQgGgFgKAAQgLAAgGAFQgFAEgCAKIggAAQACgUAOgLQAPgKAaAAIATABQAJACAIAEQAHAEAFAIQAGAIAAANIAAA0IAAARQAAAJADAIIgiAAIgCgGIgBgGQgHAIgLAEQgJAEgLgBQgVAAgMgKgAAMAGIgMACIgMACQgFACgEAEQgDADAAAHQAAAJAEAEQAGAEAIABQANgBAIgHQAIgHAAgNIAAgOQgFADgGABg");
	this.shape_19.setTransform(781.65,38.75);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#004B8A").s().p("AAZA+IAAhTIgrBTIgnAAIAAh7IAhAAIAABTIArhTIAnAAIAAB7g");
	this.shape_20.setTransform(767.775,38.75);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#004B8A").s().p("AAoBQIAAgkIhQAAIAAAkIgfAAIAAg+IAOAAQAEgIADgLQAEgMADgPQACgPgBgPIAAgVIBjAAIAABhIAQAAIAAA+gAgJgzQAAANgDAOQgCANgDALIgHASIAuAAIAAhIIgfAAg");
	this.shape_21.setTransform(753.05,40.575);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#004B8A").s().p("AgeA5QgOgIgIgOQgIgOAAgUQAAgTAIgPQAIgPAOgIQAOgIATAAQAZAAAPAMQAPANADAWIgiAAQgCgLgGgFQgGgGgKAAQgNAAgIALQgIAKAAATQAAASAIAKQAHAKANAAQALAAAHgGQAGgGACgNIAhAAQgDAZgQANQgPANgZAAQgSAAgOgIg");
	this.shape_22.setTransform(732.125,38.725);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#004B8A").s().p("AAdA+IAAguIgOAAIgjAuIgqAAIApgwQgIgCgIgFQgHgFgEgHQgEgIAAgKQAAgLAFgJQAGgIAJgFQAJgEAMgBIBKAAIAAB7gAgNghQgFAEABAHQgBAIAFADQAEADALAAIAbAAIAAgcIgbAAQgLAAgEADg");
	this.shape_23.setTransform(710.825,38.75);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#004B8A").s().p("AgeA5QgOgIgIgOQgIgOAAgUQAAgTAIgPQAIgPAOgIQAOgIATAAQAZAAAPAMQAPANADAWIgiAAQgCgLgGgFQgGgGgKAAQgNAAgIALQgIAKAAATQAAASAIAKQAHAKANAAQALAAAHgGQAGgGACgNIAhAAQgDAZgQANQgPANgZAAQgSAAgOgIg");
	this.shape_24.setTransform(697.875,38.725);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#004B8A").s().p("AgQA+IAAhhIgpAAIAAgaIBzAAIAAAaIgpAAIAABhg");
	this.shape_25.setTransform(684.925,38.75);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#004B8A").s().p("AgfA5QgOgHgIgPQgIgPAAgTQAAgTAIgPQAIgPAOgHQAOgKARABQATgBAOAKQAOAIAHAQQAHAPABAWIAAACIhYAAQAAARAIAIQAHAJANAAQAJAAAGgFQAGgEAEgJIAhAAQgGATgQALQgPALgVAAQgTAAgOgIgAAbgMQgBgHgDgHQgDgGgFgEQgGgDgJAAQgKAAgHAGQgIAIgBANIA1AAIAAAAg");
	this.shape_26.setTransform(672.075,38.75);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#004B8A").s().p("Ag+BWIAAinIAgAAIAAAPQAHgJAKgFQAKgFAKAAQARABAMAIQANAIAHAPQAGAPABAUQgBASgGAOQgHAPgMAIQgMAIgQAAQgLAAgJgFQgKgEgHgKIAAA8gAgVgvQgJAKABASQgBASAJAJQAHAKAOAAQANAAAIgKQAIgJgBgRQAAgTgIgKQgHgKgNAAQgOAAgHAKg");
	this.shape_27.setTransform(658.05,40.775);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#004B8A").s().p("AghA5QgOgIgIgPQgIgOAAgUQAAgTAIgPQAIgOAPgIQAOgJATAAQASAAAPAJQAOAIAIAOQAIAPAAATQAAAUgIAPQgIAOgPAIQgNAIgUABQgSgBgPgIgAgVgcQgIAKAAASQAAATAIAKQAHALAOAAQAOAAAIgLQAHgKABgTQgBgSgHgKQgIgLgOAAQgOAAgHALg");
	this.shape_28.setTransform(643.15,38.775);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#004B8A").s().p("AgdBTQgMgHgHgLQgHgLgDgNQgDgOgBgNIACgcQABgOAGgOQAEgNALgKQAJgKASgEQAHgCAHgBIAOgCQAGgBACgEIAgAAQgCAPgJAIQgIAIgMADQgNADgNABQgPACgKAHQgJAHgEAKQgEALgCAMIABAAQAEgIAFgIQAHgIAKgFQAJgFAOgBQAQABANAHQAMAIAHAOQAIANABAUQgBATgIAPQgIAOgOAIQgPAIgSAAQgRAAgLgHgAgTgBQgIAIAAATQAAATAIAJQAHAKAMAAQANAAAHgKQAIgKAAgTQAAgSgIgJQgHgJgNAAQgMAAgHAKg");
	this.shape_29.setTransform(628.6,36.325);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#004B8A").s().p("AghA5QgOgIgIgPQgIgOAAgUQAAgTAIgPQAIgOAOgIQAPgJASAAQAUAAAOAJQAOAIAIAOQAHAPABATQgBAUgHAPQgIAOgOAIQgPAIgTABQgTgBgOgIgAgVgcQgIAKAAASQAAATAIAKQAIALANAAQAOAAAIgLQAIgKgBgTQABgSgIgKQgIgLgOAAQgNAAgIALg");
	this.shape_30.setTransform(607.2,38.775);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#004B8A").s().p("AAYA+IAAg0IgvAAIAAA0IgiAAIAAh7IAiAAIAAAtIAvAAIAAgtIAiAAIAAB7g");
	this.shape_31.setTransform(592.725,38.75);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#004B8A").s().p("AA7A+Igeg0IgNAPIAAAlIgfAAIAAglIgNgPIgeA0IgoAAIAvhMIgqgvIAnAAIAnAyIAAgyIAfAAIAAAyIAngyIAnAAIgrAwIAwBLg");
	this.shape_32.setTransform(575.725,38.75);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#004B8A").s().p("AgfA5QgOgHgIgPQgIgPAAgTQAAgTAIgPQAIgPAOgHQAOgKARABQATgBAOAKQAOAIAHAQQAHAPABAWIAAACIhYAAQAAARAIAIQAHAJANAAQAJAAAGgFQAGgEAEgJIAhAAQgGATgQALQgPALgVAAQgTAAgOgIgAAbgMQgBgHgDgHQgDgGgFgEQgGgDgJAAQgKAAgHAGQgIAIgBANIA1AAIAAAAg");
	this.shape_33.setTransform(559.025,38.75);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#004B8A").s().p("Ag+BWIAAinIAgAAIAAAPQAHgJAKgFQAKgFALAAQAQABAMAIQANAIAHAPQAGAPABAUQgBASgGAOQgHAPgMAIQgMAIgQAAQgLAAgJgFQgKgEgHgKIAAA8gAgVgvQgIAKAAASQAAASAIAJQAHAKAOAAQANAAAIgKQAHgJAAgRQABgTgJgKQgHgKgNAAQgOAAgHAKg");
	this.shape_34.setTransform(545,40.775);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#004B8A").s().p("AgfA5QgOgHgIgPQgIgPAAgTQAAgTAIgPQAIgPAOgHQAOgKARABQATgBAOAKQAOAIAHAQQAHAPABAWIAAACIhYAAQAAARAIAIQAHAJANAAQAJAAAGgFQAGgEAEgJIAhAAQgGATgQALQgPALgVAAQgTAAgOgIgAAbgMQgBgHgDgHQgDgGgFgEQgGgDgJAAQgKAAgHAGQgIAIgBANIA1AAIAAAAg");
	this.shape_35.setTransform(530.575,38.75);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#004B8A").s().p("AgdBTQgMgHgHgLQgHgLgDgNQgEgOAAgNIACgcQACgOAEgOQAGgNAKgKQAKgKARgEQAHgCAHgBIANgCQAHgBABgEIAhAAQgCAPgJAIQgIAIgMADQgMADgOABQgPACgKAHQgIAHgFAKQgEALgCAMIABAAQAEgIAFgIQAGgIAKgFQAKgFAOgBQAPABANAHQANAIAHAOQAIANAAAUQAAATgIAPQgHAOgPAIQgPAIgTAAQgQAAgLgHgAgUgBQgHAIAAATQAAATAHAJQAIAKAMAAQANAAAIgKQAHgKAAgTQAAgSgHgJQgIgJgNAAQgMAAgIAKg");
	this.shape_36.setTransform(516.4,36.325);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#004B8A").s().p("AAZA+IAAhTIgrBTIgnAAIAAh7IAhAAIAABTIArhTIAnAAIAAB7g");
	this.shape_37.setTransform(495.175,38.75);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#004B8A").s().p("AABA2IAAhGIgZAAIAAgQIADAAQALABAIgGQAGgFADgLIASAAIAABrg");
	this.shape_38.setTransform(476.425,31.9);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#004B8A").s().p("AghA5QgOgIgIgPQgIgOAAgUQAAgTAIgPQAIgOAOgIQAPgJASAAQAUAAAOAJQAOAIAIAOQAHAPABATQgBAUgHAPQgIAOgOAIQgPAIgTABQgTgBgOgIgAgVgcQgIAKAAASQAAATAIAKQAIALANAAQAOAAAIgLQAIgKgBgTQABgSgIgKQgIgLgOAAQgNAAgIALg");
	this.shape_39.setTransform(465.45,38.775);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#004B8A").s().p("Ag+BWIAAinIAgAAIAAAPQAHgJAKgFQAKgFAKAAQARABAMAIQANAIAHAPQAGAPABAUQgBASgGAOQgHAPgMAIQgMAIgQAAQgLAAgJgFQgKgEgHgKIAAA8gAgVgvQgJAKABASQgBASAJAJQAHAKAOAAQANAAAIgKQAIgJgBgRQAAgTgIgKQgHgKgNAAQgOAAgHAKg");
	this.shape_40.setTransform(451.05,40.775);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#004B8A").s().p("AgQA+IAAhhIgpAAIAAgaIBzAAIAAAaIgpAAIAABhg");
	this.shape_41.setTransform(437.475,38.75);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#004B8A").s().p("AgeA5QgOgIgIgOQgIgOAAgUQAAgTAIgPQAIgPAOgIQAOgIATAAQAZAAAPAMQAPANADAWIgiAAQgCgLgGgFQgGgGgKAAQgNAAgIALQgIAKAAATQAAASAIAKQAHAKANAAQALAAAHgGQAGgGACgNIAhAAQgDAZgQANQgPANgZAAQgSAAgOgIg");
	this.shape_42.setTransform(424.625,38.725);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#004B8A").s().p("AAsA+IAAh7IAiAAIAAB7gAhMA+IAAh7IAhAAIAAArIAaAAQANAAAKAEQAKAFAGAJQAGAIAAANQAAAOgGAJQgGAJgKAEQgKAFgOAAgAgrAmIARAAQAJAAAGgDQAGgFgBgJQABgIgGgFQgGgEgJAAIgRAAg");
	this.shape_43.setTransform(408.75,38.75);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#004B8A").s().p("AhGBVIAAiqIB+AAIAAAgIhZAAIAAAeIAsAAQARAAAOAGQANAGAIALQAIAMAAASQAAAUgIAMQgIALgOAHQgOAFgSAAgAghA3IAnAAQANAAAIgGQAIgFAAgOQAAgOgIgFQgIgGgNABIgnAAg");
	this.shape_44.setTransform(391.775,36.4);

	this.instance_3 = new lib.imodiumLogo();
	this.instance_3.parent = this;
	this.instance_3.setTransform(113,15);

	this.instance_4 = new lib.dicloranSmallLogo();
	this.instance_4.parent = this;
	this.instance_4.setTransform(118,9,0.9429,0.9429);

	this.instance_5 = new lib.drmom_logo();
	this.instance_5.parent = this;
	this.instance_5.setTransform(147.7,38.65,0.5277,0.5277,0,0,0,54.4,58.1);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#08724A").s().p("AgVAVQgIgJAAgMQAAgMAIgIQAJgJAMAAQANAAAIAJQAJAJAAALQAAAMgJAIQgJAKgMAAQgLAAgKgJgAgPgRQgIAIAAAJQAAAJAIAIQAFAHAKAAQAJAAAHgHQAIgHgBgKQABgJgIgIQgIgGgIgBQgJABgGAGgAAGARIgGgOIgEAAIAAAOIgHAAIAAgiIALAAQAMAAAAAKQAAAHgGABIAHAQgAgEgBIAEAAQAFAAAAgGQAAgEgFAAIgEAAg");
	this.shape_45.setTransform(319.4147,28.4238,0.7169,0.7169);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#F58220").s().p("AgjBIQgPgCgKgLQgIgIgDgMIgBgRIABgJIAGALQAJAMAKAGQAMAHAOgCQARgCAOgPQAegcAPgnIAJgjIAEAOQAEAPgBAPQgCApggAfQgcAdghAAIgMgBg");
	this.shape_46.setTransform(162.9852,40.3752,0.7169,0.7169);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#08724A").s().p("AhdCYQgugNgWgkQgRgcAAghIAAgCQAAgsAbgsQAcgtAugeQAigVArgKQAWgEASAAQAnAAAgAPQAgAPATAdQAgAygbBBQgZBBhCAoQglAWgnAKQgYAGgXAAQgYAAgWgHgAAAheQgkALgbAcQgbAegFAqQgFAtAaAYQAfAcArgQQA5gUAdg8QAeg/grgnQgNgMgUgCIgLgBQgOAAgPAFg");
	this.shape_47.setTransform(163.0727,39.6213,0.7169,0.7169);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#08724A").s().p("AB3DYIAAlhIgBAAIhLFhIhRAAIhPlhIgBAAIAAFhIhOAAIAAmvIB6AAIBNFTIACAAIBHlTIB5AAIAAGvg");
	this.shape_48.setTransform(133.1054,35.4496,0.7169,0.7169);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#08724A").s().p("AgmCgIAAj8IhYAAIAAhDID9AAIAABDIhYAAIAAD8g");
	this.shape_49.setTransform(186.6413,39.4464,0.7169,0.7169);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#08724A").s().p("AA6CgIAAjAIhtDAIhXAAIAAk/IBRAAIAAC/IBti/IBWAAIAAE/g");
	this.shape_50.setTransform(208.113,39.4464,0.7169,0.7169);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#08724A").s().p("AicBfQAaAGANgCQAVgFAAgYIAAjoID9AAIAAE+IhGAAIAAj7IhvAAIAACKIgBAqQgBAWgHAMQgUAlghAGQgEABhCAAg");
	this.shape_51.setTransform(232.0043,39.6973,0.7169,0.7169);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#08724A").s().p("AA3CgIAAjAIhoDAIhUAAIAAk/IBPAAIAAC/IBoi/IBUAAIAAE/g");
	this.shape_52.setTransform(256.3437,39.4464,0.7169,0.7169);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#08724A").s().p("AhrDfIAAhDIAQAAQAZAAALgIQAMgKAFgdIhwlLIBZAAIBADpIABAAIA+jpIBVAAIhpE5QgOAtgLAbQgJAYgMAOQgMAPgOADQgRAEgcABg");
	this.shape_53.setTransform(278.9805,44.0168,0.7169,0.7169);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#08724A").s().p("ABlCgIgBj6IgJAAIg8D6Ig9AAIg+j4IgIAAIABD4IhFAAIAAk/IB1AAIAzDuIABAAIA5juIBvAAIAAE/g");
	this.shape_54.setTransform(303.8755,39.4464,0.7169,0.7169);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.bf(img.Bitmap18, null, new cjs.Matrix2D(0.403,0,0,0.403,-166.7,-30.2)).s().p("AtkDqIAAnWIbJAAIAAHZg");
	this.shape_55.setTransform(178.825,32.475);

	this.instance_6 = new lib.Bitmap13();
	this.instance_6.parent = this;
	this.instance_6.setTransform(128,20,1.1311,1.1307);

	this.instance_7 = new lib.tyzine();
	this.instance_7.parent = this;
	this.instance_7.setTransform(131,15);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#008C99").s().p("AglBDQgRgJgJgSQgJgQAAgYQAAgWAJgSQAJgQARgKQAQgKAVAAQAXAAAQAKQAQAJAJARQAJARAAAXQAAAYgJAQQgJASgQAJQgQAJgXAAQgVAAgQgJgAgdglQgKAOgBAXQABAZAKANQALAOASAAQAUAAAKgOQALgOAAgYQAAgYgLgNQgLgNgTgBQgSABgLANg");
	this.shape_56.setTransform(206.7,39);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#008C99").s().p("AhGBlIAAjFIAeAAIAAATQAHgMANgGQAMgFAOAAQAUAAAOAKQAPAJAIARQAIASAAAXQAAAXgIAQQgHAQgPAKQgOAJgUAAQgNAAgMgGQgMgEgJgNIAABJgAgdg9QgLAOAAAXQAAAYALAMQAKAOATAAQASAAALgOQAKgMAAgXQAAgYgLgOQgKgNgSAAQgTAAgKANg");
	this.shape_57.setTransform(190.225,41.45);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#008C99").s().p("AgPBIIAAh2IgwAAIAAgZIB+AAIAAAZIgvAAIAAB2g");
	this.shape_58.setTransform(174.85,38.975);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#008C99").s().p("AgjBDQgQgKgIgQQgJgRAAgWQAAgXAJgRQAJgSAQgJQAQgKAVAAQAcAAARAOQARAOADAZIggAAQgDgOgIgHQgJgIgNAAQgRABgLANQgKAOAAAXQAAAYAKAOQAKANARAAQAPAAAJgIQAJgJACgQIAgAAQgEAbgSAQQgRAPgcAAQgVAAgQgJg");
	this.shape_59.setTransform(160.725,38.925);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#008C99").s().p("AAkBIQgGgEgCgJQgKAJgNAEQgMAEgPAAQgWAAgOgLQgNgMAAgUQAAgOAGgJQAGgIAKgEQAJgEALgCIAXgDIARgDIAJgCIAEgEIACgEIAAgGQAAgLgGgGQgIgFgOAAQgPAAgIAGQgHAGgCAOIgfAAQADgbARgLQARgLAbAAQAQAAANAEQANAFAJAJQAHAKAAAPIAABJQAAAGABACQACADAFgBIACAAIAFAAIAAAWIgMADIgJAAQgJAAgGgEgAAKAGIgQACIgPADQgHACgFAFQgFAFAAAJQAAAKAHAGQAHAGAMAAQAKAAAHgDQAKgDAFgGQAFgFAAgGIABgOIAAgRQgHAEgJACg");
	this.shape_60.setTransform(145.35,38.925);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#008C99").s().p("AhCBkIAAjHICGAAIAAAfIhjAAIAACog");
	this.shape_61.setTransform(130.4,36.225);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#0E6CB6").s().p("AgnApQgQgQAAgZQAAgYAQgQQAPgQAYAAQAYAAAQARQAQAQAAAXQAAAYgQARQgQAQgYAAQgYAAgPgQgAgdgfQgNANAAASQAAAUAMANQAMAMASAAQASAAAMgNQAMgNAAgTQAAgSgMgNQgMgNgSAAQgRAAgMANgAAKAeIgDgEQgJgUgDAAIgBAAIAAAYIgNAAIAAg8IASAAIAKABQALAEAAALQAAAOgNACQADACANAWIACAEgAgGgEIACAAQALAAAAgIQAAgHgFAAIgGgBIgCAAg");
	this.shape_62.setTransform(344.999,26.2649,0.7292,0.7292);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#0E6CB6").s().p("AgWBpQgZgYgRgVIhIhdIAACKIhQAAIAAkzIBQAAIAABoIBihoIBbAAIh9CGIBkB/QBeByBfAeQiGgBhphhg");
	this.shape_63.setTransform(316.3596,37.6404,0.7292,0.7292);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#0E6CB6").s().p("AiNjVIAAAAQA5gUA7AAQBPAAAtAqQAsAqAABNQgBBHgsAsQgtAthFAAQgWAAgXgGIAACJIhQAPgAg9ihIAACvQATAHATAAQAnAAAXgYQAWgYgBgtQABgugXgYQgYgYgpAAQgSAAgQAFg");
	this.shape_64.setTransform(210.7346,39.2993,0.7292,0.7292);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#0E6CB6").s().p("AiSCaIgCgBIAAhHIACABIAKAAQATABAMgUQASgaARg6QAQg7AJhLIAAgBIDCAAIAAEzIhRAAIAAjsIg1AAQgIBEgQA1QgRA2gXAdQgdAkgxAAQgMAAgHgCg");
	this.shape_65.setTransform(259.1354,34.2132,0.7292,0.7292);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#0E6CB6").s().p("AhuB0QgrgtAAhHQAAhGArgtQArgtBDAAQBEAAArAtQArAtAABGQAABFgsAvQgrAthDAAQhDAAgrgtgAgzhFQgUAZAAAsQAAAsAUAaQATAZAgAAQAhAAATgZQATgaAAgsQAAgsgTgZQgTgZghgBQggABgTAZg");
	this.shape_66.setTransform(235.2905,33.9944,0.7292,0.7292);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#0E6CB6").s().p("ABBCaIAAiJQAAgeACgdIgmA6IheCKIhOAAIAAkzIBPAAIAACJQAAAXgCAkIAmg6IBfiKIBNAAIAAEzg");
	this.shape_67.setTransform(162.2609,34.0491,0.7292,0.7292);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#0E6CB6").s().p("ABlCoIAAiUIABg7IACgUIgKASQgKAWgTAdIgwBOIghAAIgwhOQgVgggIgTIgJgSIABAUQABAWAAAoIAACRIhPAAIAAlQIBRAAIAzBUQAUAfATAmIAJAQIADgHQAbgyARgcIAyhUIBSAAIAAFQg");
	this.shape_68.setTransform(133.4756,32.9371,0.7292,0.7292);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#0E6CB6").s().p("AAuCaIAAgBIhpiKIAACLIhQAAIAAkzIBQAAIAABoIBhhoIBcAAIh+CGICICtg");
	this.shape_69.setTransform(188.2934,34.0491,0.7292,0.7292);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#0E6CB6").s().p("Ag/CUQgcgLgUgVQgSgVgLgeQgKgcAAglQAAgiAKgeQAKgcAUgWQATgWAcgMQAdgLAhAAQAhAAAcALQALAFAPANIACgRIA/AAQgECYAECYIhMAAIAAgeQgPAWgXAHQgNAEgZAAQgiAAgcgMgAgbhTQgNAGgIAKQgIALgGARQgFARAAAWQAAAYAFAQQAGARAIALQAJALAMAFQAMAGAQgBQARABALgGQAMgFAJgLQAIgLAGgRQAFgTAAgVQAAgTgFgUQgGgRgIgLQgIgKgNgGQgMgGgSABQgOgBgMAGg");
	this.shape_70.setTransform(284.4752,33.7756,0.7292,0.7292);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#0E6CB6").s().p("AgVCWQgbgIgWgUQgVgUgMgdQgMgdAAgoQAAgpAOghQAOgfAWgUQAVgTAcgKQArgPAwAJQATAEAOAGIAEACIAABHIgIgDQgMgGgPgDQgggIgdAJQgOAGgJAKQgMALgFARQgHARAAAaQAAATAFAPQAEAPAKAMQAKAMANAGQAOAHAWAAQATAAAOgEQALgCASgHIAHgDIAABHIgEABQgNAGgUAFQgVAEgUAAQghAAgagKg");
	this.shape_71.setTransform(330.0321,34.0354,0.7292,0.7292);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#004B8A").s().p("AgSBVIAAgkIAlAAIAAAkgAgIAiIgJhIIAAgvIAjAAIAAAuIgKBJg");
	this.shape_72.setTransform(777.425,36.4);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#004B8A").s().p("AAVA+Igig2IgPAQIAAAmIgiAAIAAh7IAiAAIAAAxIAsgxIAoAAIgwAwIA3BLg");
	this.shape_73.setTransform(767.975,38.75);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#004B8A").s().p("AghA5QgOgIgIgPQgIgOAAgUQAAgTAIgPQAIgOAPgIQAOgJATAAQATAAAOAJQAOAIAIAOQAIAPAAATQAAAUgIAPQgIAOgPAIQgOAIgTABQgSgBgPgIgAgVgcQgIAKAAASQAAATAIAKQAHALAOAAQAOAAAIgLQAIgKAAgTQAAgSgIgKQgIgLgOAAQgOAAgHALg");
	this.shape_74.setTransform(726.75,38.775);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#004B8A").s().p("AgeBTQgLgHgHgLQgHgLgDgNQgDgOAAgNIABgcQABgOAFgOQAGgNAJgKQALgKAQgEQAIgCAHgBIANgCQAHgBABgEIAhAAQgDAPgHAIQgJAIgMADQgNADgNABQgQACgIAHQgKAHgEAKQgEALgBAMIABAAQACgIAHgIQAGgIAJgFQAKgFANgBQAQABANAHQANAIAIAOQAHANAAAUQAAATgHAPQgIAOgPAIQgPAIgTAAQgQAAgMgHgAgUgBQgHAIAAATQAAATAHAJQAIAKAMAAQANAAAIgKQAHgKAAgTQAAgSgHgJQgIgJgNAAQgMAAgIAKg");
	this.shape_75.setTransform(697.95,36.325);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#004B8A").s().p("Ag+BWIAAinIAgAAIAAAPQAHgJAKgFQAKgFAKAAQASABAMAIQAMAIAHAPQAHAPAAAUQAAASgHAOQgGAPgMAIQgNAIgQAAQgLAAgKgFQgKgEgGgKIAAA8gAgWgvQgIAKAAASQAAASAIAJQAIAKAOAAQANAAAIgKQAIgJAAgRQgBgTgHgKQgIgKgNAAQgOAAgIAKg");
	this.shape_76.setTransform(668.8,40.775);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#004B8A").s().p("AAYA+IAAhhIgvAAIAABhIgiAAIAAh7IBzAAIAAB7g");
	this.shape_77.setTransform(654.075,38.75);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#004B8A").s().p("AAsA+IAAh7IAhAAIAAB7gAhNA+IAAh7IAiAAIAAArIAbAAQANAAAIAEQALAFAGAJQAGAIAAANQAAAOgGAJQgGAJgLAEQgJAFgNAAgAgrAmIARAAQAJAAAGgDQAFgFABgJQgBgIgFgFQgGgEgJAAIgRAAg");
	this.shape_78.setTransform(617.15,38.75);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#004B8A").s().p("AAYA+IAAg0IgvAAIAAA0IgiAAIAAh7IAiAAIAAAtIAvAAIAAgtIAiAAIAAB7g");
	this.shape_79.setTransform(586.875,38.75);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#004B8A").s().p("AApA+IAAhdIgBAAIgYBdIgfAAIgYhdIgBAAIAABdIggAAIAAh7IAxAAIAXBZIAAAAIAYhZIAxAAIAAB7g");
	this.shape_80.setTransform(557.275,38.75);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#004B8A").s().p("Ag+BWIAAinIAgAAIAAAPQAHgJAKgFQAJgFALAAQASABALAIQANAIAHAPQAHAPAAAUQAAASgHAOQgHAPgLAIQgNAIgQAAQgLAAgKgFQgKgEgGgKIAAA8gAgVgvQgJAKABASQgBASAJAJQAHAKAOAAQANAAAIgKQAIgJAAgRQgBgTgHgKQgIgKgNAAQgOAAgHAKg");
	this.shape_81.setTransform(527.75,40.775);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#004B8A").s().p("Ag5A+IAAh7IBGAAQALAAAJAEQAJACAFAIQAGAGAAAMQAAAIgFAHQgEAGgIADQAKAEAGAGQAGAIAAAMQAAAMgFAIQgGAJgJAEQgKAEgMAAgAgYAoIAZAAIALgBQAFgBADgEQADgEAAgGQAAgIgDgDQgEgDgFgCIgLgBIgYAAgAgYgLIAXAAIAJgBQAEgBADgDQADgEAAgGQAAgIgGgDQgGgCgHAAIgXAAg");
	this.shape_82.setTransform(513.425,38.75);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#004B8A").s().p("AghA5QgOgIgIgPQgIgOAAgUQAAgTAIgPQAIgOAPgIQAOgJATAAQATAAAOAJQAOAIAIAOQAIAPAAATQAAAUgIAPQgIAOgPAIQgOAIgTABQgSgBgPgIgAgVgcQgIAKAAASQAAATAIAKQAHALAOAAQAOAAAIgLQAIgKAAgTQAAgSgIgKQgIgLgOAAQgOAAgHALg");
	this.shape_83.setTransform(499.05,38.775);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#004B8A").s().p("AAZBVIAAhUIgrBUIgnAAIAAh6IAhAAIAABTIArhTIAnAAIAAB6gAAAgyQgRABgLgJQgKgIAAgTIANAAQACAJAHAEQAHADAJAAQAKAAAHgDQAHgEABgJIAOAAQAAATgLAIQgKAIgQAAIgCAAg");
	this.shape_84.setTransform(464.125,36.4);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#004B8A").s().p("AArA+IAAh7IAjAAIAAB7gAhMA+IAAh7IAhAAIAAArIAaAAQANAAAJAEQALAFAGAJQAGAIAAANQAAAOgGAJQgGAJgLAEQgJAFgOAAgAgrAmIARAAQAKAAAFgDQAGgFAAgJQAAgIgGgFQgGgEgJAAIgRAAg");
	this.shape_85.setTransform(448.1,38.75);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#004B8A").s().p("Ag5A+IAAh7IBGAAQALAAAJAEQAJACAFAIQAGAGAAAMQAAAIgFAHQgEAGgIADQAKAEAGAGQAGAIAAAMQAAAMgFAIQgGAJgJAEQgKAEgMAAgAgYAoIAZAAIALgBQAFgBADgEQADgEAAgGQAAgIgDgDQgEgDgFgCIgLgBIgYAAgAgYgLIAXAAIAJgBQAEgBADgDQADgEAAgGQAAgIgGgDQgGgCgHAAIgXAAg");
	this.shape_86.setTransform(432.475,38.75);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#004B8A").s().p("AghA5QgOgIgIgPQgIgOAAgUQAAgTAIgPQAIgOAOgIQAPgJASAAQATAAAPAJQAOAIAIAOQAHAPABATQgBAUgHAPQgIAOgOAIQgOAIgUABQgTgBgOgIgAgVgcQgIAKAAASQAAATAIAKQAHALAOAAQAOAAAIgLQAIgKgBgTQABgSgIgKQgIgLgOAAQgNAAgIALg");
	this.shape_87.setTransform(418.1,38.775);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#004B8A").s().p("AAjBVIAAhJIhFAAIAABJIgmAAIAAiqIAmAAIAABBIBFAAIAAhBIAmAAIAACqg");
	this.shape_88.setTransform(401.85,36.4);

	this.instance_8 = new lib.imofloralogo();
	this.instance_8.parent = this;
	this.instance_8.setTransform(121,18);

	this.instance_9 = new lib.logo_alergy();
	this.instance_9.parent = this;
	this.instance_9.setTransform(129,8);

	this.instance_10 = new lib.hexorallogo();
	this.instance_10.parent = this;
	this.instance_10.setTransform(121,14);

	this.instance_11 = new lib.nikorettelogo();
	this.instance_11.parent = this;
	this.instance_11.setTransform(119,22);

	this.instance_12 = new lib.bengeylogo();
	this.instance_12.parent = this;
	this.instance_12.setTransform(119,12,0.8157,0.8157);

	this.instance_13 = new lib.ReganeLogo();
	this.instance_13.parent = this;
	this.instance_13.setTransform(194.55,35.55,0.5912,0.5912,0,0,0,121,30);
	this.instance_13.filters = [new cjs.ColorFilter(0, 0, 0, 1, 0, 0, 0, 0)];
	this.instance_13.cache(-2,-2,246,64);

	this.instance_14 = new lib.Bitmap25();
	this.instance_14.parent = this;
	this.instance_14.setTransform(116,13,1.0003,0.9989);

	this.instance_15 = new lib.HexoBroncho();
	this.instance_15.parent = this;
	this.instance_15.setTransform(123,5);

	this.instance_16 = new lib.motrine();
	this.instance_16.parent = this;
	this.instance_16.setTransform(106,11);

	this.instance_17 = new lib.aveeno_title();
	this.instance_17.parent = this;
	this.instance_17.setTransform(102,13);

	this.instance_18 = new lib.ob_title();
	this.instance_18.parent = this;
	this.instance_18.setTransform(155,11);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.bf(img.Bitmap26, null, new cjs.Matrix2D(0.847,0,0,0.847,-199.5,-182)).s().p("AsQFgIAAq+IYhAAIAAK+g");
	this.shape_89.setTransform(188.025,35.65);

	this.instance_19 = new lib.listerine();
	this.instance_19.parent = this;
	this.instance_19.setTransform(120,23);

	this.instance_20 = new lib.Bitmap30();
	this.instance_20.parent = this;
	this.instance_20.setTransform(93,5,0.9996,0.9975);

	this.instance_21 = new lib.neutrogena();
	this.instance_21.parent = this;
	this.instance_21.setTransform(104,10);

	this.instance_22 = new lib.penaten();
	this.instance_22.parent = this;
	this.instance_22.setTransform(162,9);

	this.instance_23 = new lib.Bitmap28();
	this.instance_23.parent = this;
	this.instance_23.setTransform(131,10,1.0007,1.0009);

	this.instance_24 = new lib.motilegas_icon();
	this.instance_24.parent = this;
	this.instance_24.setTransform(138,2);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#004B8A").s().p("AAlBVIglg7IgmA7IgrAAIA9hYIg4hSIAsAAIAhA4IAig4IApAAIg2BSIA8BYg");
	this.shape_90.setTransform(382.925,36.4);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#004B8A").s().p("AAlBVIglg7IgmA7IgrAAIA9hYIg4hSIAsAAIAhA4IAig4IApAAIg2BSIA8BYg");
	this.shape_91.setTransform(366.925,36.4);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#004B8A").s().p("AAlBVIglg7IgmA7IgrAAIA9hYIg4hSIAsAAIAhA4IAig4IApAAIg2BSIA8BYg");
	this.shape_92.setTransform(350.925,36.4);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#004B8A").s().p("AAlBVIglg7IgmA7IgrAAIA9hYIg4hSIAsAAIAhA4IAig4IApAAIg2BSIA8BYg");
	this.shape_93.setTransform(334.925,36.4);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#004B8A").s().p("AAlBVIglg7IgmA7IgrAAIA9hYIg4hSIAsAAIAhA4IAig4IApAAIg2BSIA8BYg");
	this.shape_94.setTransform(318.925,36.4);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#004B8A").s().p("AAlBVIglg7IgmA7IgrAAIA9hYIg4hSIAsAAIAhA4IAig4IApAAIg2BSIA8BYg");
	this.shape_95.setTransform(302.925,36.4);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#004B8A").s().p("AAlBVIglg7IgmA7IgrAAIA9hYIg4hSIAsAAIAhA4IAig4IApAAIg2BSIA8BYg");
	this.shape_96.setTransform(286.925,36.4);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#004B8A").s().p("AAlBVIglg7IgmA7IgrAAIA9hYIg4hSIAsAAIAhA4IAig4IApAAIg2BSIA8BYg");
	this.shape_97.setTransform(270.925,36.4);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#004B8A").s().p("AAlBVIglg7IgmA7IgrAAIA9hYIg4hSIAsAAIAhA4IAig4IApAAIg2BSIA8BYg");
	this.shape_98.setTransform(254.925,36.4);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#004B8A").s().p("AAlBVIglg7IgmA7IgrAAIA9hYIg4hSIAsAAIAhA4IAig4IApAAIg2BSIA8BYg");
	this.shape_99.setTransform(238.925,36.4);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#004B8A").s().p("AAlBVIglg7IgmA7IgrAAIA9hYIg4hSIAsAAIAhA4IAig4IApAAIg2BSIA8BYg");
	this.shape_100.setTransform(222.925,36.4);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#004B8A").s().p("AAlBVIglg7IgmA7IgrAAIA9hYIg4hSIAsAAIAhA4IAig4IApAAIg2BSIA8BYg");
	this.shape_101.setTransform(206.925,36.4);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#004B8A").s().p("AAlBVIglg7IgmA7IgrAAIA9hYIg4hSIAsAAIAhA4IAig4IApAAIg2BSIA8BYg");
	this.shape_102.setTransform(190.925,36.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2,p:{x:262}},{t:this.instance_1,p:{x:160.65}},{t:this.instance,p:{x:559}}]},9).to({state:[{t:this.instance,p:{x:388}},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},10).to({state:[{t:this.instance_2,p:{x:336}},{t:this.instance_3},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37,p:{x:495.175}},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31,p:{x:592.725}},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28,p:{x:643.15}},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25,p:{x:684.925}},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22,p:{x:732.125}},{t:this.shape_21},{t:this.shape_20,p:{x:767.775}},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17,p:{x:810.325}},{t:this.shape_16,p:{x:824.125}},{t:this.shape_15,p:{x:838.075}},{t:this.instance,p:{x:886}}]},10).to({state:[{t:this.instance,p:{x:352}},{t:this.instance_4}]},10).to({state:[{t:this.instance,p:{x:225}},{t:this.instance_5}]},10).to({state:[{t:this.instance,p:{x:372}},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45}]},10).to({state:[{t:this.shape_55},{t:this.instance,p:{x:279}}]},10).to({state:[{t:this.instance,p:{x:335}},{t:this.instance_6}]},10).to({state:[{t:this.instance,p:{x:278}},{t:this.instance_7}]},10).to({state:[{t:this.instance,p:{x:265}},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56}]},10).to({state:[{t:this.instance,p:{x:389}},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62}]},10).to({state:[{t:this.instance,p:{x:377}},{t:this.instance_8},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_22,p:{x:484.875}},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_17,p:{x:541.775}},{t:this.shape_80},{t:this.shape_16,p:{x:572.925}},{t:this.shape_79},{t:this.shape_31,p:{x:601.125}},{t:this.shape_78},{t:this.shape_15,p:{x:633.175}},{t:this.shape_77},{t:this.shape_76},{t:this.shape_28,p:{x:683.2}},{t:this.shape_75},{t:this.shape_37,p:{x:712.275}},{t:this.shape_74},{t:this.shape_25,p:{x:740.075}},{t:this.shape_20,p:{x:753.175}},{t:this.shape_73},{t:this.shape_72}]},10).to({state:[{t:this.instance,p:{x:276}},{t:this.instance_9}]},10).to({state:[{t:this.instance,p:{x:346}},{t:this.instance_10}]},10).to({state:[{t:this.instance,p:{x:326}},{t:this.instance_11}]},10).to({state:[{t:this.instance,p:{x:342}},{t:this.instance_12}]},10).to({state:[{t:this.instance,p:{x:316}},{t:this.instance_13}]},10).to({state:[{t:this.instance,p:{x:316}},{t:this.instance_14}]},10).to({state:[{t:this.instance,p:{x:276}},{t:this.instance_15}]},10).to({state:[{t:this.instance,p:{x:276}},{t:this.instance_16}]},10).to({state:[{t:this.instance_17},{t:this.instance,p:{x:276}}]},10).to({state:[{t:this.instance,p:{x:276}},{t:this.instance_18}]},10).to({state:[{t:this.shape_89},{t:this.instance,p:{x:276}}]},10).to({state:[{t:this.instance,p:{x:276}},{t:this.instance_19}]},10).to({state:[{t:this.instance,p:{x:336}},{t:this.instance_20}]},10).to({state:[{t:this.instance_21},{t:this.instance,p:{x:366}}]},10).to({state:[{t:this.instance,p:{x:256}},{t:this.instance_22}]},10).to({state:[{t:this.instance_1,p:{x:270.65}},{t:this.instance_7}]},10).to({state:[{t:this.instance,p:{x:356}},{t:this.instance_23}]},10).to({state:[{t:this.instance,p:{x:356}},{t:this.instance_24}]},10).to({state:[{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90}]},18).wait(6));

	// Layer_2
	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("Ehj/AFeIAAq7MDH/AAAIAAK7g");
	this.shape_103.setTransform(640,35);
	this.shape_103._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_103).wait(9).to({_off:false},0).wait(314));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,1280,70.8);
// library properties:
lib.properties = {
	id: '284D0C179085334E961662CC8FA93117',
	width: 1280,
	height: 70,
	fps: 24,
	color: "#000000",
	opacity: 1.00,
	manifest: [
		{src:"images/aveeno_title.png", id:"aveeno_title"},
		{src:"images/bengeylogo.png", id:"bengeylogo"},
		{src:"images/Bitmap13.png", id:"Bitmap13"},
		{src:"images/Bitmap18.png", id:"Bitmap18"},
		{src:"images/Bitmap25.png", id:"Bitmap25"},
		{src:"images/Bitmap26.png", id:"Bitmap26"},
		{src:"images/Bitmap28.png", id:"Bitmap28"},
		{src:"images/Bitmap30.png", id:"Bitmap30"},
		{src:"images/dicloranSmallLogo.png", id:"dicloranSmallLogo"},
		{src:"images/HexoBroncho.png", id:"HexoBroncho"},
		{src:"images/hexorallogo.png", id:"hexorallogo"},
		{src:"images/imodiumLogo.png", id:"imodiumLogo"},
		{src:"images/imofloralogo.png", id:"imofloralogo"},
		{src:"images/listerine.png", id:"listerine"},
		{src:"images/logo.png", id:"logo"},
		{src:"images/logo_alergy.png", id:"logo_alergy"},
		{src:"images/logoMom.png", id:"logoMom"},
		{src:"images/motilegas_icon.png", id:"motilegas_icon"},
		{src:"images/motrine.png", id:"motrine"},
		{src:"images/neutrogena.png", id:"neutrogena"},
		{src:"images/nikorettelogo.png", id:"nikorettelogo"},
		{src:"images/ob_title.png", id:"ob_title"},
		{src:"images/penaten.png", id:"penaten"},
		{src:"images/topSplitter.png", id:"topSplitter"},
		{src:"images/tyzine.png", id:"tyzine"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['284D0C179085334E961662CC8FA93117'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;